package com.sxt.serice;

import com.sxt.swing.AdminOperateSwing;

/**
 * 用于管理员操作的adminswing界面相关操作
 * @author pengl
 *
 */
public class AdminOperate {

	public AdminOperate() {
		new AdminOperateSwing();
	}

}
