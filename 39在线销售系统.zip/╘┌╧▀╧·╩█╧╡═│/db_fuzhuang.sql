/*
Navicat MySQL Data Transfer

Source Server         : ares
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : db_fuzhuang

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2015-04-16 21:11:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL DEFAULT '0',
  `userName` varchar(50) DEFAULT NULL,
  `userPw` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'admin', 'admin');
INSERT INTO `t_admin` VALUES ('2', 'ff', 'ff');

-- ----------------------------
-- Table structure for `t_catelog`
-- ----------------------------
DROP TABLE IF EXISTS `t_catelog`;
CREATE TABLE `t_catelog` (
  `catelog_id` int(11) NOT NULL DEFAULT '0',
  `catelog_name` varchar(50) DEFAULT NULL,
  `catelog_miaoshu` varchar(5000) DEFAULT NULL,
  `catelog_del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`catelog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_catelog
-- ----------------------------
INSERT INTO `t_catelog` VALUES ('1', '西装 ', '请输入内容', 'no');
INSERT INTO `t_catelog` VALUES ('2', '休闲服', '请输入内容', 'no');
INSERT INTO `t_catelog` VALUES ('3', '学生装', '请输入内容', 'no');
INSERT INTO `t_catelog` VALUES ('4', '情侣装', '请输入内容', 'no');

-- ----------------------------
-- Table structure for `t_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `t_gonggao`;
CREATE TABLE `t_gonggao` (
  `gonggao_id` int(11) NOT NULL DEFAULT '0',
  `gonggao_title` varchar(500) DEFAULT NULL,
  `gonggao_content` varchar(8000) DEFAULT NULL,
  `gonggao_data` varchar(50) DEFAULT NULL,
  `gonggao_fabuzhe` varchar(50) DEFAULT NULL,
  `gonggao_del` varchar(50) DEFAULT NULL,
  `gonggao_one1` varchar(50) DEFAULT NULL,
  `gonggao_one2` varchar(50) DEFAULT NULL,
  `gonggao_one3` varchar(50) DEFAULT NULL,
  `gonggao_one4` varchar(50) DEFAULT NULL,
  `gonggao_one5` datetime DEFAULT NULL,
  `gonggao_one6` datetime DEFAULT NULL,
  `gonggao_one7` int(11) DEFAULT NULL,
  `gonggao_one8` int(11) DEFAULT NULL,
  PRIMARY KEY (`gonggao_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_gonggao
-- ----------------------------
INSERT INTO `t_gonggao` VALUES ('1', '测试公告', '测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告测试公告', '2012-2-28 0:51:27', null, null, null, null, null, null, null, null, null, null);
INSERT INTO `t_gonggao` VALUES ('2', '网站开通公告', '网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告网站开通公告', '2012-2-28 0:51:38', null, null, null, null, null, null, null, null, null, null);
INSERT INTO `t_gonggao` VALUES ('3', '22222', '<p>2222</p>', '2012-2-28 2:29:54', null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `t_goods`
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `goods_id` int(11) NOT NULL DEFAULT '0',
  `goods_name` varchar(500) DEFAULT NULL,
  `goods_miaoshu` varchar(5000) DEFAULT NULL,
  `goods_pic` varchar(50) DEFAULT NULL,
  `goods_yanse` varchar(50) DEFAULT NULL,
  `goods_shichangjia` int(11) DEFAULT NULL,
  `goods_tejia` int(11) DEFAULT NULL,
  `goods_isnottejia` varchar(50) DEFAULT NULL,
  `goods_isnottuijian` varchar(50) DEFAULT NULL,
  `goods_catelog_id` int(11) DEFAULT NULL,
  `goods_kucun` int(11) DEFAULT NULL,
  `goods_del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('1', '休闲装测试信息', '休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息休闲装测试信息', '/upload/1330363430843.jpg', null, '11', '11', 'yes', null, '2', '0', 'no');
INSERT INTO `t_goods` VALUES ('2', '测试1111', '测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111测试1111', '/upload/1330363674484.jpg', null, '33', '33', 'yes', null, '3', '33', 'no');
INSERT INTO `t_goods` VALUES ('3', '情侣装相关信息', '情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息', '/upload/1330363697953.jpg', null, '44', '404', 'yes', null, '4', '44', 'yes');
INSERT INTO `t_goods` VALUES ('4', '情侣装相关信息', '情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息情侣装相关信息', '/upload/1330363725968.jpg', null, '44', '44', 'yes', null, '4', '42', 'no');
INSERT INTO `t_goods` VALUES ('5', '学生装测试', '学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试学生装测试', '/upload/1330363748906.jpg', null, '55', '55', 'yes', null, '3', '55', 'no');
INSERT INTO `t_goods` VALUES ('6', '休闲服特价', '休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价休闲服特价', '/upload/1330363772625.jpg', null, '66', '55', 'yes', null, '2', '544', 'no');
INSERT INTO `t_goods` VALUES ('7', '学生最新流行', '学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行学生最新流行', '/upload/1330363800484.jpg', null, '88', '77', 'yes', null, '3', '775', 'no');
INSERT INTO `t_goods` VALUES ('8', '测试信息测试信息', '测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息', '/upload/1330363911406.jpg', null, '55', '0', 'no', null, '2', '22', 'no');
INSERT INTO `t_goods` VALUES ('9', '测试信息测试信息测试信息测试信息', '测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息请输入内容', '/upload/1330363926609.jpg', null, '77', '77', 'no', null, '3', '75', 'no');
INSERT INTO `t_goods` VALUES ('10', '测试信息测试信息测试信息', '测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息', '/upload/1330363937156.jpg', null, '99', '99', 'no', null, '1', '996', 'no');
INSERT INTO `t_goods` VALUES ('11', '测试信息测试信息', '测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息测试信息', '/upload/1330363972328.jpg', null, '99', '99', 'no', null, '1', '97', 'no');

-- ----------------------------
-- Table structure for `t_liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyan`;
CREATE TABLE `t_liuyan` (
  `liuyan_id` int(11) NOT NULL DEFAULT '0',
  `liuyan_title` varchar(50) DEFAULT NULL,
  `liuyan_content` varchar(5000) DEFAULT NULL,
  `liuyan_date` varchar(50) DEFAULT NULL,
  `liuyan_user` varchar(50) DEFAULT NULL,
  `recontent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`liuyan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_liuyan
-- ----------------------------
INSERT INTO `t_liuyan` VALUES ('1', '1111', '<p>11</p>', '2012-2-28 0:58:01', 'aaaaaa', null);

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `order_id` int(11) NOT NULL DEFAULT '0',
  `order_bianhao` varchar(50) DEFAULT NULL,
  `order_date` varchar(50) DEFAULT NULL,
  `order_zhuangtai` varchar(50) DEFAULT NULL,
  `order_jine` int(11) DEFAULT NULL,
  `order_songhuodizhi` varchar(50) DEFAULT NULL,
  `order_fukuangfangshi` varchar(50) DEFAULT NULL,
  `order_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1', '20120228013615', '2012-02-28 01:36:15', 'yes', '594', '', '货到付款', '2');
INSERT INTO `t_order` VALUES ('2', '20120228022755', '2012-02-28 02:27:55', 'no', '297', '', '货到付款', '3');

-- ----------------------------
-- Table structure for `t_orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `t_orderitem`;
CREATE TABLE `t_orderitem` (
  `orderItem_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL,
  `goods_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderItem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_orderitem
-- ----------------------------
INSERT INTO `t_orderitem` VALUES ('1', '1', '4', '2');
INSERT INTO `t_orderitem` VALUES ('2', '1', '7', '2');
INSERT INTO `t_orderitem` VALUES ('3', '1', '9', '2');
INSERT INTO `t_orderitem` VALUES ('4', '1', '10', '2');
INSERT INTO `t_orderitem` VALUES ('5', '2', '10', '1');
INSERT INTO `t_orderitem` VALUES ('6', '2', '11', '2');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_name` varchar(50) DEFAULT NULL,
  `user_pw` varchar(50) DEFAULT NULL,
  `user_realname` varchar(50) DEFAULT NULL,
  `user_address` varchar(50) DEFAULT NULL,
  `user_sex` varchar(50) DEFAULT NULL,
  `user_tel` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_qq` varchar(50) DEFAULT NULL,
  `user_man` varchar(50) DEFAULT NULL,
  `user_age` varchar(50) DEFAULT NULL,
  `user_birthday` varchar(50) DEFAULT NULL,
  `user_xueli` varchar(50) DEFAULT NULL,
  `user_del` varchar(50) DEFAULT NULL,
  `user_one1` varchar(50) DEFAULT NULL,
  `user_one2` varchar(50) DEFAULT NULL,
  `user_one3` varchar(50) DEFAULT NULL,
  `user_one4` varchar(50) DEFAULT NULL,
  `user_one5` varchar(50) DEFAULT NULL,
  `user_one6` int(11) DEFAULT NULL,
  `user_one7` int(11) DEFAULT NULL,
  `user_one8` int(11) DEFAULT NULL,
  `user_one9` datetime DEFAULT NULL,
  `user_one10` datetime DEFAULT NULL,
  `user_one11` bigint(20) DEFAULT NULL,
  `user_one12` bigint(20) DEFAULT NULL,
  `user_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('2', 'aaaaaa', 'aaaaaa', 'aaa', 'aa', '男', '', '', '', null, null, null, null, 'no', null, null, null, null, null, null, null, null, null, null, null, null, '0');
INSERT INTO `t_user` VALUES ('3', 'cccccc', 'cccccc', 'cc', 'cc', '男', '', '', '', null, null, null, null, 'no', null, null, null, null, null, null, null, null, null, null, null, null, '0');
