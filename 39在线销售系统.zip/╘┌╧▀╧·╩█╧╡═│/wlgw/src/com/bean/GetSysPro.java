package com.bean;

import java.text.SimpleDateFormat;
import java.util.Calendar;



	public class GetSysPro {
		
	 public  String getDate()
	    {Calendar cal=Calendar.getInstance();//-0����0��ǰ���ʱ���ʱ��
	        cal.add(Calendar.DAY_OF_YEAR,-0);
	        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        String nowtime=sdf.format(cal.getTime());
	        return nowtime;
	    }
		
	 public String getVendor(){
		 String vendor = System.getProperty("java.vendor");
		 return vendor;
	 }
	 public String getVenurl(){
		 String venurl = System.getProperty("java.vendor.url");
		 return venurl;
	 }
	 public String getVersion(){
		 String version = System.getProperty("java.class.version");
		 return version;
	 }
	 public String getPath(){
		 String path = System.getProperty("java.class.path");
		 return path;
	 }
	 public String getUname(){
		 String username = System.getProperty("user.name");
		 return username;
	 }
	 public String getUhome(){
		 String userhome = System.getProperty("user.home");
		 return userhome;
	 }
	 public String getUdir(){
		 String userdir = System.getProperty("user.dir");
		 return userdir;
	 } 
	 public String getJVSver(){
		 String jvsver = System.getProperty("java_vm_specification_version");
		 return jvsver;
	 }
	 public String getJVSven(){
		 String jvsven = System.getProperty("java.vm.specification.vendor");
		 return jvsven;
	 }
	 public String getJVSname(){
		 String jvsname = System.getProperty("java_vm_specification_name");
		 return jvsname;
	 } 	
	 
	 public String getJVver(){
		 String jvver = System.getProperty("java.vm.version");
		 return jvver;
	 } 
	 public String getJVven(){
		 String jvven = System.getProperty("java.vm.vendor");
		 return jvven;
	 }
	 public String getJVname(){
		 String jvname = System.getProperty("java.vm.name");
		 return jvname;
	 }
	 public String getDir(){
		 String dir = System.getProperty("java.ext.dirs");
		 return dir;
	 } 		 
	 
	 public String getFSep(){
		 String fsep = System.getProperty("file.separator");
		 return fsep;
	 }
	 public String getPSep(){
		 String psep = System.getProperty("path.separator");
		 return psep;
	 }
	 public String getLSep(){
		 String lsep = System.getProperty("line.separator");
		 return lsep;
	 } 		 
	 
	 
	 
	 
	
	 
}
