package com.vo.web.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.bean.Apply;
import com.vo.bean.Log;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.service.LogService;

public class LogAction extends ActionSupport {
	private LogService logService;

	public LogService getLogService() {
		return logService;
	}

	public void setLogService(LogService logService) {
		this.logService = logService;
	}

	public String findUsersLogs() {

		// 查找用户
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		Integer id = user.getId();

		// 根据用户查找日志
		List<Log> findLogs = logService.findLogs(id);
		if (findLogs != null && findLogs.size() != 0) {
			ServletActionContext.getRequest().setAttribute("userlogs", findLogs);
			return SUCCESS;
		} else {
			String error = "您还没有项目日志";
			ServletActionContext.getRequest().setAttribute("error", error);
			return ERROR;
		}

	};

	public String findApplyLog() {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();

		String[] applyid1 = (String[]) params.get("applyid");
		String applyid = applyid1[0];
		Apply apply = logService.findApplyByApplyId(Integer.valueOf(applyid));
		LogTable applyLog = logService.findApplyLogByApplyId(Integer.valueOf(applyid));
		ServletActionContext.getRequest().setAttribute("apply", apply);
		ServletActionContext.getRequest().setAttribute("applyLog", applyLog);
		return SUCCESS;
	}

	@Override
	public String execute() throws Exception {

		Map<Integer, String> cost = new HashMap<Integer, String>();
		Map<Integer, String> lost = new HashMap<Integer, String>();

		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();

		String[] cost_1arr = (String[]) params.get("cost_1");
		String cost_1 = cost_1arr[0];
		cost.put(1, cost_1);
		String[] lost_1arr = (String[]) params.get("lost_1");
		String lost_1 = lost_1arr[0];
		lost.put(1, lost_1);

		String[] cost_2arr = (String[]) params.get("cost_2");
		String cost_2 = cost_2arr[0];
		cost.put(2, cost_2);
		String[] lost_2arr = (String[]) params.get("lost_2");
		String lost_2 = lost_2arr[0];
		lost.put(2, lost_2);

		String[] cost_3arr = (String[]) params.get("cost_3");
		String cost_3 = cost_3arr[0];
		cost.put(3, cost_3);
		String[] lost_3arr = (String[]) params.get("lost_3");
		String lost_3 = lost_3arr[0];
		lost.put(3, lost_3);

		String[] cost_4arr = (String[]) params.get("cost_4");
		String cost_4 = cost_4arr[0];
		cost.put(4, cost_4);
		String[] lost_4arr = (String[]) params.get("lost_4");
		String lost_4 = lost_4arr[0];
		lost.put(4, lost_4);

		String[] cost_5arr = (String[]) params.get("cost_5");
		String cost_5 = cost_5arr[0];
		cost.put(5, cost_5);
		String[] lost_5arr = (String[]) params.get("lost_5");
		String lost_5 = lost_5arr[0];
		lost.put(5, lost_5);

		String[] cost_6arr = (String[]) params.get("cost_6");
		String cost_6 = cost_6arr[0];
		cost.put(6, cost_6);
		String[] lost_6arr = (String[]) params.get("lost_6");
		String lost_6 = lost_6arr[0];
		lost.put(6, lost_6);

		String[] cost_7arr = (String[]) params.get("cost_7");
		String cost_7 = cost_7arr[0];
		cost.put(7, cost_7);
		String[] lost_7arr = (String[]) params.get("lost_7");
		String lost_7 = lost_7arr[0];
		lost.put(7, lost_7);

		String[] cost_8arr = (String[]) params.get("cost_1");
		String cost_8 = cost_8arr[0];
		cost.put(8, cost_8);
		String[] lost_8arr = (String[]) params.get("lost_1");
		String lost_8 = lost_8arr[0];
		lost.put(8, lost_8);

		String[] cost_9arr = (String[]) params.get("cost_9");
		String cost_9 = cost_9arr[0];
		cost.put(9, cost_9);
		String[] lost_9arr = (String[]) params.get("lost_9");
		String lost_9 = lost_9arr[0];
		lost.put(9, lost_9);

		String[] cost_10arr = (String[]) params.get("cost_10");
		String cost_10 = cost_10arr[0];
		cost.put(10, cost_10);
		String[] lost_10arr = (String[]) params.get("lost_10");
		String lost_10 = lost_10arr[0];
		lost.put(10, lost_10);

		String[] cost_11arr = (String[]) params.get("cost_11");
		String cost_11 = cost_11arr[0];
		cost.put(11, cost_11);
		String[] lost_11arr = (String[]) params.get("lost_11");
		String lost_11 = lost_11arr[0];
		lost.put(11, lost_11);

		String[] cost_12arr = (String[]) params.get("cost_12");
		String cost_12 = cost_12arr[0];
		cost.put(12, cost_12);
		String[] lost_12arr = (String[]) params.get("lost_12");
		String lost_12 = lost_12arr[0];
		lost.put(12, lost_12);

		/**
		 * 获取userId和applyId
		 */
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		Integer id = user.getId();

		String[] logId1 = (String[]) params.get("logId");
		String logId = logId1[0];

		Apply apply = logService.findApplyByApplyId(Integer.valueOf(logId));

		for (int i = 1; i <= cost.size(); i++) {
			Log log = new Log();
			log.setCost(cost.get(i));
			log.setLost(lost.get(i));
			log.setMonth(i);
			log.setApply(apply);
			log.setUser(user);
			logService.updateLog(log);
		}

		int costNum = 0;
		for (int i = 1; i <= cost.size(); i++) {
			Integer value = Integer.valueOf(cost.get(i));
			costNum = costNum + value;
		}
		int lostNum = 0;
		for (int i = 1; i <= lost.size(); i++) {
			Integer value = Integer.valueOf(lost.get(i));
			lostNum = lostNum + value;
		}

		
		logService.updateLogTable(costNum,lostNum,Integer.valueOf(logId), id);

		String error = "日志修改成功";
		ServletActionContext.getRequest().setAttribute("error", error);

		return SUCCESS;
	}

	public String showLog() {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();

		String[] applyId1 = (String[]) params.get("applyid");
		String applyId = applyId1[0];

		Apply apply = logService.findApplyByApplyId(Integer.valueOf(applyId));

		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		Integer id = user.getId();

		List<Log> monthLog = logService.findLogByUserIdAndApplyId(id, Integer.valueOf(applyId));
		LogTable logTable = logService.findApplyLogByApplyId(Integer.valueOf(applyId));

		ServletActionContext.getRequest().setAttribute("monthLog", monthLog);
		ServletActionContext.getRequest().setAttribute("apply", apply);
		ServletActionContext.getRequest().setAttribute("logTable", logTable);
		return SUCCESS;
	}

}
