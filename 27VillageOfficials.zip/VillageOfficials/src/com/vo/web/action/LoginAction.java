package com.vo.web.action;

import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.bean.Admin;
import com.vo.bean.User;
import com.vo.service.LoginService;

public class LoginAction extends ActionSupport {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;

	public LoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}

	@Override
	public String execute() throws Exception {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		// ��ȡ�û�������
		String[] usertype1 = (String[]) params.get("usertype");
		String[] username1 = (String[]) params.get("username");
		String[] password1 = (String[]) params.get("password");

		String usertype = usertype1[0];
		String username = username1[0];
		String password = password1[0];

		if (usertype.equals("user")) {
			User user = loginService.userLogin(username, password);
			if (user != null) {
				ServletActionContext.getRequest().getSession().setAttribute("user", user);
				return "user";
			}
			return ERROR;
		} else {
			Admin admin = loginService.adminLogin(username, password);
			if (admin != null) {
				ServletActionContext.getRequest().getSession().setAttribute("admin", admin);
				return "admin";
			}
			return ERROR;
		}
	}
	
	public String choosePage(){
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		boolean fullinfo = user.isFullinfo();
		if(fullinfo){
			return "showinfo";
		}
		return "custominfo";
	}
}
