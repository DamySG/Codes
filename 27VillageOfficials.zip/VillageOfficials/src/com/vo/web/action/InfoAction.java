package com.vo.web.action;

import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.bean.User;
import com.vo.service.InfoService;

public class InfoAction extends ActionSupport{
	
	private InfoService infoService;
	
	public InfoService getInfoService() {
		return infoService;
	}

	public void setInfoService(InfoService infoService) {
		this.infoService = infoService;
	}

	@Override
	public String execute() throws Exception {
		
		//获取参数
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		
		String[] name1 = (String[]) params.get("name");
		String name = name1[0];
		
		String[] oldname1 = (String[]) params.get("oldname");
		String oldname = oldname1[0];
		
		String[] gender1 = (String[]) params.get("gender");
		String gender = gender1[0];
		
		String[] minzu1 = (String[]) params.get("minzu");
		String minzu = minzu1[0];
		
		String[] home1 = (String[]) params.get("home");
		String home = home1[0];
		
		String[] zhengzhi1 = (String[]) params.get("zhengzhi");
		String zhengzhi = zhengzhi1[0];
		
		String[] marrage1 = (String[]) params.get("marrage");
		String marrage = marrage1[0];
		
		String[] city1 = (String[]) params.get("city");
		String city = city1[0];
		
		String[] county1 = (String[]) params.get("county");
		String county = county1[0];
		
		String[] town1 = (String[]) params.get("town");
		String town = town1[0];
		
		String[] year1 = (String[]) params.get("year");
		String year = year1[0];
		
		String[] month1 = (String[]) params.get("month");
		String month = month1[0];
		
		String[] xueli1 = (String[]) params.get("xueli");
		String xueli = xueli1[0];
		
		String[] xuewei1 = (String[]) params.get("xuewei");
		String xuewei = xuewei1[0];
		
		String[] school1 = (String[]) params.get("school");
		String school = school1[0];
		
		String[] zhuanye1 = (String[]) params.get("zhuanye");
		String zhuanye = zhuanye1[0];
		
		String[] gr1 = (String[]) params.get("gr");
		String gr = gr1[0];
		
		String[] gm1 = (String[]) params.get("gm");
		String gm = gm1[0];
		
		String[] phone1 = (String[]) params.get("phone");
		String phone = phone1[0];
		
		String[] email1 = (String[]) params.get("email");
		String email = email1[0];
		
		String[] youbian1 = (String[]) params.get("youbian");
		String youbian = youbian1[0];
		
		String[] jiangcheng1 = (String[]) params.get("jiangcheng");
		String jiangcheng = jiangcheng1[0];
		
		String[] peixun1 = (String[]) params.get("peixun");
		String peixun = peixun1[0];
		
		String[] qita1 = (String[]) params.get("qita");
		String qita = qita1[0];
		
		String birthday = year + "-" + month;
		String biyeshijian = gr + "-" + gm;
		
		User sessionU = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		
		sessionU.setName(name);
		sessionU.setOldname(oldname);
		sessionU.setGender(Boolean.valueOf(gender));
		sessionU.setNative_(minzu);
		sessionU.setHome(home);
		sessionU.setZhengzhi(zhengzhi);
		sessionU.setMarrage(marrage);
		sessionU.setCity(city);
		sessionU.setCounty(county);
		sessionU.setTown(town);
		sessionU.setBirthday(birthday);
		sessionU.setXueli(xueli);
		sessionU.setXuewei(xuewei);
		sessionU.setSchool(school);
		sessionU.setZhuanye(zhuanye);
		sessionU.setBiyeshijian(biyeshijian);
		sessionU.setPhone(phone);
		sessionU.setEmail(email);
		sessionU.setPost(youbian);
		sessionU.setJiangcheng(jiangcheng);
		sessionU.setPeixun(peixun);
		sessionU.setQita(qita);
		
		boolean infofull = false;
		
		if(!(name.equals("")&&gender.equals("")&&city.equals("")&&county.equals("")&&town.equals("")&&birthday.equals("")&&xueli.equals("")&&xuewei.equals("")&&phone.equals("")&&email.equals(""))){
			infofull = true;
		}
		
		sessionU.setFullinfo(infofull);
		
		Integer id = sessionU.getId();
		boolean update = infoService.updateUserById(id, sessionU);
		/*boolean update = infoService.updateUserById(id, name,oldname,gender,minzu,home,zhengzhi,marrage,city,county,town,birthday,xueli,xuewei,school,zhuanye,biyeshijian,phone,email,youbian,jiangcheng,peixun,qita, infofull);*/
		if(update){
			ServletActionContext.getRequest().getSession().setAttribute("user", sessionU);
			return SUCCESS;
		}
		return ERROR;
	}
	
}
