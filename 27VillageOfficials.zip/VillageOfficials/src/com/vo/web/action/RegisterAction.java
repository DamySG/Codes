package com.vo.web.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.service.RegistryService;

public class RegisterAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	
	private RegistryService registryService; 
	

	public RegistryService getRegistryService() {
		return registryService;
	}


	public void setRegistryService(RegistryService registryService) {
		this.registryService = registryService;
	}


	@Override
	public String execute() throws Exception {
		boolean ok = false;
		
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		
		String[] username1 = (String[]) params.get("username");
		String[] password1 = (String[]) params.get("password");
		String[] password21 = (String[]) params.get("password2");
		
		String username = username1[0];
		String password = password1[0];
		String password2 = password21[0];

		if (username != null && password != null && password2 != null) {
			if (password.equals(password2)) {
				ok  = registryService.registry(username, password,false);
			}
		}
		if(ok){
			return SUCCESS;
		}
		return ERROR;
	}
}
