package com.vo.web.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.service.AdminService;

public class AdminAction extends ActionSupport {
	private AdminService adminService;

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public String usersList() {
		List<User> users = adminService.findUsers();
		
		if (users.size() > 0) {
			ServletActionContext.getRequest().setAttribute("users", users);
			return SUCCESS;
		}
		return null;
	}

	public String user() {
		
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] id1 = (String[]) params.get("id");
		String id = id1[0];

		User user = adminService.findUserById(Integer.valueOf(id));
		if (user != null) {
			ServletActionContext.getRequest().setAttribute("user", user);
			return SUCCESS;
		}
		return null;
	}

	public String userApplyList() {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] userId1 = (String[]) params.get("userId");
		String userId = userId1[0];
	
		List<Apply> applies = adminService.findApplyByUserId(Integer.valueOf(userId));
		if (applies.size() > 0) {
			ServletActionContext.getRequest().setAttribute("userapplies", applies);
			return SUCCESS;
		}
		return null;
	}
	
	public String applyList() {
		
		List<Apply> applies = adminService.findApplies();
		if (applies.size() > 0) {
			ServletActionContext.getRequest().setAttribute("applies", applies);
			return SUCCESS;
		}
		return null;
	}

	public String apply() {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] id1 = (String[]) params.get("id");
		String id = id1[0];

		Apply apply = adminService.findApplyById(Integer.valueOf(id));
		if (apply != null) {
			ServletActionContext.getRequest().setAttribute("apply", apply);
			return SUCCESS;
		}
		return null;
	}
	
	public String LogList(){
		List<LogTable> logLists = adminService.findLogLists();
		if (logLists.size() > 0) {
			ServletActionContext.getRequest().setAttribute("logLists", logLists);
			return SUCCESS;
		}
		return null;
	}
	
	public String Log(){
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] id1 = (String[]) params.get("id");
		String id = id1[0];

		LogTable log = adminService.findLogById(Integer.valueOf(id));
		if (log != null) {
			ServletActionContext.getRequest().setAttribute("log", log);
			return SUCCESS;
		}
		return null;
	}
	
	public String applyResult(){
		HttpServletRequest request = ServletActionContext.getRequest();
		
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		
		String[] result1 = (String[]) params.get("result");
		String result = result1[0];
		
		String[] applyId1 = (String[]) params.get("applyId");
		String applyId = applyId1[0];
		
		boolean update = adminService.updateApply(Integer.valueOf(result),Integer.valueOf(applyId));
		//根据项目Id和用户Id  创建日志
		Apply apply = adminService.findApplyById(Integer.valueOf(applyId));
		LogTable logTable = new LogTable();
		logTable.setApply(apply);
		logTable.setUser(apply.getUser());
		boolean createLog = adminService.createLog(logTable);
		
		if(update){
			System.out.println("操作成功");
			String error = "操作成功";
			request.setAttribute("error", error);
			return SUCCESS;
		}
		return ERROR;
	}
	
	public String sum(){
		int userNum = adminService.UserNum();
		//男女比例
		int manNum = adminService.ManNum();
		int man = (manNum/userNum)*100;
		int woman = ((userNum-manNum)/userNum)*100;
		ServletActionContext.getRequest().setAttribute("man", man);
		ServletActionContext.getRequest().setAttribute("woman", woman);
		//学历
		int benKeNum = adminService.BenKeNum();
		int zhuanKeNum = adminService.ZhuanKeNum();
		int yanJiuShengNum = adminService.YanJiuShengNum();
		
		int benke = (benKeNum/userNum)*100;
		int zhanke = (zhuanKeNum/userNum)*100;
		int yanjiusheng = (yanJiuShengNum/userNum)*100;
		ServletActionContext.getRequest().setAttribute("benke", benke);
		ServletActionContext.getRequest().setAttribute("zhanke", zhanke);
		ServletActionContext.getRequest().setAttribute("yanjiusheng", yanjiusheng);
		
		//项目分类
		int applyNum = adminService.ApplyNum();
		
		int zhongzhiNum = adminService.ZhongzhiNum();
		int xuMuNum = adminService.XuMuNum();
		int jiaoYuNum = adminService.JiaoYuNum();
		int waiLianNum = adminService.WaiLianNum();
		
		int zhongzhi = (zhongzhiNum/applyNum)*100;
		int xumu = (xuMuNum/applyNum)*100;
		int jiaoyu = (jiaoYuNum/applyNum)*100;
		int wailian = (waiLianNum/applyNum)*100;
		
		ServletActionContext.getRequest().setAttribute("zhongzhi", zhongzhi);
		ServletActionContext.getRequest().setAttribute("xumu", xumu);
		ServletActionContext.getRequest().setAttribute("jiaoyu", jiaoyu);
		ServletActionContext.getRequest().setAttribute("wailian", wailian);
		
		return SUCCESS;
	}

}
