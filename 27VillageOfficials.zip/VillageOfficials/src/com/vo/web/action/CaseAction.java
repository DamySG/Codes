package com.vo.web.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import sun.print.resources.serviceui;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.service.CaseService;

public class CaseAction extends ActionSupport {
	private CaseService caseService;

	public CaseService getCaseService() {
		return caseService;
	}

	public void setCaseService(CaseService caseService) {
		this.caseService = caseService;
	}
	
	public String checkInfo(){
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		boolean fullinfo = user.isFullinfo();
		if(fullinfo){
			return SUCCESS;
		}else {
			String error = "您的用户信息还没有填写完整哟，请先完善";
			ServletActionContext.getRequest().setAttribute("error", error);
			return ERROR;
		}
		
	}

	@Override
	public String execute() throws Exception {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();

		String[] subject1 = (String[]) params.get("subject");
		String subject = subject1[0];

		String[] name1 = (String[]) params.get("name");
		String name = name1[0];

		String[] fund1 = (String[]) params.get("fund");
		String fund = fund1[0];

		String[] location1 = (String[]) params.get("location");
		String location = location1[0];

		String[] year1 = (String[]) params.get("year");
		String year = year1[0];

		String[] month1 = (String[]) params.get("month");
		String month = month1[0];

		String stime = year + "-" + month;

		String[] area1 = (String[]) params.get("area");
		String area = area1[0];

		String[] shuoming1 = (String[]) params.get("shuoming");
		String shuoming = shuoming1[0];

		User sessionU = (User) ServletActionContext.getRequest().getSession().getAttribute("user");

		Apply a = new Apply();
		a.setSubject(subject);
		a.setName(name);
		a.setFund(Integer.valueOf(fund));
		a.setLocation(location);
		a.setStime(stime);
		a.setArea(Integer.valueOf(area));
		a.setPass(0);
		a.setShuoming(shuoming);
		a.setUser(sessionU);

		boolean updateApply = caseService.updateApply(a);
		if (updateApply) {
			return SUCCESS;
		}
		return ERROR;
	}

	public String findUserCase() {
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		Integer id = user.getId();

		List<Apply> applies = caseService.findUserCase(id);
		if (applies != null && applies.size() != 0) {
			ServletActionContext.getRequest().setAttribute("case", applies);
			return SUCCESS;
		} else {
			String error = "您还没有申请项目哦,快去创建吧";
			ServletActionContext.getRequest().setAttribute("error", error);
			return ERROR;
		}
	}

	public String findCase() {
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] id1 = (String[]) params.get("id");
		String id = id1[0];

		Apply c = caseService.findCase(Integer.valueOf(id));
		if (c != null) {
			ServletActionContext.getRequest().setAttribute("c", c);
			return SUCCESS;
		}
		return null;
	}
	
	public String createLog(){
		ActionContext ac = ActionContext.getContext();
		Map params = ac.getParameters();
		String[] applyId1 = (String[]) params.get("applyId");
		String applyId = applyId1[0];
		Apply apply = caseService.findCase(Integer.valueOf(applyId));
		
		User user = (User) ServletActionContext.getRequest().getSession().getAttribute("user");
		Integer id = user.getId();
		
		//根据用户Id 和 applyId 创建日志
		LogTable log = new LogTable();
		log.setApply(apply);
		log.setUser(user);
		System.out.println("======");
		caseService.updateLog(log);
		
		return SUCCESS;
	}
}
