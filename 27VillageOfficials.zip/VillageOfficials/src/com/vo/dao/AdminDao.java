package com.vo.dao;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;

public interface AdminDao {
	public List<User> findUsers();

	public User findUserById(int id);

	public List<Apply> findApplyByUserId(int UserId);
	
	public boolean createLog(LogTable logTable);

	public Apply findApplyById(int id);

	public LogTable findLogById(int id);

	public List<Apply> findApplies();

	public List<LogTable> findLogLists();

	public boolean updateApply(int result, int id);

	public int UserNum();
	
	public int ApplyNum();

	public int ManNum();

	public int BenKeNum();
	
	public int ZhuanKeNum();
	
	public int YanJiuShengNum();

	public int ZhongzhiNum();

	public int XuMuNum();

	public int JiaoYuNum();

	public int WaiLianNum();

}
