package com.vo.dao;

public interface RegistryDao {
	public boolean registry(String username,String password,boolean fullinfo);
}
