package com.vo.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.vo.bean.Admin;
import com.vo.bean.User;
import com.vo.dao.LoginDao;

public class LoginDaoImpl implements LoginDao{
	private SessionFactory sessionFactory;
	private Session session;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Admin adminLogin(String name, String password) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Admin where name = ? and password = ?";
		Query query = session.createQuery(hql);
		query.setString(0, name);
		query.setString(1, password);
		
		List list = query.list();
		if(list.size() > 0){
			session.getTransaction().commit();
			return  (Admin) list.get(0);
		}
		return null;
	}

	@Override
	public User userLogin(String username, String password) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where username = ? and password = ?";
		Query query = session.createQuery(hql);
		query.setString(0, username);
		query.setString(1, password);
		
		List list = query.list();
		if(list.size() > 0){
			session.getTransaction().commit();
			return (User) list.get(0);
		}
		return null;
	}

}
