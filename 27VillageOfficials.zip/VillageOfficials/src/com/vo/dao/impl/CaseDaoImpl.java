package com.vo.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.dao.CaseDao;

public class CaseDaoImpl implements CaseDao{
	private SessionFactory sessionFactory;
	private Session session;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public boolean updateApply(Apply apply) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(apply);
		session.getTransaction().commit();
		return true;
	}

	@Override
	public List<Apply> findUserCase(int userId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where userId = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, userId);
		
		List list = query.list();
		if(list.size() > 0){
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public Apply findCase(int id) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, id);
		
		List list = query.list();
		if(list.size() > 0){
			session.getTransaction().commit();
			return (Apply) list.get(0);
		}
		return null;
	}

	@Override
	public boolean updateLog(LogTable logTable) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(logTable);
		session.getTransaction().commit();
		return false;
	}

}
