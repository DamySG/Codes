package com.vo.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.vo.bean.User;
import com.vo.dao.InfoDao;

public class InfoDaoImpl implements InfoDao {

	private Session session;
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public boolean updateUserById(int id, User user) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(user);
		session.getTransaction().commit();
		return true;
	}

	@Override
	public boolean updateUserById(int id, String name, String oldname, String gender, String native_, String home, String zhengzhi, String marrage,
			String city, String county, String town, String birthday, String xueli, String xuewei, String school, String zhuanye, String biyeshijian,
			String phone, String email, String post, String jiangcheng, String peixun, String qita, boolean fullinfo) {

		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "update User set name = ?,oldname = ?,gender = ?,native_ = ?,home = ?,zhengzhi = ?,marrage = ?,"+
					"city = ?,county = ?,town = ?,birthday = ?,xueli = ?,xuewei = ?,school = ?,zhuanye = ?,biyeshijian = ?,"
					+"phone = ?,email = ?,post = ?,jiangcheng = ?,peixun = ?,qita = ?, fullinfo  = ? where id = ?";
		
		Query query = session.createQuery(hql);
		query.setString(0, name);
		query.setString(1, oldname);
		query.setString(2, gender);
		query.setString(3, native_);
		query.setString(4, home);
		query.setString(5, zhengzhi);
		query.setString(6, marrage);
		query.setString(7, city);
		query.setString(8, county);
		query.setString(9, town);
		query.setString(10,birthday );
		query.setString(11, xueli);
		query.setString(12, xuewei);
		query.setString(13, school);
		query.setString(14, zhuanye);
		query.setString(15, biyeshijian);
		query.setString(16, phone);
		query.setString(17, email);
		query.setString(18, post);
		query.setString(19, jiangcheng);
		query.setString(20, peixun);
		query.setString(21, qita);
		query.setBoolean(22, fullinfo);
		query.setInteger(23, id);
		

		int execute = query.executeUpdate();
		if (execute > 0) {
			session.getTransaction().commit();
			return true;
		}
		return false;
	}

}
