package com.vo.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.dao.AdminDao;

public class AdminDaoImpl implements AdminDao{
	
	private SessionFactory sessionFactory;
	private Session session;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Apply> findApplyByUserId(int UserId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Admin where userId = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, UserId);
		List<Apply> list = query.list();
		if(list.size()>0){
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public User findUserById(int id) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, id);
		User user = (User) query.list().get(0);
		if(user != null ){
			session.getTransaction().commit();
			return user;
		}
		return null;

	}

	@Override
	public List<User> findUsers() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User";
		Query query = session.createQuery(hql);
		List<User> list = query.list();
		if(list.size()>0){
			session.getTransaction().commit();
			return list;
		}
		return null;

	}

	@Override
	public Apply findApplyById(int id) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, id);
		Apply apply = (Apply) query.list().get(0);
		if(apply != null){
			session.getTransaction().commit();
			return apply;
		}
		return null;
	}

	@Override
	public List<Apply> findApplies() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply";
		Query query = session.createQuery(hql);
		List<Apply> list = query.list();
		if(list.size()>0){
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public List<LogTable> findLogLists() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from LogTable";
		Query query = session.createQuery(hql);
		List<LogTable> list = query.list();
		if(list.size()>0){
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public LogTable findLogById(int id) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from LogTable where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, id);
		LogTable log = (LogTable) query.list().get(0);
		if(log != null){
			session.getTransaction().commit();
			return log;
		}
		return null;
	}

	@Override
	public boolean updateApply(int result, int id) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "update Apply set pass = ? where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, result);
		query.setInteger(1, id);
		int update = query.executeUpdate();
		if(update>0){
			session.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public int BenKeNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where xueli = '本科'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}
	

	@Override
	public int ManNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where gender = 1";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int UserNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
		
	}

	@Override
	public int WaiLianNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where subject = '外联'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int XuMuNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where subject = '畜牧业'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int ZhongzhiNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where subject = '种植业'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int JiaoYuNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where subject = '教育'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int YanJiuShengNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where xueli = '研究生'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int ZhuanKeNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from User where xueli = '专科'";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public int ApplyNum() {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply";
		Query query = session.createQuery(hql);
		List list = query.list();
		session.getTransaction().commit();
		return list.size();
	}

	@Override
	public boolean createLog(LogTable logTable) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.save(logTable);
		session.getTransaction().commit();
		return true;
	}

}
