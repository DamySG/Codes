package com.vo.dao.impl;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.vo.bean.User;
import com.vo.dao.RegistryDao;

public class RegistryDaoImpl extends HibernateDaoSupport implements RegistryDao {

	

	@Override
	public boolean registry(String username, String password,boolean fullinfo) {
		User u = new User();
		u.setUsername(username);
		u.setPassword(password);
		u.setFullinfo(fullinfo);
		getHibernateTemplate().save(u);
		return true;
	}

}
