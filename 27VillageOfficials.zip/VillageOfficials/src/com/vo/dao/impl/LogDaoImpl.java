package com.vo.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.vo.bean.Apply;
import com.vo.bean.Log;
import com.vo.bean.LogTable;
import com.vo.dao.LogDao;

public class LogDaoImpl implements LogDao {

	private Session session;
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Log> findLogs(int userId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from LogTable where userId = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, userId);

		List list = query.list();
		if (list.size() > 0) {
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public Apply findApplyByApplyId(int apply) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "from Apply where id = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, apply);

		Apply apply1 = (Apply) query.list().get(0);
		if (apply1 != null) {
			session.getTransaction().commit();
			return apply1;
		}
		return null;
	}

	@Override
	public Apply findApplyByLog(Log log) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		Apply apply = log.getApply();
		if (apply != null) {
			session.getTransaction().commit();
			return apply;
		}
		return null;
	}

	@Override
	public boolean updateCost(String cost, int month, int applyId, int UserId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String sql = "insert into log(cost) values ? where month = ?, applyId = ? and userId = ?";
		SQLQuery query = session.createSQLQuery(sql);
		query.setString(0, cost);
		query.setInteger(1, month);
		query.setInteger(2, applyId);
		query.setInteger(3, UserId);
		int execute = query.executeUpdate();
		if (execute > 0) {
			session.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public boolean updateLost(String lost, int month, int applyId, int UserId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String sql = "update log set lost = ? where month = ?, applyId = ? and userId = ?";
		SQLQuery query = session.createSQLQuery(sql);
		query.setString(0, lost);
		query.setInteger(1, month);
		query.setInteger(2, applyId);
		query.setInteger(3, UserId);
		int execute = query.executeUpdate();
		if (execute > 0) {
			session.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public List<Log> findLogByUserIdAndApplyId(int userId, int ApplyId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String sql = "from Log where apply = "+ApplyId+" and user = "+userId;
		Query query = session.createQuery(sql);
		/*query.setInteger(0, ApplyId);
		query.setInteger(1, userId);*/
		List list = query.list();
		if (list != null&&list.size()>0) {
			session.getTransaction().commit();
			return list;
		}
		return null;
	}

	@Override
	public LogTable findApplyLogByApplyId(int applyId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String sql = "from LogTable where apply = ?";
		Query query = session.createQuery(sql);
		query.setInteger(0, applyId);
		List list = query.list();
		if (list != null&&list.size()>0) {
			session.getTransaction().commit();
			return (LogTable) list.get(0);
		}
		return null;
	}

	@Override
	public boolean updateCost(Log log) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(log);
		session.getTransaction().commit();
		return true;
	}
	
	@Override
	public boolean updateLost(Log log) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		session.saveOrUpdate(log);
		session.getTransaction().commit();
		return true;
	}
	
	@Override
	public boolean updateLog(Log log) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		/*String hql = "update Log";
		Query query = session.createQuery(hql);
		int update = query.executeUpdate();
		if(update>0){
			session.getTransaction().commit();
			return true;
		}*/
		session.save(log);
		session.getTransaction().commit();
		return false;
	}
	
	@Override
	public boolean updateLog(int cost,int lost,int month,int applyId,int userId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "update Log set cost = ?,lost = ?,month=?where apply = ? and user = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, cost);
		query.setInteger(1, lost);
		query.setInteger(2, month);
		query.setInteger(3, applyId);
		query.setInteger(4, userId);
		int update = query.executeUpdate();
		if(update>0){
			session.getTransaction().commit();
			return true;
		}
		return false;
	}

	@Override
	public boolean updateLogTable(int cost,int lost,int applyId,int userId) {
		session = sessionFactory.getCurrentSession();
		session.beginTransaction();
		String hql = "update LogTable set cost = ?,lost = ?where apply = ? and user = ?";
		Query query = session.createQuery(hql);
		query.setInteger(0, cost);
		query.setInteger(1, lost);
		query.setInteger(2, applyId);
		query.setInteger(3, userId);
		int update = query.executeUpdate();
		if(update>0){
			session.getTransaction().commit();
			return true;
		}
		return false;
	}
}
