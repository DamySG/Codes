package com.vo.dao;

import com.vo.bean.User;

public interface InfoDao {
	public boolean updateUserById(int id,User user);
	
	public boolean updateUserById(int id, String name, String oldname, String gender, String native_, String home, String zhengzhi, String marrage,
			String city, String county, String town, String birthday, String xueli, String xuewei, String school, String zhuanye, String biyeshijian,
			String phone, String email, String post, String jiangcheng, String peixun, String qita, boolean fullinfo);
}
