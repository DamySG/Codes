package com.vo.service;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.Log;
import com.vo.bean.LogTable;

public interface LogService {
	public List<Log> findLogs(int userId);
	
	public Apply findApplyByApplyId(int apply);
	
	public Apply findApplyByLog(Log log);
	
	public boolean updateCost(String cost,int month,int applyId,int UserId);
	
	public boolean updateCost(Log log);
	
	public boolean updateLost(String lost,int month,int applyId,int UserId);
	
	public boolean updateLost(Log log);
	
	public boolean updateLog(Log log);
	
	public boolean updateLog(int cost,int lost,int month,int applyId,int userId);
	
	public boolean updateLogTable(int cost,int lost, int applyId,int userId);
	
	public List<Log> findLogByUserIdAndApplyId(int userId,int ApplyId);
	
	public LogTable findApplyLogByApplyId(int applyId);
}
