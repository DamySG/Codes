package com.vo.service.impl;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.dao.CaseDao;
import com.vo.service.CaseService;

public class CaseServiceImpl implements CaseService{
	private CaseDao caseDao;

	public CaseDao getCaseDao() {
		return caseDao;
	}

	public void setCaseDao(CaseDao caseDao) {
		this.caseDao = caseDao;
	}

	@Override
	public boolean updateApply(Apply apply) {
		return caseDao.updateApply(apply);
	}

	@Override
	public List<Apply> findUserCase(int userId) {
		return caseDao.findUserCase(userId);
	}

	@Override
	public Apply findCase(int id) {
		return caseDao.findCase(id);
	}

	@Override
	public boolean updateLog(LogTable logTable) {
		return caseDao.updateLog(logTable);
	}

}
