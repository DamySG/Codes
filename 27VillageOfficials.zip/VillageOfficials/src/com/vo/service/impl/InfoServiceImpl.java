package com.vo.service.impl;

import com.vo.bean.User;
import com.vo.dao.InfoDao;
import com.vo.service.InfoService;

public class InfoServiceImpl implements InfoService{
	
	private InfoDao infoDao;
	

	public InfoDao getInfoDao() {
		return infoDao;
	}


	public void setInfoDao(InfoDao infoDao) {
		this.infoDao = infoDao;
	}


	@Override
	public boolean updateUserById(int id, User user) {
		return infoDao.updateUserById(id, user);
	}


	@Override
	public boolean updateUserById(int id, String name, String oldname, String gender, String native_, String home, String zhengzhi, String marrage,
			String city, String county, String town, String birthday, String xueli, String xuewei, String school, String zhuanye, String biyeshijian,
			String phone, String email, String post, String jiangcheng, String peixun, String qita, boolean fullinfo) {
		
		return infoDao.updateUserById(id, name, oldname, gender, native_, home, zhengzhi, marrage, city, county, town, birthday, xueli, xuewei, school, zhuanye, biyeshijian, phone, email, post, jiangcheng, peixun, qita, fullinfo);
	}



}
