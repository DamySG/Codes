package com.vo.service.impl;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.Log;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.dao.LogDao;
import com.vo.service.LogService;

public class LogServiceImpl implements LogService{
	private LogDao logDao;
	

	public LogDao getLogDao() {
		return logDao;
	}


	public void setLogDao(LogDao logDao) {
		this.logDao = logDao;
	}


	@Override
	public List<Log> findLogs(int userId) {
		return logDao.findLogs(userId);
	}

	@Override
	public Apply findApplyByApplyId(int apply) {
		return logDao.findApplyByApplyId(apply);
	}
	
	@Override
	public Apply findApplyByLog(Log log) {
		return logDao.findApplyByLog(log);
	}


	@Override
	public boolean updateCost(String cost,int month, int applyId, int UserId) {
		return logDao.updateCost(cost,month, applyId, UserId);
	}


	@Override
	public boolean updateLost(String lost,int month, int applyId, int UserId) {
		return logDao.updateLost(lost,month, applyId, UserId);
	}


	@Override
	public List<Log> findLogByUserIdAndApplyId(int userId, int ApplyId) {
		return logDao.findLogByUserIdAndApplyId(userId, ApplyId);
	}


	@Override
	public LogTable findApplyLogByApplyId(int applyId) {
		return logDao.findApplyLogByApplyId(applyId);
	}


	@Override
	public boolean updateCost(Log log) {
		return logDao.updateCost(log);
	}
	
	@Override
	public boolean updateLost(Log log) {
		return logDao.updateLost(log);
	}
	
	@Override
	public boolean updateLog(Log log) {
		return logDao.updateLog(log);
	}


	@Override
	public boolean updateLogTable(int cost,int lost,int applyId,int userId) {
		return logDao.updateLogTable(cost,lost,applyId, userId);
	}


	@Override
	public boolean updateLog(int cost,int lost,int month,int applyId, int userId) {
		return logDao.updateLog(cost,lost,month,applyId, userId);
	}

}
