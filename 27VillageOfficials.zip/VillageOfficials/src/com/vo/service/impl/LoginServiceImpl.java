package com.vo.service.impl;

import com.vo.bean.Admin;
import com.vo.bean.User;
import com.vo.dao.LoginDao;
import com.vo.service.LoginService;

public class LoginServiceImpl implements LoginService{
	
	private LoginDao loginDao;

	public LoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(LoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public Admin adminLogin(String name, String password) {
		return loginDao.adminLogin(name, password);
	}

	@Override
	public User userLogin(String username, String password) {
		return loginDao.userLogin(username, password);
	}

	

}
