package com.vo.service.impl;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;
import com.vo.bean.User;
import com.vo.dao.AdminDao;
import com.vo.service.AdminService;

public class AdminServiceImpl implements AdminService {

	private AdminDao adminDao;

	public AdminDao getAdminDao() {
		return adminDao;
	}

	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	@Override
	public User findUserById(int id) {
		return adminDao.findUserById(id);
	}

	@Override
	public List<User> findUsers() {
		return adminDao.findUsers();
	}

	@Override
	public List<Apply> findApplyByUserId(int UserId) {
		return adminDao.findApplyByUserId(UserId);
	}

	@Override
	public Apply findApplyById(int id) {
		return adminDao.findApplyById(id);
	}

	@Override
	public List<Apply> findApplies() {
		return adminDao.findApplies();
	}

	@Override
	public List<LogTable> findLogLists() {
		return adminDao.findLogLists();
	}

	@Override
	public LogTable findLogById(int id) {
		return adminDao.findLogById(id);
	}

	@Override
	public boolean updateApply(int result, int id) {
		return adminDao.updateApply(result, id);
	}

	@Override
	public int BenKeNum() {
		return adminDao.BenKeNum();
	}

	@Override
	public int JiaoYuNum() {
		return adminDao.JiaoYuNum();
	}

	@Override
	public int ManNum() {
		return adminDao.ManNum();
	}

	@Override
	public int UserNum() {
		return adminDao.UserNum();
	}

	@Override
	public int WaiLianNum() {
		return adminDao.WaiLianNum();
	}

	@Override
	public int XuMuNum() {
		return adminDao.XuMuNum();
	}

	@Override
	public int ZhongzhiNum() {
		return adminDao.ZhongzhiNum();
	}

	@Override
	public int YanJiuShengNum() {
		return adminDao.YanJiuShengNum();
	}

	@Override
	public int ZhuanKeNum() {
		return adminDao.ZhuanKeNum();
	}

	@Override
	public int ApplyNum() {
		return adminDao.ApplyNum();
	}

	@Override
	public boolean createLog(LogTable logTable) {
		return adminDao.createLog(logTable);
	}

}
