package com.vo.service.impl;

import com.vo.dao.RegistryDao;
import com.vo.service.RegistryService;

public class RegistryServiceImpl implements RegistryService{
	
	private RegistryDao registryDao;
	

	public RegistryDao getRegistryDao() {
		return registryDao;
	}


	public void setRegistryDao(RegistryDao registryDao) {
		this.registryDao = registryDao;
	}


	@Override
	public boolean registry(String username, String password,boolean fullinfo) {
		return registryDao.registry(username, password,fullinfo);
	}

}
