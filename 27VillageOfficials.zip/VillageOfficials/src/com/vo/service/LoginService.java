package com.vo.service;

import com.vo.bean.Admin;
import com.vo.bean.User;

public interface LoginService {
	public User userLogin(String username,String password);
	
	public Admin adminLogin(String name,String password);
}
