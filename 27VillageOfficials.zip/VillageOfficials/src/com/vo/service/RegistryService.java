package com.vo.service;

public interface RegistryService {
	public boolean registry(String username,String password,boolean fullinfo);
}
