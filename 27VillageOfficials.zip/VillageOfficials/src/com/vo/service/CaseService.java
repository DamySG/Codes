package com.vo.service;

import java.util.List;

import com.vo.bean.Apply;
import com.vo.bean.LogTable;

public interface CaseService {
	public boolean updateApply(Apply apply);
	
	public boolean updateLog(LogTable logTable);
	
	public List<Apply> findUserCase(int userId);
	
	public Apply findCase(int id);
}
