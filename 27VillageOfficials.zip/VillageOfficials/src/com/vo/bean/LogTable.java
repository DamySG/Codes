package com.vo.bean;

public class LogTable {
	private Integer id;
	private String cost;
	private String lost;
	private Apply apply;
	private User user;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getLost() {
		return lost;
	}

	public void setLost(String lost) {
		this.lost = lost;
	}

	public Apply getApply() {
		return apply;
	}

	public void setApply(Apply apply) {
		this.apply = apply;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LogTable() {
	}

	public LogTable(Integer id, String cost, String lost, Apply apply, User user) {
		this.id = id;
		this.cost = cost;
		this.lost = lost;
		this.apply = apply;
		this.user = user;
	}

}
