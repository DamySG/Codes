package com.vo.bean;

public class Log implements java.io.Serializable {

	private static final long serialVersionUID = 1332299622515509147L;

	private Integer id;
	private String cost;
	private String lost;
	private int month;
	private Apply apply;
	private User user;

	public Log(Integer id, String cost, String lost, int month, Apply apply, User user) {
		this.id = id;
		this.cost = cost;
		this.lost = lost;
		this.month = month;
		this.apply = apply;
		this.user = user;
	}

	public Log() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getLost() {
		return lost;
	}

	public void setLost(String lost) {
		this.lost = lost;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public Apply getApply() {
		return apply;
	}

	public void setApply(Apply apply) {
		this.apply = apply;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}