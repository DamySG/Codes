package com.vo.bean;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Apply implements java.io.Serializable {

	private static final long serialVersionUID = 1716564636892193222L;

	private int id;
	private User user;
	private String subject;
	private String name;
	private Integer fund;
	private String location;
	private String stime;
	private Integer area;
	private String shuoming;
	private int pass;
	private Set<Log> logs = new HashSet<Log>(0);

	public Apply() {
	}

	public Apply(User user, String subject,String name, Integer fund, String location, String stime, Integer area, int pass) {
		this.user = user;
		this.name = name;
		this.fund = fund;
		this.location = location;
		this.stime = stime;
		this.area = area;
		this.pass = pass;
	}

	public Apply(User user, String subject,String name, Integer fund, String location, String stime, Integer area, String shuoming, int pass, Set<Log> logs) {
		this.user = user;
		this.name = name;
		this.fund = fund;
		this.location = location;
		this.stime = stime;
		this.area = area;
		this.shuoming = shuoming;
		this.pass = pass;
		this.logs = logs;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getFund() {
		return this.fund;
	}

	public void setFund(Integer fund) {
		this.fund = fund;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getStime() {
		return this.stime;
	}

	public void setStime(String stime) {
		this.stime = stime;
	}

	public Integer getArea() {
		return this.area;
	}

	public void setArea(Integer area) {
		this.area = area;
	}

	public String getShuoming() {
		return this.shuoming;
	}

	public void setShuoming(String shuoming) {
		this.shuoming = shuoming;
	}

	public int getPass() {
		return this.pass;
	}

	public void setPass(int pass) {
		this.pass = pass;
	}

	public Set<Log> getLogs() {
		return this.logs;
	}

	public void setLogs(Set<Log> logs) {
		this.logs = logs;
	}

}