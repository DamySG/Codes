package com.vo.bean;

import java.util.HashSet;
import java.util.Set;

public class User implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Integer id;
	private String username;
	private String password;
	private String name;
	private String oldname;
	private boolean gender;
	private String native_;
	private String home;
	private String zhengzhi;
	private String marrage;
	private String city;
	private String county;
	private String town;
	private String birthday;
	private String xueli;
	private String xuewei;
	private String school;
	private String zhuanye;
	private String biyeshijian;
	private String phone;
	private String email;
	private String post;
	private String jiangcheng;
	private String peixun;
	private String qita;
	private boolean fullinfo;
	private Set<Apply> applies = new HashSet<Apply>(0);
	private Set<Log> logs = new HashSet<Log>(0);

	public User() {
	}

	public User(String username, String password, boolean gender, String native_, String home, String zhengzhi, String marrage, String city, String county,
			String town, String birthday, String xueli, String school, String phone, String email) {
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.native_ = native_;
		this.home = home;
		this.zhengzhi = zhengzhi;
		this.marrage = marrage;
		this.city = city;
		this.county = county;
		this.town = town;
		this.birthday = birthday;
		this.xueli = xueli;
		this.school = school;
		this.phone = phone;
		this.email = email;
	}

	public User(String username, String password, String name, String oldname, boolean gender, String native_, String home, String zhengzhi, String marrage,
			String city, String county, String town, String birthday, String xueli, String xuewei, String school, String zhuanye, String biyeshijian,
			String phone, String email, String post, String jiangcheng, String peixun, String qita, boolean fullinfo, Set<Apply> applies,Set<Log> logs) {
		this.username = username;
		this.password = password;
		this.name = name;
		this.oldname = oldname;
		this.gender = gender;
		this.native_ = native_;
		this.home = home;
		this.zhengzhi = zhengzhi;
		this.marrage = marrage;
		this.city = city;
		this.county = county;
		this.town = town;
		this.birthday = birthday;
		this.xueli = xueli;
		this.xuewei = xuewei;
		this.school = school;
		this.zhuanye = zhuanye;
		this.biyeshijian = biyeshijian;
		this.phone = phone;
		this.email = email;
		this.post = post;
		this.jiangcheng = jiangcheng;
		this.peixun = peixun;
		this.qita = qita;
		this.applies = applies;
		this.fullinfo = fullinfo;
		this.logs = logs;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOldname() {
		return this.oldname;
	}

	public void setOldname(String oldname) {
		this.oldname = oldname;
	}

	public boolean getGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public String getNative_() {
		return this.native_;
	}

	public void setNative_(String native_) {
		this.native_ = native_;
	}

	public String getHome() {
		return this.home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getZhengzhi() {
		return this.zhengzhi;
	}

	public void setZhengzhi(String zhengzhi) {
		this.zhengzhi = zhengzhi;
	}

	public String getMarrage() {
		return this.marrage;
	}

	public void setMarrage(String marrage) {
		this.marrage = marrage;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return this.county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getTown() {
		return this.town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public String getBirthday() {
		return this.birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getXueli() {
		return this.xueli;
	}

	public void setXueli(String xueli) {
		this.xueli = xueli;
	}

	public String getXuewei() {
		return xuewei;
	}

	public void setXuewei(String xuewei) {
		this.xuewei = xuewei;
	}

	public String getSchool() {
		return this.school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public String getZhuanye() {
		return this.zhuanye;
	}

	public void setZhuanye(String zhuanye) {
		this.zhuanye = zhuanye;
	}

	public String getBiyeshijian() {
		return this.biyeshijian;
	}

	public void setBiyeshijian(String biyeshijian) {
		this.biyeshijian = biyeshijian;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPost() {
		return this.post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getJiangcheng() {
		return this.jiangcheng;
	}

	public void setJiangcheng(String jiangcheng) {
		this.jiangcheng = jiangcheng;
	}

	public String getPeixun() {
		return this.peixun;
	}

	public void setPeixun(String peixun) {
		this.peixun = peixun;
	}

	public String getQita() {
		return this.qita;
	}

	public void setQita(String qita) {
		this.qita = qita;
	}

	public boolean isFullinfo() {
		return fullinfo;
	}

	public void setFullinfo(boolean fullinfo) {
		this.fullinfo = fullinfo;
	}

	public Set<Apply> getApplies() {
		return this.applies;
	}

	public void setApplies(Set<Apply> applies) {
		this.applies = applies;
	}

	public Set<Log> getLogs() {
		return logs;
	}

	public void setLogs(Set<Log> logs) {
		this.logs = logs;
	}
	
	

}