/*
Navicat MySQL Data Transfer

Source Server         : vo
Source Server Version : 50132
Source Host           : localhost:3306
Source Database       : villageofficials

Target Server Type    : MYSQL
Target Server Version : 50132
File Encoding         : 65001

Date: 2015-04-18 21:09:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
`id`  int(12) NOT NULL AUTO_INCREMENT ,
`name`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`password`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2

;

-- ----------------------------
-- Records of admin
-- ----------------------------
BEGIN;
INSERT INTO `admin` VALUES ('1', 'admin', 'admin');
COMMIT;

-- ----------------------------
-- Table structure for `apply`
-- ----------------------------
DROP TABLE IF EXISTS `apply`;
CREATE TABLE `apply` (
`id`  int(12) NOT NULL AUTO_INCREMENT ,
`subject`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`name`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`fund`  bigint(15) NOT NULL ,
`location`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`stime`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`area`  bigint(20) NOT NULL ,
`shuoming`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`pass`  int(12) NOT NULL ,
`userId`  int(12) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK58B836E8E9A77E7` USING BTREE (`userId`) 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2

;

-- ----------------------------
-- Records of apply
-- ----------------------------
BEGIN;
INSERT INTO `apply` VALUES ('1', '种植业', '吃大餐', '1000', '德得轩', '1990-1', '1000', '我们的目标是，吃回本', '1', '5');
COMMIT;

-- ----------------------------
-- Table structure for `log`
-- ----------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
`id`  int(12) NOT NULL AUTO_INCREMENT ,
`cost`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`lost`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`month`  int(12) NOT NULL ,
`applyId`  int(12) NOT NULL ,
`userId`  int(12) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`applyId`) REFERENCES `apply` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK1A3441D16D541` USING BTREE (`applyId`) ,
INDEX `FK1A3448E9A77E7` USING BTREE (`userId`) 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=1

;

-- ----------------------------
-- Records of log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for `logtable`
-- ----------------------------
DROP TABLE IF EXISTS `logtable`;
CREATE TABLE `logtable` (
`id`  int(12) NOT NULL AUTO_INCREMENT ,
`cost`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`lost`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`applyId`  int(12) NOT NULL ,
`userId`  int(12) NOT NULL ,
PRIMARY KEY (`id`),
FOREIGN KEY (`applyId`) REFERENCES `apply` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
INDEX `FK7926030A1D16D541` USING BTREE (`applyId`) ,
INDEX `FK7926030A8E9A77E7` USING BTREE (`userId`) 
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=2

;

-- ----------------------------
-- Records of logtable
-- ----------------------------
BEGIN;
INSERT INTO `logtable` VALUES ('1', null, null, '1', '5');
COMMIT;

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
`id`  int(12) NOT NULL AUTO_INCREMENT ,
`username`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`password`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,
`name`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`oldname`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`gender`  tinyint(1) NULL DEFAULT NULL ,
`native`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`home`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`zhengzhi`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`marrage`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`city`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`county`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`town`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`birthday`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`xueli`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`xuewei`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`school`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`zhuanye`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`biyeshijian`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`phone`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`email`  varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`post`  varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`jiangcheng`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`peixun`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`qita`  varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,
`fullinfo`  tinyint(1) NOT NULL ,
PRIMARY KEY (`id`)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci
AUTO_INCREMENT=6

;

-- ----------------------------
-- Records of user
-- ----------------------------
BEGIN;
INSERT INTO `user` VALUES ('5', 'aa', '11', '我是用户', '', '0', '汉族', '长治', '团员', '未婚', '长治市', '城区', '东街街办', '1998-3', '本科', '学士', '长治学院', '软件工程', '2000-6', '11111111111', '111111111', '111111', '表现良好', '经过专业培训', '', '1');
COMMIT;

-- ----------------------------
-- Auto increment value for `admin`
-- ----------------------------
ALTER TABLE `admin` AUTO_INCREMENT=2;

-- ----------------------------
-- Auto increment value for `apply`
-- ----------------------------
ALTER TABLE `apply` AUTO_INCREMENT=2;

-- ----------------------------
-- Auto increment value for `log`
-- ----------------------------
ALTER TABLE `log` AUTO_INCREMENT=1;

-- ----------------------------
-- Auto increment value for `logtable`
-- ----------------------------
ALTER TABLE `logtable` AUTO_INCREMENT=2;

-- ----------------------------
-- Auto increment value for `user`
-- ----------------------------
ALTER TABLE `user` AUTO_INCREMENT=6;
