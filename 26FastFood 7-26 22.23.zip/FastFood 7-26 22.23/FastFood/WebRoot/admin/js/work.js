function $$(id){
	return document.getElementById(id);
}

//全选和全不选
function clickMe(flag){
	$(".checkBox").each(
		function(i,obj){
			$(obj).attr("checked",flag);
		}
	);
}

//鼠标移入
function changeto(obj){
	$(obj).css("background-color","#FFFFF0");
}
//鼠标移出
function changeback(obj){
	$(obj).css("background-color","#FFFFFF");
}

//新建管理员
function xjManager(){
	location="/FastFood/admin/view/addManager.jsp";
}

//新建会员
function xjUser(){
	location="/FastFood/admin/view/addUser.jsp";
}

//判断登录账号非空  + 合法
function yzName(){
	var Name=$$("userName");
	var cs = /^[a-zA-Z0-9_]{2,20}$/;
	if(Name.value==""){
		$$("yzUserName").innerHTML="<font color='red'>账户名称不能为空!</font>";
		return false;
	}else if(!cs.test(Name.value)) {
		$$("yzUserName").innerHTML="<font color='red'>账户名称必须由2-20个英文字母或数字组成!</font>";
		return false;
	}
	$$("yzUserName").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}


//密码非空验证+确认验证
function yzPwd(){
	var pwd=$$("pwd");
	var pass = /^[a-zA-Z0-9_]{5,20}$/;
	if(pwd.value==""){
		$$("yzPwd").innerHTML="<font color='red'>账户密码不能为空!</font>";
		return false;
	}else if(!pass.test(pwd.value)) {
		$$("yzPwd").innerHTML="<font color='red'>账户密码必须由5-20个英文字母或数字组成!</font>";
		return false;
	}	
	$$("yzPwd").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//确认密码的验证
function yzRPwd(){
	var pwd=$$("pwd");
	var Rpwd=$$("Rpwd");
	if(Rpwd.value!=pwd.value){
		$$("yzRpwd").innerHTML="<font color='red'>两次密码不一致!</font>";
		return false;
	}
	$$("yzRpwd").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}


//验证电子邮件 非空 + 合法
function yzEmail(){
	var email=$$("email");
	if(email.value!=""){
		if(email.value.indexOf("@",0)== -1 || email.value.indexOf(".",0)==-1){
			$$("yzEmail").innerHTML="<font color='red'>电子邮件格式不正确，请输入正确的电子邮件 </font>";
			return false;
		}
	}
	$$("yzEmail").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}


//管理员验证电子邮件 非空 + 合法
function yzMEmail(){
	var email=$$("email");
	if(email.value==""){
		$$("yzEmail").innerHTML="<font color='red'>请输入电子邮件号!</font>";
		return false;
	}else if(email.value.indexOf("@",0)== -1 || email.value.indexOf(".",0)==-1){
		$$("yzEmail").innerHTML="<font color='red'>电子邮件格式不正确，请输入正确的电子邮件 </font>";
		return false;
	}
	$$("yzEmail").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//联系电话非空
function yzPhone(){
	var phone=$$("telephone");
	if(phone.value==""){
		$$("yzPhone").innerHTML="<font color='red'>请填写联系电话!</font>";
			return false;
		}
		$$("yzPhone").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//联系地址非空 + 合法
function yzAddress(){
	var address=$$("address");
	if(address.value==""){
		$$("yzAddress").innerHTML="<font color='red'>请填写联系地址!</font>";
			return false;
		}
		$$("yzAddress").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}


