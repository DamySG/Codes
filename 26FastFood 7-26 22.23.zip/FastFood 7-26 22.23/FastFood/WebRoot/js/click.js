//关闭网站
function f_Close(){
	window.close();	
}

//打开首页
function homeShow(){
	location="/FastFood/foodInfo.do?p=findFoodInfoById&bigTypeId=1";
}
//打开注册页面
function registerShow(){
	location="/FastFood/view/register.jsp";
}
//打开订单查询页面
function orderSelectShow(){
	location="/FastFood/view/order/orderSelect.jsp";
}

//打开每周菜谱页面
function menuShow(){
	location="/FastFood/view/menu.jsp";
}

//打开饮食文化页面
function abstinentShow(){
	location="/FastFood/view/abstinent.jsp";
}

//打开留言页面
function messageShow(){
	location="/FastFood/message.do?p=findAllMessage&msid=1&page=1";
}

