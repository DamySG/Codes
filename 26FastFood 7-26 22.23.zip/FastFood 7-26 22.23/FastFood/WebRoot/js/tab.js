function $$(id){
	return document.getElementById(id);
}

//显示商品信息
function tabShow(id){
	 if(id==3){
		$$("mytab1").style.display="none";
		$$("td1").style.display="none";
		location="/FastFood/foodInfo.do?p=findFoodInfoById&bigTypeId="+id;
	 }else{
		location="/FastFood/foodInfo.do?p=findFoodInfoById&bigTypeId="+id;
		if($$("mytab"+id).style.display=="none"){
			$$("mytab"+id).style.display="block";
			$$("mytab3").style.display="none";
			$$("td1").style.display="block";
			$$("td3").style.display="none";
		}
	 }
  }

//判断登录账号非空  + 合法
function yzUserName(){
	var userName=$$("userName");
	var cs = /^[a-zA-Z0-9_]{3,20}$/;
	if(userName.value==""){
		$$("yzName").innerHTML="<font color='red'>登录账号不能为空</font>";
		return false;
	}else if(!cs.test(userName.value)) {
		$$("yzName").innerHTML="<font color='red'>登录账号必须由3-20个英文字母或数字组成</font>";
		return false;
	}
	$$("yzName").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//判断登录密码非空  + 合法
function yzUserPass(){
	var userPass=$$("userPass");
	var cs = /^[a-zA-Z0-9_]{5,20}$/;
	if(userPass.value==""){
		$$("yzPass").innerHTML="<font color='red'>登录密码不能为空</font>";
		return false;
	}else if(!cs.test(userPass.value)) {
		$$("yzPass").innerHTML="<font color='red'>登录密码必须由5-20个英文字母或数字组成</font>";
		return false;
	}
	$$("yzPass").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//确认密码  + 合法
function yzRepeatPass(){
	var userPass=$$("userPass");
	var repeatPass=$$("repeatPass");
	if(repeatPass.value==""){
		$$("yzrPass").innerHTML="<font color='red'>登录密码不能为空</font>";
		return false;
	}else if(repeatPass.value!=userPass.value){
		$$("yzrPass").innerHTML="<font color='red'>重复密码不一致</font>";
		return false;
	}
	$$("yzrPass").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//验证电子邮件 非空 + 合法
function yzMyEail(){
	var myEail=$$("myEail");
	if(myEail.value==""){
		$$("yzEail").innerHTML="<font color='red'>电子邮件不能为空</font>";
		return false;
	}else if(myEail.value.indexOf("@",0)== -1 || myEail.value.indexOf(".",0)==-1){
		$$("yzEail").innerHTML="<font color='red'>电子邮件格式不正确，请输入正确的电子邮件 </font>";
		return false;
	}
	$$("yzEail").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

function changeCity(){
	$$("tdcity").style.display="block";
	var proIndex=$$("pro").value;
	var cityList=new Array();   // 创建地区的数组	     				     			
	cityList['市区']=["--市区--"];
	cityList['湖南']=["长沙市","株洲市","衡阳市"];
	cityList['湖北']=["襄樊市","荆州市","武汉市"];
	cityList['广东']=["广州市","东莞市","中山市"];  		
		
	var newOption;   //声明一个变量保存新增城市
	$$("city").length=0;    //将省的选项设置为0
	for(var j in cityList[proIndex]){
		newOption = new Option(cityList[proIndex][j],cityList[proIndex][j]);
		$$("city").options.add(newOption);
	}
}

//判断标题非空  + 合法
function yzTitle(){
	var title=$$("title");
	var ti = /^([0-9a-zA-Z]|[\u4e00-\u9fa5]){2,30}$/;
	if(title.value==""){
		$$("yztitle").innerHTML="<font color='red'>标题不能为空!</font>";
		return false;
	}else if(!ti.test(title.value)) {
		$$("yztitle").innerHTML="<font color='red'>标题必须由5-30个英文字母或数字组成!</font>";
		return false;
	}
	$$("yztitle").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//判断名字非空  + 合法
function yzName(){
	var name=$$("userName");
	var na = /^([0-9a-zA-Z]|[\u4e00-\u9fa5]){2,20}$/;
	if(name.value==""){
		$$("yzName").innerHTML="<font color='red'>名字不能为空!</font>";
		return false;
	}else if(!na.test(name.value)) {
		$$("yzName").innerHTML="<font color='red'>请输入任意20字符以内的昵称!</font>";
		return false;
	}
	$$("yzName").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//判断邮箱的合法
function yzEmail(){
	var email=$$("email");
	var en = /^\w+@+\w+\.\w+$/;
	if(email.value!=""){
		if(!en.test(email.value)) {
			$$("yzEmail").innerHTML="<font color='red'>邮箱账号不正确!</font>";
			return false;
		}	
		$$("yzEmail").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
		return true;
	}else if(email.value==""){
		return true;
	}	
	
}

//判断留言内容的非空 
function yzMemo(){
	var memo=$$("memo");
	if(memo.value=="") {
		$$("yzMemo").innerHTML="<font color='red'>留言内容不能为空!</font>";
		return false;
	}
	$$("yzMemo").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//判断评论内容的非空 
function plMemo(){
	var memo=$$("memo");
	if(memo.value=="") {
		$$("yzMemo").innerHTML="<font color='red'>留言内容不能为空!</font>";
		return false;
	}
	$$("yzMemo").innerHTML="<img src=\"/FastFood/images/note_ok.gif\">";
	return true;
}

//订餐价格与菜种类
function changeCai(){
	var cai=$$("cai").value;
	switch(cai){
		case '8':
			$$("div1").style.display="block";
			$$("div2").style.display="none";
			$$("div3").style.display="none";
			break;
		case '12':
			$$("div1").style.display="none";
			$$("div2").style.display="block";
			$$("div3").style.display="none";
			break;
		case '20':
			$$("div1").style.display="none";
			$$("div2").style.display="none";
			$$("div3").style.display="block";
			break;
	}
}

//个人中心
function clickVip(id){
	switch(id){
		case '1':
			$$("tab1").style.display="block";
			$$("tab2").style.display="none";
			$$("tab3").style.display="none";
			break;
		case '2':
			$$("tab1").style.display="none";
			$$("tab2").style.display="block";
			$$("tab3").style.display="none";
			break;
		case '3':
			$$("tab1").style.display="none";
			$$("tab2").style.display="none";
			$$("tab3").style.display="block";
			break;
	}
}