  //***********************************************用enter键替换tab键
  function changFocus(){ 
     if(event.keyCode==13&&
	    event.srcElement.type!="button"&&
		event.srcElement.type!="submit"&&
		event.srcElement.type!="reset"&&
		event.srcElement.type!="textarea"&&
		event.srcElement.type!=""){
	    event.keyCode=9;
	 }
  }
  document.onkeydown=changFocus; //通过document的onkeydown 事件调用方法