package com.ff.services;

import java.util.Date;
import java.util.List;

import com.ff.dao.FoodinfoDAO;
import com.ff.dao.FoodtypeDAO;
import com.ff.dao.ManagerDAO;
import com.ff.dao.OrdersDAO;
import com.ff.dao.OrdersdetailDAO;
import com.ff.dao.UserinfoDAO;
import com.ff.iservices.IOrderService;
import com.hsg.pojos.Orders;

/**
 * 订单信息service
 * @author hushiguo
 *
 */
public class OrderService implements IOrderService {
   private OrdersDAO ordersDao;
   private OrdersdetailDAO ordersDetailDao;
   private UserinfoDAO userInfoDao;
   private ManagerDAO managerDao;
   private FoodinfoDAO foodInfoDao;
   private FoodtypeDAO foodTypeDao;
   
	public void setOrdersDao(OrdersDAO ordersDao) {
		this.ordersDao = ordersDao;
	}
	public void setOrdersDetailDao(OrdersdetailDAO ordersDetailDao) {
		this.ordersDetailDao = ordersDetailDao;
	}
	public void setUserInfoDao(UserinfoDAO userInfoDao) {
		this.userInfoDao = userInfoDao;
	}
	public void setManagerDao(ManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	public void setFoodInfoDao(FoodinfoDAO foodInfoDao) {
		this.foodInfoDao = foodInfoDao;
	}
	public void setFoodTypeDao(FoodtypeDAO foodTypeDao) {
		this.foodTypeDao = foodTypeDao;
	}
   
	/**
	 * 修改订单信息
	 * @param orderId
	 * @param order
	 */
	public void updateOrderInfo(String orderId,Orders order){
	  Orders orders=ordersDao.findById(orderId);
      if(orders!=null){
		 orders.setOName(order.getOName());
		 orders.setOSendaddress(order.getOSendaddress());
		 orders.setOPhone(order.getOPhone());
		 orders.setOPost(order.getOPost());
         orders.setOCheck(order.getOCheck());
         orders.setOEmail(order.getOEmail());
         orders.setOJiezhang(order.getOJiezhang());
         orders.setOSendtype(order.getOSendtype());
      }
		
	}
   
	/**
	 *查询所有的订单信息
	 * @return
	 */
	public List<Orders> findAllOrders(){
		return ordersDao.findAll();
	}
   

	/**
	 *查询所有的订单信息
	 * @return
	 */
	public Orders findAllOrders(String ordersId){
		return ordersDao.findById(ordersId);
	}
   
    /**
     * 根据订单编号和接收人查询订单信息
     * ordersId  订单编号
     * name  收货人姓名
     * userid 当前登录用户编号
     */
	public Orders findAllOrders(String ordersId,String name,Integer userId){
		String hql="";
		List<Orders> list=null;
		if(ordersId!=null&&name!=null&&!name.equals("")&&userId!=null){
			 hql="select o from Orders o" +
				"  where  o.OId =? " +
				"  and o.OName=?  " +
				"  and o.userinfo.userid=?" +
				"  and o.OState=1 " +
				"  order by o.OId desc";
	        list=ordersDao.queryByHql(hql,ordersId,name,userId);
			return list!=null&&list.size()>0?list.get(0):null;
		}else if(ordersId!=null&&userId!=null){
			 hql="select o from Orders o" +
				"  where  o.OId =? " +
				"  and o.userinfo.userid=?" +
				"  and o.OState=1 " +
				"  order by o.OId desc";
	        list=ordersDao.queryByHql(hql,ordersId,userId);
			return list!=null&&list.size()>0?list.get(0):null;
		
		}else{
			return ordersDao.findById(ordersId);
		}
	}
	
	
	
	/**
	 * 获得一个订单号
	 * @return
	 */
	public String  getOrderId(){
		Date d=new Date();
		String hql="select o from Orders o" +
				"  where  rownum=1 " +
				"  and substr(o.OId,1,8)=TO_CHAR(sysdate,'YYYYMMDD') " +
				"  and o.OState=1 " +
				"  order by o.OId desc";
		String oid="0001";
		List<Orders> list=ordersDao.queryByHql(hql);
		//如果当天有记录，则+1
		if(list!=null&&list.size()>0){
			System.out.println(Long.parseLong(list.get(0).getOId())+1);
			return (Long.parseLong(list.get(0).getOId())+1)+"";
			
		}else{  //如果当天没有记录 ，则新增一条 
			System.out.println(d.getYear()+1900);
			System.out.println(d.getMonth()+1);
			System.out.println(d.getDate());
			String month="";
			String date="";
			
			//如果月<10  则前面加0  例：09
			if(d.getMonth()<10){
				month="0"+(d.getMonth()+1);
			}else{
				month=""+(d.getMonth()+1);
			}
			
			//如果日<10  则前面加0  例：09 
			if(d.getDate()<10){
				date="0"+(d.getDate());
			}else{
				date=""+(d.getDate());
			}
			System.out.println(month);
			System.out.println(date);
			System.out.println((d.getYear()+1900)+month+date+oid);
			return (""+(d.getYear()+1900)+month+date+oid);   //比如：201107130001
		}
	}
	
	
   
	/**
	 * 增加订单信息
	 * @param order
	 */
    public void addOrders(Orders order){
    	 ordersDao.save(order);
    }
	
	
}
