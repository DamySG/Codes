package com.ff.services;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ff.dao.AdviceDAO;
import com.ff.dao.FoodinfoDAO;
import com.ff.dao.UserinfoDAO;
import com.ff.iservices.IAdviceService;
import com.hsg.pojos.Advice;
import com.hsg.pojos.Message;
import com.hsg.pojos.PageBean;


/**
 * 评论
 * @author hushiguo
 *
 */
public class AdviceService implements IAdviceService {
    private AdviceDAO adviceDao;
    private FoodinfoDAO foodInfoDao;
    private UserinfoDAO userInfoDao;
	
    public void setAdviceDao(AdviceDAO adviceDao) {
		this.adviceDao = adviceDao;
	}
	public void setFoodInfoDao(FoodinfoDAO foodInfoDao) {
		this.foodInfoDao = foodInfoDao;
	}
	public void setUserInfoDao(UserinfoDAO userInfoDao) {
		this.userInfoDao = userInfoDao;
	}
    
	/**
	 * 查询所有评论
	 * @return
	 */
    public List<Advice> findAllAdvice(){
    	return adviceDao.findAll();
    }
    
    
    
    /**
	 * 根据评论编号查询所有评论
	 * @return
	 */
    public Advice findAdviceById(Integer adviceId){
    	return adviceDao.findById(adviceId);
    }
    
    
    /**
	 * 根据商品编号分页查询所有评论
	 * @return
	 */
    public PageBean findAdviceByfoodId(Integer currentPage,Integer foodId){
    	PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=5;  //每页条数
    	//得到总记录
    	String hql1="select count(*) from Advice a where a.foodinfo.foodid=? and a.adState=1";
    	totalCount= (Integer) adviceDao.queryByUnique(hql1, foodId);
        
    	String hql2="select a from Advice a " +
    			" where  a.adState=1" +
    			" and a.foodinfo.foodid=?" +
    			" order by a.adId desc";
    	
    	//得到总信息
        List<Advice> advicesList=adviceDao.queryByPage(hql2, currentPage, pageSize, foodId);
        if(advicesList!=null){
        	 for (Advice advice : advicesList) {
     			System.out.println(advice.getAdContent());
     		}
        }
       
    	//得到总页数  10/2  5页
        Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        	totalCount/pageSize+1;
    	//上一页
        Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
        Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(advicesList);
        return pb;
    }

    
    /**
	 * 分页查询所有评论信息
	 * @return
	 */
    public PageBean findAllAdvice(Integer currentPage){
    	PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	//得到总记录
    	String hql1="select count(*) from Advice a where a.adState=1";
    	totalCount= (Integer) adviceDao.queryByUnique(hql1);
        
    	String hql2="select a from Advice a " +
    			" where a.adState=1" +
    			" order by a.adId desc";
    	
    	//得到总信息
        List<Advice> advicesList=adviceDao.queryByPage(hql2, currentPage, pageSize);
        if(advicesList!=null){
        	 for (Advice advice : advicesList) {
     			System.out.println(advice.getAdContent());
     		}
        }
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(advicesList);
        return pb;
    }
    
	/**
	 * 根据标题分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByName(Integer currentPage,String foodName){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Advice a where a.adState=1 and a.foodinfo.foodname like ?";
    	totalCount = (Integer) adviceDao.queryByUnique(hql1,"%"+foodName+"%");
    	
    	String hql2="select a from Advice a " +
		" where a.adState=1" +
		" and a.foodinfo.foodname like ?" +
		" order by a.adId desc";
    	
    	//得到总信息
    	List<Advice> adviceList = adviceDao.queryByPage(hql2, currentPage, pageSize,"%"+foodName+"%");
    	
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(adviceList);
    	return pb;
	}
    
	
	/**
	 * 根据时间分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByDate(Integer currentPage,Date startDate, Date stopDate){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Advice a where a.adState=1 " +
		" and a.adDate " +
		" between ? and ? ";
    	totalCount = (Integer) adviceDao.queryByUnique(hql1,startDate,stopDate);
 	
    	String hql2="select a from Advice a " +
		" where a.adState=1" +
		" and a.adDate" +
		" between ? and ?" +
		" order by a.adId desc";
    	
    	//得到总信息
    	List<Advice> adviceList = adviceDao.queryByPage(hql2, currentPage, pageSize,startDate,stopDate);
    	
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(adviceList);
    	return pb;
	}
    
	/**
	 * 根据msId删除用户
	 * @param msId
	 */
	public void deleteById(Integer adId){
		Advice advice= adviceDao.findById(adId);
		if(advice!=null){
			advice.setAdState(adId);
		}
	}
    
    
    /**
     * 根据商品添加评论信息
     * @param Advice
     */
    public void addAdvice(Advice Advice){
    	adviceDao.save(Advice);
    }
}
