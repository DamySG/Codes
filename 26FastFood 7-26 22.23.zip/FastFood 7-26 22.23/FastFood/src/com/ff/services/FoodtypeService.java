package com.ff.services;

import java.util.List;

import com.ff.dao.FoodinfoDAO;
import com.ff.dao.FoodtypeDAO;
import com.ff.iservices.IFoodtypeService;
import com.hsg.pojos.Foodtype;

public class FoodtypeService implements IFoodtypeService {

	private FoodinfoDAO foodInfoDao;
	private FoodtypeDAO foodTypeDao;
	
	
	public void setFoodInfoDao(FoodinfoDAO foodInfoDao) {
		this.foodInfoDao = foodInfoDao;
	}
	public void setFoodTypeDao(FoodtypeDAO foodTypeDao) {
		this.foodTypeDao = foodTypeDao;
	}
	
	/**
	 * 查询所有商品类别信息
	 * @return
	 */
	public List<Foodtype> findAllFoodType(){
		return foodTypeDao.findAll();
	}
	
	
	/**
	 * 查询所有商品类别信息
	 * @return
	 */
	public List<Foodtype> findAllFoodType2(){
		String hql="from Foodtype t where  t.FState=1 order by t.FTypeid desc ";
		return foodTypeDao.queryByHql(hql);
	}
	
	
	/**
	 * 根据编号查询
	 * @param typeId
	 * @return
	 */
	public Foodtype findFoodTypeById(Integer typeId){
		return foodTypeDao.findById(typeId);
	}
	
	/**
	 * 根据名称查询
	 * @param typeId
	 * @return
	 */
	public Foodtype findFoodTypeByName(String typeName){
		String hql="from Foodtype t where t.FTypename=? and t.FState=1";
		List<Foodtype> list= foodTypeDao.queryByHql(hql, typeName);
		return list!=null&&list.size()>0?list.get(0):null;
	}
	
	/**
	 * 根据大类型编号查询
	 * 1  自选订餐
	 * 2  固定套餐
	 * 3  组合套餐
	 * @param typeId
	 * @return
	 */
	public List<Foodtype> findFoodTypeByBigId(Integer bigTypeId){
		String hql="select f  from Foodtype f where f.FBigtype=? and f.FState=1 order by  f.FTypeid desc";
		return foodTypeDao.queryByHql(hql, bigTypeId);
	}
	
}
