package com.ff.services;

import java.util.List;
import java.util.Set;

import com.ff.dao.ManagerDAO;
import com.ff.dao.ManagerroleDAO;
import com.ff.dao.TreemenuDAO;
import com.ff.iservices.ITreeMenuService;
import com.hsg.pojos.Managerrole;
import com.hsg.pojos.Treemenu;

public class TreeMenuService implements ITreeMenuService {
   private TreemenuDAO treeMenuDao;
   private ManagerDAO managerDao;
   private ManagerroleDAO managerRoleDao;
   
   
	public void setManagerRoleDao(ManagerroleDAO managerRoleDao) {
	this.managerRoleDao = managerRoleDao;
    }
	public void setTreeMenuDao(TreemenuDAO treeMenuDao) {
		this.treeMenuDao = treeMenuDao;
	}
	public void setManagerDao(ManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	   
	/**
	 * 查询父级菜单
	 * @return
	 */
	public List<Treemenu> findParentMenu(){
		String hql = "select t from Treemenu t where t.treeprentid=0  order by t.treemenuid";
		List<Treemenu> list=treeMenuDao.queryByHql(hql);
		return list!=null&&list.size()>0?list:null;
	}
	
		/**
	 * 根据角色编号查询父级菜单
	 * @return
	 */
	public Set<Treemenu> findMenuByRoleId(Integer roleId){
		Managerrole role=managerRoleDao.findById(roleId);
	    Set<Treemenu> tree=role.getTreemenus();
	    return tree;
	}
	
	
	/**
	 * 根据管理员编号查询所有树形菜单
	 * @return
	 */
	public List<Treemenu> findTreeMenuBymgId(Integer managerId){
		String hql = "select t from Treemenu t" +
						" inner join t.managerroles r " +
						" inner join r.managers m " +
						" where m.mgId=? order by t.treemenuid";
		List<Treemenu> list=treeMenuDao.queryByHql(hql, managerId);
		if(list!=null){
			return list;
		}else{
			return null;
		}
	}	
	
	
		/**
	 * 查询父级菜单下的所有子菜单
	 * @return
	 */
	public List<Treemenu> findBytmId(Integer treeMenuId){
		String hql = "select t from Treemenu t where t.treeprentid=?  order by t.treemenuid";
		List<Treemenu> list=treeMenuDao.queryByHql(hql, treeMenuId);
		if(list!=null){
			return list;
		}else{
			return null;
		}
	}
	
	
	/**
	 * 查询所有树形菜单
	 * @return
	 */
	public List<Treemenu> findAllTreeMenu(){
		return treeMenuDao.findAll();
	}
	
	
	/**
	 * 根据编号查询所有树形菜单
	 * @return
	 */
	public Treemenu findTreeMenuById(Integer treeMenuId){
		return treeMenuDao.findById(treeMenuId);
	}
   
	
}
