package com.ff.services;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.ff.dao.FoodinfoDAO;
import com.ff.dao.FoodtypeDAO;
import com.ff.dao.ManagerDAO;
import com.ff.dao.OrdersDAO;
import com.ff.dao.OrdersdetailDAO;
import com.ff.dao.UserinfoDAO;
import com.ff.iservices.IOrderDetailService;
import com.ff.iservices.IOrderService;
import com.hsg.pojos.FoodInfoBean;
import com.hsg.pojos.Foodinfo;
import com.hsg.pojos.Orders;
import com.hsg.pojos.Ordersdetail;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Userinfo;

/**
 * 详细订单信息service
 * @author hushiguo
 *
 */
public class OrderDetailService implements IOrderDetailService  {
   private OrdersDAO ordersDao;
   private OrdersdetailDAO ordersDetailDao;
   private UserinfoDAO userInfoDao;
   private ManagerDAO managerDao;
   private FoodinfoDAO foodInfoDao;
   private FoodtypeDAO foodTypeDao;
   
	public void setOrdersDao(OrdersDAO ordersDao) {
		this.ordersDao = ordersDao;
	}
	public void setOrdersDetailDao(OrdersdetailDAO ordersDetailDao) {
		this.ordersDetailDao = ordersDetailDao;
	}
	public void setUserInfoDao(UserinfoDAO userInfoDao) {
		this.userInfoDao = userInfoDao;
	}
	public void setManagerDao(ManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	public void setFoodInfoDao(FoodinfoDAO foodInfoDao) {
		this.foodInfoDao = foodInfoDao;
	}
	public void setFoodTypeDao(FoodtypeDAO foodTypeDao) {
		this.foodTypeDao = foodTypeDao;
	}
   
	
	/**
	 * 删除订单信息  (即将订单状态和详细订单状态修改为2)
	 * @param orderId
	 */
	public void deleteOrderInfo(String orderId){
		String hql="select d " +
				"  from Ordersdetail d" +
				"  where d.odState=1 " +
				"  and d.orders.OId =?";
		List<Ordersdetail> detail=ordersDetailDao.queryByHql(hql, orderId);
		if(detail!=null){
			for (Ordersdetail d : detail) {
				 d.setOdState(2);  //修改详细订单的状态
				 d.getOrders().setOState(2);//修改订单的状态
			}
		}
	}
	
	
	/**
	 * 根据条件分页查询订单信息
	 * @return
	 */
	public PageBean findDetailByPage(Integer currentPage,Integer i,String orderId, 
	    Date startDate, Date stopDate, Integer OCheck,Integer OJiezhang){
		//分页对象
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	String hql1="";  //获得总条数
    	String hql2="";  //获得总信息
    	//得到总信息
    	List<Ordersdetail> detailList=null;
    	//如果i==0 默认查询所有  否则根据条件查询
    	if(i==0){
    		//得到总条数
        	hql1="select count(*) from Ordersdetail d where d.odState=1";
        	totalCount = (Integer) ordersDetailDao.queryByUnique(hql1);
        	//得到所有信息
            hql2="select d from Ordersdetail d " +
    		" where  d.odState=1" +
    		" order by d.orders.OId desc";
        	//得到总信息
            detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize);
    	}else{
    		//如果订单不为空  则根据订单编号查询
    		if(orderId!=null&&!orderId.equals("")){
    	   		//得到总条数
            	hql1="select count(*) from Ordersdetail d where d.odState=1 and d.orders.OId like ?";
            	totalCount = (Integer) ordersDetailDao.queryByUnique(hql1,"%"+orderId+"%");
            	//得到所有信息
                hql2="select d from Ordersdetail d " +
        		" where  d.odState=1 " +
        		" and d.orders.OId like ?" +
        		" order by d.orders.OId desc";
            	//得到总信息
                detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize,"%"+orderId+"%");
    		}else if(startDate!=null&&!startDate.equals("")
    				&&stopDate!=null&&!stopDate.equals("")){ //开始日期和结束日期不为空 则根据日期查询
    			//得到总条数
            	hql1="select count(*) " +
            		 " from Ordersdetail d " +
            		 " where d.odState=1 " +
            		 " and trunc(d.orders.OOrderdate) " +
            		 " between ? and ?";
            	totalCount = (Integer) ordersDetailDao.queryByUnique(hql1,startDate,stopDate);
            	//得到所有信息
                hql2="select d from Ordersdetail d " +
        		" where  d.odState=1 " +
        		" and trunc(d.orders.OOrderdate) between ? and ? " +
        		" order by d.orders.OId desc";
            	//得到总信息
                detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize,startDate,stopDate);
    		}else if(OCheck!=null&&OJiezhang!=null){ //查询未审核并且未发货的订单，即未处理
    			//得到总条数
            	hql1="select count(*) " +
            		 " from Ordersdetail d " +
            		 " where d.odState=1 " +
            		 " and d.orders.OCheck=? " +
            		 " and d.orders.OJiezhang=? ";
            	totalCount =(Integer)ordersDetailDao.queryByUnique(hql1,OCheck,OJiezhang);
            	//得到所有信息
                hql2="select d from Ordersdetail d " +
        		" where  d.odState=1 " +
        		" and  d.orders.OCheck=?" +
        		" and d.orders.OJiezhang=?" +
        		" order by d.orders.OId desc";
            	//得到总信息
                detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize,OCheck,OJiezhang);
    		}else if(OCheck!=null){ //查询1 未审核  2 已审核
    			//得到总条数
            	hql1="select count(*) " +
            		 " from Ordersdetail d " +
            		 " where d.odState=1 " +
            		 " and d.orders.OCheck=?";
            	totalCount =(Integer)ordersDetailDao.queryByUnique(hql1,OCheck);
            	//得到所有信息
                hql2="select d from Ordersdetail d " +
        		" where  d.odState=1 " +
        		" and  d.orders.OCheck=? " +
        		" order by d.orders.OId desc";
            	//得到总信息
                detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize,OCheck);
    		}else if(OJiezhang!=null){  //查询发货  1  未发货  2  已发货  3 已签收
    			//得到总条数
            	hql1="select count(*) " +
            		 " from Ordersdetail d " +
            		 " where d.odState=1 " +
            		 " and d.orders.OJiezhang=?";
            	totalCount =(Integer)ordersDetailDao.queryByUnique(hql1,OJiezhang);
            	//得到所有信息
                hql2="select d from Ordersdetail d " +
        		" where  d.odState=1 " +
        		" and  d.orders.OJiezhang=? " +
        		" order by d.orders.OId desc";
            	//得到总信息
                detailList = ordersDetailDao.queryByPage(hql2, currentPage, pageSize,OJiezhang);
    		}
    	}
    	//得到总页数  10/2  5页
       // Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        //	totalCount/pageSize+1;
    	//上一页
       // Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
       // Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(detailList);
    	return pb;
	}
	
   
	/**
	 *查询所有的详细订单信息
	 * @return
	 */
	public List<Ordersdetail> findAllOrderDetail(){
		return ordersDetailDao.findAll();
	}
   
	/**
	 * 查询最新增加的订单详细信息
	 * @return
	 */
	public List<Ordersdetail> findBigOrderInfo(){
		String hql="select d from Ordersdetail d  " +
				"  where d.orders.OId=(select max(o.OId) " +
				"  from Orders o where  o.OState=1) " +
				"  and d.odState=1" +
				"  order by d.orders.OId desc";
		return ordersDetailDao.queryByHql(hql);
		
	}

	/**
	 * 根据订单编号查询订单详细信息
	 * @return
	 */
	public List<Ordersdetail> findByOrderId(String orderId){
		String hql="select d from Ordersdetail d  where d.orders.OId=? ";
		List<Ordersdetail> list= ordersDetailDao.queryByHql(hql,orderId);
		if(list!=null){
			for (Ordersdetail ordersdetail : list) {
				System.out.println(ordersdetail.getOrders().getOName());
			}
			return list;
		}else{
			return null;
		}
	}
	
	
	/**
	 *根据编号查询所有的详细订单信息
	 * @return
	 */
	public Ordersdetail findAllOrderDetail(Integer orderDetailId){
		return ordersDetailDao.findById(orderDetailId);
	}
   
	/**
	 * 添加详单
	 * 	 od_orderId varchar2(50) ,  --订单编号  (外键)
	 *   od_foodId number(9) ,--商品编号(外键)
	 *   od_buyNum number(9) ,--购买数量
	 *   od_totalMoney number(15,2) ,--购买总金额
	 * @param oDetail
	 * @param car
	 * @param orders
	 */
	public void addOrderDetail(ShoppingCar car,Orders orders,Userinfo user){
		//持久化
		ordersDao.save(orders);
		System.out.println(orders.getOId());
		//获得购物车内的商品信息
		Collection<FoodInfoBean> bean=car.getAllFoodInfo();
		if(bean!=null){
			Double  totalMoney=0.0;  //购买总金额
			Integer totalCoin=0;  //获得总积分
			//循环所有购买的商品信息
			for (FoodInfoBean foodInfoBean : bean) {
				//购买金额
				Double Money=foodInfoBean.getBuy()*foodInfoBean.getFoodinfo().getDanjia();
				//获得总积分
				totalCoin+=foodInfoBean.getFoodinfo().getFoodcoin()*foodInfoBean.getBuy();
				//购买总金额
				totalMoney+=Money;
				Ordersdetail oDetail = new Ordersdetail(
										orders,
										foodInfoBean.getFoodinfo(),
										foodInfoBean.getBuy(),
										Money,
										1
										);
				//根据编号查询商品信息
				Foodinfo foodinfo=foodInfoDao.findById(foodInfoBean.getFoodinfo().getFoodid());
				//修改商品数量
				foodinfo.setFoodnumber(foodinfo.getFoodnumber()-
						foodInfoBean.getBuy());
				//保存详单信息
				ordersDetailDao.save(oDetail);
			}
			
			Userinfo u=userInfoDao.findById(user.getUserid());
			if(u!=null){
				//会员卡付款  则从会员卡中扣取金额
				if(orders.getOPaymethod()=="会员卡付款"){
					if(u.getUExtendone()!=null){
						//修改会员的余额
						u.setUExtendone(u.getUExtendone()-totalMoney);
					}
					
				}
				//修改会员的积分
				if(u.getUsercoin()!=null){
					u.setUsercoin(u.getUsercoin()+totalCoin);
				}else{
					u.setUsercoin(totalCoin);	
				}
				
			}
		}
	}
}
