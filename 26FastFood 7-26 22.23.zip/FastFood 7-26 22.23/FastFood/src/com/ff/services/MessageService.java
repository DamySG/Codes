package com.ff.services;

import java.util.Date;
import java.util.List;

import com.ff.dao.MessageDAO;
import com.ff.iservices.IMessageService;
import com.hsg.pojos.Message;
import com.hsg.pojos.PageBean;

/**
 * 留言service
 * @author hushiguo
 *
 */
public class MessageService implements IMessageService {

	private MessageDAO messageDao;

	public void setMessageDao(MessageDAO messageDao) {
		this.messageDao = messageDao;
	}
	
	/**
	 * 查询所有的留言
	 * @return
	 */
	public List<Message> findAllMessage(){
		return messageDao.findAll();
	}
	
	/**
	 * 添加留言
	 * @param Message
	 */
	public void addMessage(Message Message){
		messageDao.save(Message);
	}
	
	
	/**
	 * 分页查询所有留言
	 * @return
	 */
	public PageBean findAllMessage(Integer currentPage, Integer msid){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=5;  //每页条数
    	if(msid==2){
    		pageSize=10;
    	}
    	
    	//得到总记录
    	String hql1="select count(*) from Message m where m.msState=1";
    	totalCount = (Integer) messageDao.queryByUnique(hql1);
    	
    	String hql2="select m from Message m " +
		" where  m.msState=1" +
		" order by m.msId desc";
    	
    	//得到总信息
    	List<Message> messageList = messageDao.queryByPage(hql2, currentPage, pageSize);

        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(messageList);
    	return pb;
	}
	
	
	/**
	 * 根据标题分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByTitle(Integer currentPage,String msTitle){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Message m where m.msState=1 and m.msTitle like ?";
    	totalCount = (Integer) messageDao.queryByUnique(hql1,"%"+msTitle+"%");
    	
    	String hql2="select m from Message m " +
		" where  m.msState=1" +
		" and m.msTitle like ?" +
		" order by m.msId desc";
    	
    	//得到总信息
    	List<Message> messageList = messageDao.queryByPage(hql2, currentPage, pageSize,"%"+msTitle+"%");
    	
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(messageList);
    	return pb;
	}
	
	/**
	 * 根据时间分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByDate(Integer currentPage,Date startDate, Date stopDate){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Message m where m.msState=1 " +
		" and to_date(m.msExtendone,'yyyy-MM-dd HH24:mi:ss') " +
		" between ? and ? ";
    	totalCount = (Integer) messageDao.queryByUnique(hql1,startDate,stopDate);
 	
    	String hql2="select m from Message m " +
		" where  m.msState=1" +
		" and to_date(m.msExtendone,'yyyy-MM-dd HH24:mi:ss')" +
		" between ? and ?" +
		" order by m.msId desc";
    	
    	//得到总信息
    	List<Message> messageList = messageDao.queryByPage(hql2, currentPage, pageSize,startDate,stopDate);
    	
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(messageList);
    	return pb;
	}
	
	
	/**
	 * 根据msId删除用户
	 * @param msId
	 */
	public void deleteById(Integer msId){
		Message message= messageDao.findById(msId);
		if(message!=null){
			message.setMsState(2);
		}
	}
}
