package com.ff.services;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ff.dao.ManagerDAO;
import com.ff.dao.ManagerroleDAO;
import com.ff.dao.TreemenuDAO;
import com.ff.iservices.IManagerRoleService;
import com.ff.iservices.IManagerService;
import com.hsg.pojos.Manager;
import com.hsg.pojos.Managerrole;
import com.hsg.pojos.Treemenu;

/**
 * 管理员角色service
 * @author hushiguo
 *
 */
public class ManagerRoleService implements IManagerRoleService  {
   private ManagerDAO managerDao;
   private ManagerroleDAO managerRoleDao;
   private TreemenuDAO treeMenuDao;
   
	public void setManagerDao(ManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	
	public void setManagerRoleDao(ManagerroleDAO managerRoleDao) {
		this.managerRoleDao = managerRoleDao;
	}
	public void setTreeMenuDao(TreemenuDAO treeMenuDao) {
		this.treeMenuDao = treeMenuDao;
	}
	   
	
	/**
	 * 给角色添加权限菜单
	 * roleId  角色编号
	 * menuId 树形菜单编号数组
	 * @return
	 */
	public void addTreeMenuByRoleId(Integer roleId,String[]menuId){
		String hql="select r from Managerrole r where r.managerroleid=? and r.managerstate=1";
		List<Managerrole> listRole=managerRoleDao.queryByHql(hql, roleId);
		try {
			Set<Treemenu> treeMenu=new HashSet<Treemenu>();   //树形菜单集合
			if(menuId!=null){
				for (int i = 0; i < menuId.length; i++) {
					treeMenu.add(treeMenuDao.findById(Integer.parseInt(menuId[i])));
				}
				if(listRole!=null){ 
					//修改树形菜单
					listRole.get(0).setTreemenus(treeMenu);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	/**
	 * 查询所有管理员角色
	 * @return
	 */
	public List<Managerrole> findAllManagerRole(){
	    return managerRoleDao.findAll();
	}
   
	/**
	 * 查询所有管理员角色
	 * @return
	 */
	public List<Managerrole> findAllManagerRole2(){
		String hql="select r from Managerrole r where  r.managerstate=1 order by r.managerroleid ";
		return managerRoleDao.queryByHql(hql);
		
	}
	
	
	/**
	 * 根据编号查询所有管理员角色
	 * @return
	 */
	public Managerrole findManagerRoleById(Integer managerRoleId){
		return managerRoleDao.findById(managerRoleId);
	}
   
	/**
	 * 根据姓名查询所有管理员角色
	 * @return
	 */
	public Managerrole findRoleByName(String roleName){
		String hql="select r from Managerrole r where r.managerrolename=? and r.managerstate=1";
		List<Managerrole> listRole=managerRoleDao.queryByHql(hql, roleName);
		return listRole!=null&&listRole.size()>0?listRole.get(0):null;
	}
	
	
	/**
	 * 根据姓名模糊查询角色
	 * @return
	 */
	public List<Managerrole> findRoleByName2(String roleName){
		String hql="select r from Managerrole r where r.managerrolename like ? and r.managerstate=1";
		List<Managerrole> listRole=managerRoleDao.queryByHql(hql, "%"+roleName+"%");
		return listRole!=null&&listRole.size()>0?listRole:null;
	}
	
	
	
	/**
	 * 增加角色
	 * @return
	 */
	public void addRole(Managerrole role){
		if(role!=null){
			 managerRoleDao.save(role);
		}
	}
	

	/**
	 * 修改角色
	 * @return
	 */
	public void updateRole(Integer roleId,Managerrole role){
		String hql="select r from Managerrole r where r.managerroleid=? and r.managerstate=1";
		List<Managerrole> listRole=managerRoleDao.queryByHql(hql, roleId);
		if(listRole!=null){
			if(role!=null){
				listRole.get(0).setManagerrolename(role.getManagerrolename());
				listRole.get(0).setRExtendone(role.getRExtendone());
			}
		}
	}
	

	/**
	 * 删除角色  把状态修改为2
	 * @return
	 */
	public void deleteRole(Integer roleId){
		String hql="select r from Managerrole r where r.managerroleid=? and r.managerstate=1";
		List<Managerrole> listRole=managerRoleDao.queryByHql(hql, roleId);
		if(listRole!=null){
			listRole.get(0).setManagerstate(2);  
		}
	}
	
}
