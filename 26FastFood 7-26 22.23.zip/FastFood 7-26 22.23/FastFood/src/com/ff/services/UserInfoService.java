package com.ff.services;

import java.util.Date;
import java.util.List;

import com.ff.dao.UserinfoDAO;
import com.ff.iservices.IUserInfoService;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.Userinfo;

/**
 * 用户service
 * @author hushiguo
 *
 */
public class UserInfoService implements IUserInfoService {
    private UserinfoDAO userInfoDao;

	public void setUserInfoDao(UserinfoDAO userInfoDao) {
		this.userInfoDao = userInfoDao;
	}
    
	/**
	 * 验证name是否已存在
	 */
	public Userinfo checkName(String name){
		String hql=" select u from Userinfo u where u.username=? and u.userstate=1";
		List<Userinfo> list=userInfoDao.queryByHql(hql, name);
		return list!=null&&list.size()>0?list.get(0):null;
	}
	
	/**
	 * 修改登录的时间和登录次数
	 * @param user
	 */
	public void updateLoginTime(Userinfo user){
	  
	  user.setLastlogin(new Date());
	  if(user.getLogintime()==null){
		  user.setLogintime(1);
	  }else{
		  user.setLogintime(user.getLogintime()+1);
	  }
	 
	}
	
	/* 
	 * 查询所有会员信息
	 */
	public List<Userinfo> findAllUserInfo(){
		return userInfoDao.findAll();
	}
	
	 
	/*
	 *  根据编号查询会员信息
	 */
	public Userinfo finUserInfoById(Integer userId ){
		return userInfoDao.findById(userId);
	}
    
	/* 
	 *  根据用户名和密码查询会员信息
	 */
	public Userinfo FindByLogin(String userName,String pwd){
		String hql=" select u from Userinfo u where u.username=? and u.pwd=? and u.userstate=1";
		List<Userinfo> list=userInfoDao.queryByHql(hql, userName,pwd);
		return list!=null&&list.size()>0?list.get(0):null;
	}
	
	/**
	 * 分页查询所有用户
	 * @param currentPage
	 * @return
	 */
	public PageBean findAllUser(Integer currentPage){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Userinfo u where u.userstate=1";
    	totalCount = (Integer) userInfoDao.queryByUnique(hql1);
    	
    	String hql2="select u from Userinfo u " +
		" where  u.userstate=1" +
		" order by u.userid desc";
    	
    	//得到总信息
    	List<Userinfo> userinfoList = userInfoDao.queryByPage(hql2, currentPage, pageSize);
    	
    	//得到总页数  10/2  5页
        Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        	totalCount/pageSize+1;
    	//上一页
        Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
        Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(userinfoList);
    	return pb;
	}
	
	/**
	 * 根据用户Name分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByName(Integer currentPage,String username){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Userinfo u where u.userstate=1 and u.username like ?";
    	totalCount = (Integer) userInfoDao.queryByUnique(hql1,"%"+username+"%");
    	
    	String hql2="select u from Userinfo u " +
		" where  u.userstate=1" +
		" and u.username like ?" +
		" order by u.userid desc";
    	
    	//得到总信息
    	List<Userinfo> userinfoList = userInfoDao.queryByPage(hql2, currentPage, pageSize,"%"+username+"%");
    	
    	//得到总页数  10/2  5页
        Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        	totalCount/pageSize+1;
    	//上一页
        Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
        Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(userinfoList);
    	return pb;
	}
	
	/**
	 * 根据userId删除用户
	 * @param userId
	 */
	public void deleteById(Integer userId){
//		String hql="select u " +
//				" from Userinfo u " +
//				" where u.userstate=1" +
//				" and u.userid = ?";
		Userinfo user= userInfoDao.findById(userId);
		if(user!=null){
			user.setUserstate(2);
		}
	}
	
	/**
	 * 根据userId修改用户信息
	 * @param userId
	 */
	public void updateById(Integer userId,String username,Integer sex,
			String telephone,String email,String address,String URemarks){
		String hql="select u from Userinfo u where u.userid=? and u.userstate=1";
		 List<Userinfo> list= userInfoDao.queryByHql(hql, userId);
		if(list!=null){
			list.get(0).setUsername(username);
			list.get(0).setSex(sex);
			list.get(0).setTelephone(telephone);
			list.get(0).setEmail(email);
			list.get(0).setAddress(address);
			list.get(0).setURemarks(URemarks);
		}
	}
	
	/**
	 * 前台添加会员
	 * @param Userinfo
	 */
	public void addUserinfo(Userinfo Userinfo){
		userInfoDao.save(Userinfo);
	}
	
	/**
	 * 后台添加会员
	 * @param Userinfo
	 */
	public void addUser(Userinfo Userinfo){
		userInfoDao.save(Userinfo);
	}

	
	
	/**
	 * 根据会员编号修改会员积分，余额
	 * @param userId
	 */
	public void updateUserCoin(Integer userId,Double totalMoney,Integer totalCoin){
		 String hql="select u from Userinfo u where u.userid=? and u.userstate=1";
		 List<Userinfo> list= userInfoDao.queryByHql(hql, userId);
		 if(list!=null){
			 //修改会员积分
			 list.get(0).setUsercoin(list.get(0).getUsercoin()+totalCoin);
			 //修改会员余额
			 list.get(0).setUExtendone(list.get(0).getUExtendone()-totalMoney);
		 }
	}
	
	/**
	 * 修改密码
	 * @param userId
	 * @param pass
	 */
	public void updatePass(Integer userId,String pass){
		String hql="select u from Userinfo u where u.userid=? and u.userstate=1";
		 List<Userinfo> list= userInfoDao.queryByHql(hql,userId);
		 if(list!=null){
			list.get(0).setPwd(pass);
		}
	}
	
	/**
	 * 修改头像
	 */
	public void updatePhotos(Userinfo user,String photos){
		String hql="select u from Userinfo u where u.userid=? and u.userstate=1";
		if(user!=null){
			List<Userinfo> list= userInfoDao.queryByHql(hql,user.getUserid());
			for (Userinfo userinfo : list) {
				userinfo.setPhotos(photos);
			}
		}
	}
}
