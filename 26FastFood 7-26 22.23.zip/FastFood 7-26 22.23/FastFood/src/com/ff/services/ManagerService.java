package com.ff.services;

import java.util.HashSet;
import java.util.List;

import com.ff.dao.ManagerDAO;
import com.ff.dao.ManagerroleDAO;
import com.ff.dao.TreemenuDAO;
import com.ff.iservices.IManagerService;
import com.hsg.pojos.Manager;
import com.hsg.pojos.Managerrole;
import com.hsg.pojos.PageBean;

public class ManagerService implements IManagerService {
   private ManagerDAO managerDao;
   private ManagerroleDAO managerRoleDao;
   private TreemenuDAO treeMenuDao;
   
	public void setManagerDao(ManagerDAO managerDao) {
		this.managerDao = managerDao;
	}
	public void setManagerRoleDao(ManagerroleDAO managerRoleDao) {
		this.managerRoleDao = managerRoleDao;
	}
	public void setTreeMenuDao(TreemenuDAO treeMenuDao) {
		this.treeMenuDao = treeMenuDao;
	}
	   
	/**
	 * 查询所有管理员
	 * @return
	 */
	public List<Manager> findAllManager(){
		return managerDao.findAll();
	}
   
	/**
	 * 根据编号查询所有管理员
	 * @return
	 */
	public Manager findManagerById(Integer managerId){
		return managerDao.findById(managerId);
	}
   
	
	/**
	 * 分页查询所有用户
	 * @param currentPage
	 * @return
	 */
	public PageBean findAllManager(Integer currentPage){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Manager m where m.mgState=1";
    	totalCount = (Integer) managerDao.queryByUnique(hql1);
    	
    	String hql2="select m from Manager m " +
		" where  m.mgState=1" +
		" order by m.mgId desc";
    	
    	//得到总信息
    	List<Manager> managerinfoList = managerDao.queryByPage(hql2, currentPage, pageSize);
    	
    	//得到总页数  10/2  5页
        Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        	totalCount/pageSize+1;
    	//上一页
        Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
        Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(managerinfoList);
    	return pb;
	}
	
	
	/**
	 * 根据用户Name分页查询
	 * @param currentPage
	 * @return
	 */
	public PageBean queryByName(Integer currentPage,String mgName){
		PageBean pb=new PageBean();
    	Integer totalCount=0;  //总记录
    	Integer pageSize=10;  //每页条数
    	
    	//得到总记录 
    	String hql1="select count(*) from Manager m where m.mgState=1 and m.mgName like ?";
    	totalCount = (Integer) managerDao.queryByUnique(hql1,"%"+mgName+"%");
    	
    	String hql2="select m from Manager m " +
		" where  m.mgState=1" +
		" and m.mgName like ?" +
		" order by m.mgId desc";
    	
    	//得到总信息
    	List<Manager> managerinfoList = managerDao.queryByPage(hql2, currentPage, pageSize,"%"+mgName+"%");
    	
    	//得到总页数  10/2  5页
        Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:
        	totalCount/pageSize+1;
    	//上一页
        Integer prePage=currentPage<=1?currentPage:currentPage-1;
        //下一页
        Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
        //保存到pagebean中
        pb.setCurrentPage(currentPage);
        pb.setRowCount(totalCount);
        pb.setRowSize(pageSize);
        pb.setPageData(managerinfoList);
    	return pb;
	}
	
	
	/**
	 * 根据mgId删除用户
	 * @param mgId
	 */
	public void deleteById(Integer mgId){

		Manager manager= managerDao.findById(mgId);
		if(manager!=null){
			manager.setMgState(2);
		}
	}
	
	
	/**
	 * 根据mgId修改管理员信息
	 * @param mgId
	 */
	public void updateManagerById(Integer mgId,String mgName,Integer mgExtendthree,
			String mgPhone,String mgExtendone,String mgAddress,String mgExtendtwo,Integer roleId){
		String hql="select m from Manager m where m.mgId=? and m.mgState=1";
		 try {
			List<Manager> list= managerDao.queryByHql(hql, mgId);
			 if(roleId!=null){
				 Managerrole role=managerRoleDao.findById(roleId);  //查到对应的角色
				 if(list!=null){
						list.get(0).setMgName(mgName);
						list.get(0).setMgExtendthree(mgExtendthree);
						list.get(0).setMgPhone(mgPhone);
						list.get(0).setMgExtendone(mgExtendone);
						list.get(0).setMgAddress(mgAddress);
						list.get(0).setMgExtendtwo(mgExtendtwo);
						role.getManagers().add(list.get(0));  //添加角色
				}
				
			 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 后台添加管理员
	 * @param Manager
	 */
	public void addManager(Manager manager,Integer roleId){
			if(roleId!=null&&!roleId.equals("")){
				managerDao.save(manager);
				Managerrole role=managerRoleDao.findById(roleId);
				role.getManagers().add(manager);
				System.out.println(role.getManagerrolename());
				 
			}
	}
	
	
	/** 
	 * 验证name是否已存在
	 * @return
	 */
	public Manager checkName(String name){
		String hql=" select m from Manager m where m.mgName=? and m.mgState=1";
		List<Manager> list=managerDao.queryByHql(hql, name);
		return list!=null&&list.size()>0?list.get(0):null;
	}
	
	/**
	 * 登录验证
	 * @return
	 */
	public Manager checkLogin(String managerName,String pwd){
		String hql="select m from Manager m where  m.mgName=? and m.mgPwd=?  and m.mgState=1";
		List<Manager> list= managerDao.queryByHql(hql,managerName,pwd);
		return list!=null&&list.size()>0?list.get(0):null;
	}
   
}
