package com.ff.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.WeakHashMap;

import com.ff.dao.FoodinfoDAO;
import com.ff.dao.FoodtypeDAO;
import com.ff.iservices.IFoodinfoService;
import com.hsg.pojos.Foodinfo;
import com.hsg.pojos.Foodtype;
import com.hsg.pojos.Orders;
import com.hsg.pojos.Ordersdetail;

/**
 * 商品业务类(如何做)
 * @author hushiguo 
 *
 */
public class FoodinfoService implements IFoodinfoService {
   private FoodinfoDAO foodInfoDao;
   private FoodtypeDAO foodTypeDao;
   
	public void setFoodInfoDao(FoodinfoDAO foodInfoDao) {
		this.foodInfoDao = foodInfoDao;
	}
	
	public void setFoodTypeDao(FoodtypeDAO foodTypeDao) {
		this.foodTypeDao = foodTypeDao;
	}

	/**
	 * 删除商品信息  (即将状态修改为2)
	 * @param orderId
	 */
	public void deleteFoodInfo(Integer foodId){
		Foodinfo foodInfo=foodInfoDao.findById(foodId);
		if(foodInfo!=null){
			foodInfo.setFState(2);
		}
	}
	
	/**
	 * 增加商品信息
	 * @param food
	 */
	public void addFoodInfo(Foodinfo food){
		if(food!=null){
			foodInfoDao.save(food);
		}
	}
	
	/**
	 * 修改商品信息
	 * @param foodId
	 * @param food
	 */
	public void updateFoodInfo(Integer foodId,Foodinfo food){
		Foodinfo foodinfo=foodInfoDao.findById(foodId); //查询要修改的商品信息
		if(foodinfo!=null){
			if(food!=null){
				foodinfo.setFoodname(food.getFoodname());
				foodinfo.setFoodimg(food.getFoodimg());
				foodinfo.setDanjia(food.getDanjia());
				foodinfo.setFoodcoin(food.getFoodcoin());
				foodinfo.setMainfood(food.getMainfood());
				foodinfo.setTaste(food.getTaste());
				foodinfo.setFoodnumber(food.getFoodnumber());
				foodinfo.setFoodremark(food.getFoodremark());
				foodinfo.setFState(food.getFState());
			}
		}
	}
	
	
	/**
	 * 分页查询商品信息
	 * @param foodTypeId
	 * @param currentPage
	 * @param i
	 * @return
	 */
	public Map<String,Object> findFoodInfoByPage(Integer foodTypeId,Integer currentPage,
			Integer i,String foodName){
		//每页条数
		Integer pageSize=10;
		//总条数
		Integer totalCount=null;
		List<Object> list=null;
		String hql1="";
		String hql2="";
		
		//如果 i==0 查询所有   否则 根据条件查询 
		if(i==0){
			hql1="select count(*) from Foodinfo f where  f.FState=1";
			totalCount=(Integer) foodInfoDao.queryByUnique(hql1);
			hql2="select f from Foodinfo f " +
					" where  f.FState=1 " +
					" order by f.foodid desc";
			list=foodInfoDao.queryByPage(hql2, currentPage, pageSize);
		}else{
			if(foodTypeId!=null){  //根据类型编号
				hql1="select count(*) from Foodinfo f where f.foodtype.FTypeid=? and f.FState=1";
				totalCount=(Integer) foodInfoDao.queryByUnique(hql1, foodTypeId);
				hql2="select f from Foodinfo f " +
						" where f.foodtype.FTypeid=? " +
						" and f.FState=1 " +
						" order by f.foodid desc";
				list=foodInfoDao.queryByPage(hql2, currentPage, pageSize, foodTypeId);
			}else if(foodName!=null&&foodTypeId==null){ //根据商品名称查询
				hql1="select count(*) from Foodinfo f " +
						" where f.foodname like ? " +
						" and f.FState=1";
				totalCount=(Integer) foodInfoDao.queryByUnique(hql1, "%"+foodName+"%");
				hql2="select f from Foodinfo f " +
				        " where f.foodname like ? " +
						" and f.FState=1 " +
						" order by f.foodid desc";
				list=foodInfoDao.queryByPage(hql2, currentPage, pageSize, "%"+foodName+"%");
			}
		}
		
		//总页数
		Integer totalPage=totalCount%pageSize==0?totalCount/pageSize:(totalCount/pageSize)+1;
		//上一页
		Integer prePage=currentPage<=1?1:currentPage-1;
		//下一页
		Integer nextPage=currentPage>=totalPage?totalPage:currentPage+1;
		//保存到map中
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("totalPage",totalPage);
		map.put("currentPage",currentPage);
		map.put("prePage",prePage);
		map.put("nextPage",nextPage);
		map.put("pageSize",pageSize);
		map.put("totalCount",totalCount);
		map.put("list",list);
		return map;

	}
	
	
	/**
	 * 修改商品数量
	 * @param foodid
	 * @param foodNum
	 */
	public void updateFoodNum(Integer foodid,Integer foodNum){
       Foodinfo foodinfo=foodInfoDao.findById(foodid);
       if(foodinfo!=null){
    	   foodinfo.setFoodnumber(foodinfo.getFoodnumber()-foodNum);
       }
	}
	
	

	/* 
	 * 查询所有商品信息
	 */
	public List<Foodinfo> findAllFoodInfo(){
		return foodInfoDao.findAll();
	}
	/*
	 *  根据编号查询商品信息
	 */
	public Foodinfo findFoodInfoById(Integer foodId ){
		return foodInfoDao.findById(foodId);  
	}
	
	/* 
	 * 根据商品类型编号查询所有商品信息
	 */
	public List<Foodinfo> findFoodInfoByTypeId(Integer foodTypeId){
		String hql="select f from Foodinfo f  inner join  f.foodtype t " +
				" where t.FTypeid=? and f.FState=1 ";
		return foodInfoDao.queryByHql(hql, foodTypeId);
	}
   
	/* 
	 * 根据商品类型名称查询所有商品信息
	 */
	public List<Foodinfo> findFoodInfoByTypeName(String foodTypeName){
		String hql="select f from Foodinfo f  inner join  f.foodtype t " +
				" where t.FTypename=? and f.FState=1 order by  f.foodid";
		return foodInfoDao.queryByHql(hql,foodTypeName);
	}
	
	/* 
	 * 根据商品大类型名称查询所有商品信息
	 */
	public List<Foodinfo> findFoodInfoByBigTypeId(Integer bigTypeId){
		String hql="select f from Foodinfo f  inner join  f.foodtype t " +
				   " where t.FBigtype=? " +
				   " and f.FState=1 " +
				   " order by  f.foodid";
		return foodInfoDao.queryByHql(hql,bigTypeId);
	}
	
	
}
