package com.ff.services;

import java.util.List;

import com.ff.dao.AccountsDAO;
import com.ff.dao.BanktypeDAO;
import com.ff.iservices.IAccountService;
import com.hsg.pojos.Accounts;

/**
 * 账户service
 * @author hushiguo
 *
 */
public class AccountService implements IAccountService {
  
	private AccountsDAO accountDao;
	private BanktypeDAO bankTypeDao;
	public void setAccountDao(AccountsDAO accountDao) {
		this.accountDao = accountDao;
	}
	public void setBankTypeDao(BanktypeDAO bankTypeDao) {
		this.bankTypeDao = bankTypeDao;
	}
	
	/**
	 * 查询所有账户信息
	 * @return
	 */
	public List<Accounts> findAllAccounts(){
		return accountDao.findAll();
	}
	

	/**
	 * 根据编号查询所有账户信息
	 * @return
	 */
	public Accounts findAccountById(String accountId){
		return accountDao.findById(accountId);	
	}

	/**
	 * 根据银行类型，账户号，密码  查询账户信息
	 * @return
	 */
	public Accounts findAccountById(Integer bankTypeId, String accountId,Integer acPwd){
		String hql="select a from Accounts a inner join a.banktype b " +
				" where b.btId=? and a.acId =? and a.acPwd=? and a.acExtendthree=1 ";
		List<Accounts> list= accountDao.queryByHql(hql, bankTypeId,accountId,acPwd);
		return list!=null&&list.size()>0?list.get(0):null;
	}
	
	
}
