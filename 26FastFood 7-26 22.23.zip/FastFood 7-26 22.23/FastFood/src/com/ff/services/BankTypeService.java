package com.ff.services;

import java.util.List;

import com.ff.dao.AccountsDAO;
import com.ff.dao.BanktypeDAO;
import com.ff.iservices.IBankTypeService;
import com.hsg.pojos.Banktype;

/**
 * 银行类型model层(业务逻辑层)
 * @author hushiguo
 *
 */
public class BankTypeService implements IBankTypeService {

	private AccountsDAO accountDao;
	private BanktypeDAO bankTypeDao;
	public void setAccountDao(AccountsDAO accountDao) {
		this.accountDao = accountDao;
	}
	public void setBankTypeDao(BanktypeDAO bankTypeDao) {
		this.bankTypeDao = bankTypeDao;
	}
	
	/**
	 * 查询所有银行类型信息
	 * @return
	 */
	public List<Banktype> findAllBankType(){
		return bankTypeDao.findAll();
	}
	

	/**
	 * 根据编号查询所有银行类型信息
	 * @return
	 */
	public Banktype findBankTypeById(Integer bankTypeId){
		return bankTypeDao.findById(bankTypeId);
	}

}
