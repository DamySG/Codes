package com.ff.dao;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;

import com.hsg.pojos.Ordersdetail;

/**
 * A data access object (DAO) providing persistence and search support for
 * Ordersdetail entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.hsg.pojos.Ordersdetail
 * @author MyEclipse Persistence Tools
 */

public class OrdersdetailDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(OrdersdetailDAO.class);
	// property constants
	public static final String OD_BUYNUM = "odBuynum";
	public static final String OD_TOTALMONEY = "odTotalmoney";
	public static final String OD_REMARK = "odRemark";
	public static final String OD_STATE = "odState";
	public static final String OD_EXTENDONE = "odExtendone";
	public static final String OD_EXTENDTWO = "odExtendtwo";
	public static final String OD_EXTENDTHREE = "odExtendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Ordersdetail transientInstance) {
		log.debug("saving Ordersdetail instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Ordersdetail persistentInstance) {
		log.debug("deleting Ordersdetail instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Ordersdetail findById(java.lang.Integer id) {
		log.debug("getting Ordersdetail instance with id: " + id);
		try {
			Ordersdetail instance = (Ordersdetail) getHibernateTemplate().get(
					"com.hsg.pojos.Ordersdetail", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Ordersdetail instance) {
		log.debug("finding Ordersdetail instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Ordersdetail instance with property: "
				+ propertyName + ", value: " + value);
		try {
			String queryString = "from Ordersdetail as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByOdBuynum(Object odBuynum) {
		return findByProperty(OD_BUYNUM, odBuynum);
	}

	public List findByOdTotalmoney(Object odTotalmoney) {
		return findByProperty(OD_TOTALMONEY, odTotalmoney);
	}

	public List findByOdRemark(Object odRemark) {
		return findByProperty(OD_REMARK, odRemark);
	}

	public List findByOdState(Object odState) {
		return findByProperty(OD_STATE, odState);
	}

	public List findByOdExtendone(Object odExtendone) {
		return findByProperty(OD_EXTENDONE, odExtendone);
	}

	public List findByOdExtendtwo(Object odExtendtwo) {
		return findByProperty(OD_EXTENDTWO, odExtendtwo);
	}

	public List findByOdExtendthree(Object odExtendthree) {
		return findByProperty(OD_EXTENDTHREE, odExtendthree);
	}

	public List findAll() {
		log.debug("finding all Ordersdetail instances");
		try {
			String queryString = "from Ordersdetail";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Ordersdetail merge(Ordersdetail detachedInstance) {
		log.debug("merging Ordersdetail instance");
		try {
			Ordersdetail result = (Ordersdetail) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Ordersdetail instance) {
		log.debug("attaching dirty Ordersdetail instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Ordersdetail instance) {
		log.debug("attaching clean Ordersdetail instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static OrdersdetailDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (OrdersdetailDAO) ctx.getBean("OrdersdetailDAO");
	}
}