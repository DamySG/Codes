package com.ff.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hsg.pojos.Userinfo;

/**
 * A data access object (DAO) providing persistence and search support for
 * Userinfo entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.hsg.pojos.Userinfo
 * @author MyEclipse Persistence Tools
 */

public class UserinfoDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(UserinfoDAO.class);
	// property constants
	public static final String USERNAME = "username";
	public static final String PWD = "pwd";
	public static final String SEX = "sex";
	public static final String PHOTOS = "photos";
	public static final String ADDRESS = "address";
	public static final String EMAIL = "email";
	public static final String TELEPHONE = "telephone";
	public static final String LOGINTIME = "logintime";
	public static final String USERCOIN = "usercoin";
	public static final String USERSTATE = "userstate";
	public static final String USERJP = "userjp";
	public static final String _UREMARKS = "URemarks";
	public static final String _UEXTENDONE = "UExtendone";
	public static final String _UEXTENDTWO = "UExtendtwo";
	public static final String _UEXTENDTHREE = "UExtendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Userinfo transientInstance) {
		log.debug("saving Userinfo instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Userinfo persistentInstance) {
		log.debug("deleting Userinfo instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Userinfo findById(java.lang.Integer id) {
		log.debug("getting Userinfo instance with id: " + id);
		try {
			Userinfo instance = (Userinfo) getHibernateTemplate().get(
					"com.hsg.pojos.Userinfo", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Userinfo instance) {
		log.debug("finding Userinfo instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Userinfo instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Userinfo as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByUsername(Object username) {
		return findByProperty(USERNAME, username);
	}

	public List findByPwd(Object pwd) {
		return findByProperty(PWD, pwd);
	}

	public List findBySex(Object sex) {
		return findByProperty(SEX, sex);
	}

	public List findByPhotos(Object photos) {
		return findByProperty(PHOTOS, photos);
	}

	public List findByAddress(Object address) {
		return findByProperty(ADDRESS, address);
	}

	public List findByEmail(Object email) {
		return findByProperty(EMAIL, email);
	}

	public List findByTelephone(Object telephone) {
		return findByProperty(TELEPHONE, telephone);
	}

	public List findByLogintime(Object logintime) {
		return findByProperty(LOGINTIME, logintime);
	}

	public List findByUsercoin(Object usercoin) {
		return findByProperty(USERCOIN, usercoin);
	}

	public List findByUserstate(Object userstate) {
		return findByProperty(USERSTATE, userstate);
	}

	public List findByUserjp(Object userjp) {
		return findByProperty(USERJP, userjp);
	}

	public List findByURemarks(Object URemarks) {
		return findByProperty(_UREMARKS, URemarks);
	}

	public List findByUExtendone(Object UExtendone) {
		return findByProperty(_UEXTENDONE, UExtendone);
	}

	public List findByUExtendtwo(Object UExtendtwo) {
		return findByProperty(_UEXTENDTWO, UExtendtwo);
	}

	public List findByUExtendthree(Object UExtendthree) {
		return findByProperty(_UEXTENDTHREE, UExtendthree);
	}

	public List findAll() {
		log.debug("finding all Userinfo instances");
		try {
			String queryString = "from Userinfo";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Userinfo merge(Userinfo detachedInstance) {
		log.debug("merging Userinfo instance");
		try {
			Userinfo result = (Userinfo) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Userinfo instance) {
		log.debug("attaching dirty Userinfo instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Userinfo instance) {
		log.debug("attaching clean Userinfo instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static UserinfoDAO getFromApplicationContext(ApplicationContext ctx) {
		return (UserinfoDAO) ctx.getBean("UserinfoDAO");
	}
}