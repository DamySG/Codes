package com.ff.dao;

import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hsg.pojos.Banktype;

/**
 * A data access object (DAO) providing persistence and search support for
 * Banktype entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.hsg.pojos.Banktype
 * @author MyEclipse Persistence Tools
 */

public class BanktypeDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(BanktypeDAO.class);
	// property constants
	public static final String BT_NAME = "btName";
	public static final String BT_STATE = "btState";
	public static final String BT_EXTENDONE = "btExtendone";
	public static final String BT_EXTENDTWO = "btExtendtwo";
	public static final String BT_EXTENDTHREE = "btExtendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Banktype transientInstance) {
		log.debug("saving Banktype instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Banktype persistentInstance) {
		log.debug("deleting Banktype instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Banktype findById(java.lang.Integer id) {
		log.debug("getting Banktype instance with id: " + id);
		try {
			Banktype instance = (Banktype) getHibernateTemplate().get(
					"com.hsg.pojos.Banktype", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Banktype instance) {
		log.debug("finding Banktype instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Banktype instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Banktype as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByBtName(Object btName) {
		return findByProperty(BT_NAME, btName);
	}

	public List findByBtState(Object btState) {
		return findByProperty(BT_STATE, btState);
	}

	public List findByBtExtendone(Object btExtendone) {
		return findByProperty(BT_EXTENDONE, btExtendone);
	}

	public List findByBtExtendtwo(Object btExtendtwo) {
		return findByProperty(BT_EXTENDTWO, btExtendtwo);
	}

	public List findByBtExtendthree(Object btExtendthree) {
		return findByProperty(BT_EXTENDTHREE, btExtendthree);
	}

	public List findAll() {
		log.debug("finding all Banktype instances");
		try {
			String queryString = "from Banktype";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Banktype merge(Banktype detachedInstance) {
		log.debug("merging Banktype instance");
		try {
			Banktype result = (Banktype) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Banktype instance) {
		log.debug("attaching dirty Banktype instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Banktype instance) {
		log.debug("attaching clean Banktype instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static BanktypeDAO getFromApplicationContext(ApplicationContext ctx) {
		return (BanktypeDAO) ctx.getBean("BanktypeDAO");
	}
}