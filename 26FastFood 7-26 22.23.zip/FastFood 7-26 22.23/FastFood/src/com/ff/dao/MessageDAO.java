package com.ff.dao;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hsg.pojos.Message;

/**
 * A data access object (DAO) providing persistence and search support for
 * Message entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.hsg.pojos.Message
 * @author MyEclipse Persistence Tools
 */

public class MessageDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(MessageDAO.class);
	// property constants
	public static final String MS_TITLE = "msTitle";
	public static final String MS_USERNAME = "msUsername";
	public static final String MS_EMAIL = "msEmail";
	public static final String MS_QQ = "msQq";
	public static final String MG_PHOTOS = "mgPhotos";
	public static final String MS_CONTENT = "msContent";
	public static final String MS_STATE = "msState";
	public static final String MS_EXTENDONE = "msExtendone";
	public static final String MS_EXTENDTWO = "msExtendtwo";
	public static final String MS_EXTENDTHREE = "msExtendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Message transientInstance) {
		log.debug("saving Message instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Message persistentInstance) {
		log.debug("deleting Message instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Message findById(java.lang.Integer id) {
		log.debug("getting Message instance with id: " + id);
		try {
			Message instance = (Message) getHibernateTemplate().get(
					"com.hsg.pojos.Message", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Message instance) {
		log.debug("finding Message instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Message instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Message as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByMsTitle(Object msTitle) {
		return findByProperty(MS_TITLE, msTitle);
	}

	public List findByMsUsername(Object msUsername) {
		return findByProperty(MS_USERNAME, msUsername);
	}

	public List findByMsEmail(Object msEmail) {
		return findByProperty(MS_EMAIL, msEmail);
	}

	public List findByMsQq(Object msQq) {
		return findByProperty(MS_QQ, msQq);
	}

	public List findByMgPhotos(Object mgPhotos) {
		return findByProperty(MG_PHOTOS, mgPhotos);
	}

	public List findByMsContent(Object msContent) {
		return findByProperty(MS_CONTENT, msContent);
	}

	public List findByMsState(Object msState) {
		return findByProperty(MS_STATE, msState);
	}

	public List findByMsExtendone(Object msExtendone) {
		return findByProperty(MS_EXTENDONE, msExtendone);
	}

	public List findByMsExtendtwo(Object msExtendtwo) {
		return findByProperty(MS_EXTENDTWO, msExtendtwo);
	}

	public List findByMsExtendthree(Object msExtendthree) {
		return findByProperty(MS_EXTENDTHREE, msExtendthree);
	}

	public List findAll() {
		log.debug("finding all Message instances");
		try {
			String queryString = "from Message";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Message merge(Message detachedInstance) {
		log.debug("merging Message instance");
		try {
			Message result = (Message) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Message instance) {
		log.debug("attaching dirty Message instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Message instance) {
		log.debug("attaching clean Message instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static MessageDAO getFromApplicationContext(ApplicationContext ctx) {
		return (MessageDAO) ctx.getBean("MessageDAO");
	}
}