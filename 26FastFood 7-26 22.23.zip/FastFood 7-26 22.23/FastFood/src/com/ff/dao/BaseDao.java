package com.ff.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * 基本dao  提供公用的方法
 * @author hushiguo
 *
 */
public class BaseDao extends HibernateDaoSupport{
    
	/**
	 * 分页查询
	 * @param hql
	 * @param currentPage
	 * @param pageSize
	 * @param objects
	 * @return
	 */
	public List queryByPage(final String hql,final Integer currentPage,
			                final Integer pageSize,final Object...objects){
		return getHibernateTemplate().executeFind(new HibernateCallback() {
			//匿名类
			public Object doInHibernate(Session session) throws HibernateException,
					SQLException {
				Query query=session.createQuery(hql);
				if(currentPage!=null&&pageSize!=null){
					query.setFirstResult((currentPage-1)*pageSize).setMaxResults(pageSize);
					
				}
				
				if(objects!=null){
					for (int i = 0; i < objects.length; i++) {
						query.setParameter(i, objects[i]);
					}
				}
				return query.list();
			}
		});
	}
	
	/**
	 * 根据hql语句查询
	 * @param hql
	 * @param objects
	 * @return
	 */
	public List queryByHql(String hql,Object...objects){
		return queryByPage(hql,null,null, objects);
	}
	
	/**
	 * 查询唯一值
	 * @param hql
	 * @param objects
	 * @return
	 */
	public Object queryByUnique(String hql,Object...objects){
		List list=queryByPage(hql, null, null, objects);
		return list!=null&&list.size()>0?list.get(0):null;
		
	}
	
	
}
