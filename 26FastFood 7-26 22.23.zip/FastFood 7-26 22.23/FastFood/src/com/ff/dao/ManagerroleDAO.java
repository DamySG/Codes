package com.ff.dao;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hsg.pojos.Managerrole;

/**
 * A data access object (DAO) providing persistence and search support for
 * Managerrole entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see com.hsg.pojos.Managerrole
 * @author MyEclipse Persistence Tools
 */

public class ManagerroleDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(ManagerroleDAO.class);
	// property constants
	public static final String MANAGERROLENAME = "managerrolename";
	public static final String MANAGERSTATE = "managerstate";
	public static final String _REXTENDONE = "RExtendone";
	public static final String _REXTENDTWO = "RExtendtwo";
	public static final String _REXTENDTHREE = "RExtendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Managerrole transientInstance) {
		log.debug("saving Managerrole instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Managerrole persistentInstance) {
		log.debug("deleting Managerrole instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Managerrole findById(java.lang.Integer id) {
		log.debug("getting Managerrole instance with id: " + id);
		try {
			Managerrole instance = (Managerrole) getHibernateTemplate().get(
					"com.hsg.pojos.Managerrole", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Managerrole instance) {
		log.debug("finding Managerrole instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Managerrole instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Managerrole as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByManagerrolename(Object managerrolename) {
		return findByProperty(MANAGERROLENAME, managerrolename);
	}

	public List findByManagerstate(Object managerstate) {
		return findByProperty(MANAGERSTATE, managerstate);
	}

	public List findByRExtendone(Object RExtendone) {
		return findByProperty(_REXTENDONE, RExtendone);
	}

	public List findByRExtendtwo(Object RExtendtwo) {
		return findByProperty(_REXTENDTWO, RExtendtwo);
	}

	public List findByRExtendthree(Object RExtendthree) {
		return findByProperty(_REXTENDTHREE, RExtendthree);
	}

	public List findAll() {
		log.debug("finding all Managerrole instances");
		try {
			String queryString = "from Managerrole";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Managerrole merge(Managerrole detachedInstance) {
		log.debug("merging Managerrole instance");
		try {
			Managerrole result = (Managerrole) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Managerrole instance) {
		log.debug("attaching dirty Managerrole instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Managerrole instance) {
		log.debug("attaching clean Managerrole instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static ManagerroleDAO getFromApplicationContext(
			ApplicationContext ctx) {
		return (ManagerroleDAO) ctx.getBean("ManagerroleDAO");
	}
}