package com.ff.dao;

import java.util.List;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.hsg.pojos.Foodinfo;

/**
 * A data access object (DAO) providing persistence and search support for
 * Foodinfo entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see com.hsg.pojos.Foodinfo
 * @author MyEclipse Persistence Tools
 */

public class FoodinfoDAO extends BaseDao {
	private static final Log log = LogFactory.getLog(FoodinfoDAO.class);
	// property constants
	public static final String FOODNAME = "foodname";
	public static final String FOODIMG = "foodimg";
	public static final String DANJIA = "danjia";
	public static final String FOODCOIN = "foodcoin";
	public static final String MAINFOOD = "mainfood";
	public static final String TASTE = "taste";
	public static final String FOODNUMBER = "foodnumber";
	public static final String FOODREMARK = "foodremark";
	public static final String _FSTATE = "FState";
	public static final String _FJP = "FJp";
	public static final String EXTENDONE = "extendone";
	public static final String EXTENDTWO = "extendtwo";
	public static final String EXTENDTHREE = "extendthree";

	protected void initDao() {
		// do nothing
	}

	public void save(Foodinfo transientInstance) {
		log.debug("saving Foodinfo instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Foodinfo persistentInstance) {
		log.debug("deleting Foodinfo instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Foodinfo findById(java.lang.Integer id) {
		log.debug("getting Foodinfo instance with id: " + id);
		try {
			Foodinfo instance = (Foodinfo) getHibernateTemplate().get(
					"com.hsg.pojos.Foodinfo", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Foodinfo instance) {
		log.debug("finding Foodinfo instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Foodinfo instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Foodinfo as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByFoodname(Object foodname) {
		return findByProperty(FOODNAME, foodname);
	}

	public List findByFoodimg(Object foodimg) {
		return findByProperty(FOODIMG, foodimg);
	}

	public List findByDanjia(Object danjia) {
		return findByProperty(DANJIA, danjia);
	}

	public List findByFoodcoin(Object foodcoin) {
		return findByProperty(FOODCOIN, foodcoin);
	}

	public List findByMainfood(Object mainfood) {
		return findByProperty(MAINFOOD, mainfood);
	}

	public List findByTaste(Object taste) {
		return findByProperty(TASTE, taste);
	}

	public List findByFoodnumber(Object foodnumber) {
		return findByProperty(FOODNUMBER, foodnumber);
	}

	public List findByFoodremark(Object foodremark) {
		return findByProperty(FOODREMARK, foodremark);
	}

	public List findByFState(Object FState) {
		return findByProperty(_FSTATE, FState);
	}

	public List findByFJp(Object FJp) {
		return findByProperty(_FJP, FJp);
	}

	public List findByExtendone(Object extendone) {
		return findByProperty(EXTENDONE, extendone);
	}

	public List findByExtendtwo(Object extendtwo) {
		return findByProperty(EXTENDTWO, extendtwo);
	}

	public List findByExtendthree(Object extendthree) {
		return findByProperty(EXTENDTHREE, extendthree);
	}

	public List findAll() {
		log.debug("finding all Foodinfo instances");
		try {
			String queryString = "from Foodinfo";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Foodinfo merge(Foodinfo detachedInstance) {
		log.debug("merging Foodinfo instance");
		try {
			Foodinfo result = (Foodinfo) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Foodinfo instance) {
		log.debug("attaching dirty Foodinfo instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Foodinfo instance) {
		log.debug("attaching clean Foodinfo instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static FoodinfoDAO getFromApplicationContext(ApplicationContext ctx) {
		return (FoodinfoDAO) ctx.getBean("FoodinfoDAO");
	}
}