package com.ff.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * 初始化配置文件
 * @author hushiguo
 *
 */
public class Config extends Properties{
	
	private static Config config;
	
	public static void init(String file) throws FileNotFoundException, IOException{
		config=new Config();
		config.load(new FileInputStream(file));
	}
	
	public static Config getConfig(){
		return config;
	}
	
}
