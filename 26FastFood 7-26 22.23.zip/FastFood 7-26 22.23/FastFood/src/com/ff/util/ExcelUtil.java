package com.ff.util;


import java.io.File;
import java.util.Date;

import org.apache.poi.hssf.dev.HSSF;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.DateTime;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 * 导入导出  
 * @author hushiguo
 */
public class ExcelUtil {
   
	/**
	 * 导出Excel文件
	 * authors:周钢
	 * @param exportFile 导出的文件
	 * @param sheetName  工作表名
	 * @param title      标题名(表头)
	 * @param type       数据类型
	 * @param strContent 数据内容
	 * @param bufMsg     返回的错误信息
	 * @return
	 */
	public synchronized static boolean exportExcel(String exportFile,
			String sheetName,String[] title,
			String []type,Object[][] strContent,
			StringBuffer bufMsg){
		//对传入的标题，文件的合法性做校验
		if(title.length!=strContent[0].length){
			bufMsg.append("标题与内容列数不一致！");
			return false;
		}
		
		if(title.length!=type.length){
			bufMsg.append("标题与内容列数不一致！");
			return false;
		}
		if(!"xls".equalsIgnoreCase(exportFile.substring(exportFile.lastIndexOf(".")+1))){
			bufMsg.append("文件的后缀名必须是XLS或xls！");
			return false;
		}
		//初始化Excel文件
		File excelFile=new File(exportFile);
		if(sheetName==null || "".equals(sheetName)){
			bufMsg.append("工作表名称不能为空！");
			return false;
		}
		WritableWorkbook wwb=null;
		try {
			//创建EXCEL工作表
			wwb = Workbook.createWorkbook(excelFile);
			WritableSheet ws = wwb.createSheet(sheetName, 0);
			int len=title.length;
			//设置工作表的字体和格式
			WritableFont fontTitle = new jxl.write.WritableFont(WritableFont.ARIAL, 14, WritableFont.BOLD, true);
			WritableFont fontContent = new jxl.write.WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, true);
			fontTitle.setItalic(false);
			fontContent.setItalic(false);
			WritableCellFormat formatTitle = new WritableCellFormat(fontTitle);
			WritableCellFormat formatContent = new WritableCellFormat(fontContent);
			//添加第一行标题
			for (int i = 0; i <len; i++) {
				Label labelTitle = new Label(i, 0, title[i], formatTitle);
				ws.addCell(labelTitle);
			}
			//添加EXCEL内容
			for (int i = 0; i <strContent.length; i++) {
				for (int j = 0; j < strContent[0].length; j++) {
					String strXX=strContent[i][j]==null?"":strContent[i][j].toString();
					if("string".equalsIgnoreCase(type[j])){
						Label labelContent=new Label(j, i+1,strXX,formatContent);
						ws.addCell(labelContent);
					}
					else if("number".equalsIgnoreCase(type[j])){
						Number lblnumber = new Number(0, 1, Double.parseDouble(strXX));
						ws.addCell(lblnumber);
					}
					else if("date".equalsIgnoreCase(type[j])){
						Date date=new Date(strXX);
						DateTime lbldate = new DateTime(0, 3, date);
						ws.addCell(lbldate);
					}
				}
			}
			//写入Exel工作表
			wwb.write();
			
		} catch (Exception e) {
			//LogUtil.getLogger().error("写Excel信息出错！",e);
			return false;
			// TODO: handle exception
		}
		finally{
			//关闭Excel工作薄对象
			try {
				wwb.close();
			} catch (Exception e) {
				//LogUtil.getLogger().error(e.getMessage());
				// TODO: handle exception
			}
		}
		return true;
	}
	
	/**
	 * 导入
	 * @param file    文件对象
	 * @param bufMsg  错误信息
	 * @return 二维数组[行][单元格]
	 */
	public synchronized static Object[][] getExcelData(File file,StringBuffer bufMsg){
		Object[][] obj=null;
		WorkbookSettings ws=new WorkbookSettings();
		Workbook  wb=null;
		try {
			//创建工作表
			wb = Workbook.getWorkbook(file,ws);
			if(wb==null){
				bufMsg.append("没有找到Excel文件");
				return null;
			}
			Sheet sheet =wb.getSheet(0);
			String strSheetName=sheet.getName();
			if(strSheetName==null || "".equals(strSheetName)){
				bufMsg.append("没有找到工作表");
				return null;
			}
			//获取工作表的数据
			int intCol=sheet.getColumns();
			int intRow=sheet.getRows();
			obj=new Object[intRow][intCol];
			//读取列
			for (int i = 0; i < intRow; i++) {
				//读取行
				for (int j = 0; j < intCol; j++) {
					String strContent=sheet.getCell(j,i).getContents();
					obj[i][j]=strContent;
				}
			}
		} catch (Exception e) {
			//LogUtil.getLogger().error("获取Excel数据信息出错！",e);
			bufMsg.append("获取Excel数据信息出错!");
			e.printStackTrace();
			return null;
		}
		finally{
			wb.close();
		}
		return obj;
	}
	
	/**
	 * authors:Administrator
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
