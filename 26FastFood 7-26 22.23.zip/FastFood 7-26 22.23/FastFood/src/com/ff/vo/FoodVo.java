package com.ff.vo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.hsg.pojos.Foodtype;
import com.hsg.pojos.Manager;
import com.hsg.pojos.Userinfo;

/**
 * 商品Vo
 * @author hushiguo
 *
 */
public class FoodVo {

	//商品信息
	private Integer foodid;
	private Foodtype foodtype;
	private String foodname;
	private String foodimg;
	private Double danjia;
	private Integer foodcoin;
	private String mainfood;
	private String taste;
	private Integer foodnumber;
	private String foodremark;
	private Integer FState;
	private String FJp;
	private String extendone;
	private String extendtwo;
	private Integer extendthree;
	private Set advices = new HashSet(0);

	
    //订单信息
	private String OId;
	private Manager manager;
	private Userinfo userinfo;
	private String OPaymethod;
	private String OSendtype;
	private String OSendaddress;
	private String OName;
	private String OPhone;
	private String OPost;
	private String OEmail;
	private Date OOrderdate;
	private Integer OCheck;
	private Integer OJiezhang;
	private Integer OState;
	private String ORemark;
	private String OExtendone;
	private String OExtendtwo;
	private Integer OExtendthree;
	private Set ordersdetails = new HashSet(0);

	//用户信息
	private Integer userid;
	private String username;
	private String pwd;
	private Integer sex;
	private Date registerdate;
	private String photos;
	private String address;
	private String email;
	private String telephone;
	private Date lastlogin;
	private Integer logintime;
	private Integer usercoin;
	private Integer userstate;
	private String userjp;
	private String URemarks;
	private Double UExtendone;
	private String UExtendtwo;
	private String UExtendthree;
	private Set orderses = new HashSet(0);
	public Integer getFoodid() {
		return foodid;
	}
	public void setFoodid(Integer foodid) {
		this.foodid = foodid;
	}
	public Foodtype getFoodtype() {
		return foodtype;
	}
	public void setFoodtype(Foodtype foodtype) {
		this.foodtype = foodtype;
	}
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public String getFoodimg() {
		return foodimg;
	}
	public void setFoodimg(String foodimg) {
		this.foodimg = foodimg;
	}
	public Double getDanjia() {
		return danjia;
	}
	public void setDanjia(Double danjia) {
		this.danjia = danjia;
	}
	public Integer getFoodcoin() {
		return foodcoin;
	}
	public void setFoodcoin(Integer foodcoin) {
		this.foodcoin = foodcoin;
	}
	public String getMainfood() {
		return mainfood;
	}
	public void setMainfood(String mainfood) {
		this.mainfood = mainfood;
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public Integer getFoodnumber() {
		return foodnumber;
	}
	public void setFoodnumber(Integer foodnumber) {
		this.foodnumber = foodnumber;
	}
	public String getFoodremark() {
		return foodremark;
	}
	public void setFoodremark(String foodremark) {
		this.foodremark = foodremark;
	}
	public Integer getFState() {
		return FState;
	}
	public void setFState(Integer fState) {
		FState = fState;
	}
	public String getFJp() {
		return FJp;
	}
	public void setFJp(String fJp) {
		FJp = fJp;
	}
	public String getExtendone() {
		return extendone;
	}
	public void setExtendone(String extendone) {
		this.extendone = extendone;
	}
	public String getExtendtwo() {
		return extendtwo;
	}
	public void setExtendtwo(String extendtwo) {
		this.extendtwo = extendtwo;
	}
	public Integer getExtendthree() {
		return extendthree;
	}
	public void setExtendthree(Integer extendthree) {
		this.extendthree = extendthree;
	}
	public Set getAdvices() {
		return advices;
	}
	public void setAdvices(Set advices) {
		this.advices = advices;
	}
	public String getOId() {
		return OId;
	}
	public void setOId(String oId) {
		OId = oId;
	}
	public Manager getManager() {
		return manager;
	}
	public void setManager(Manager manager) {
		this.manager = manager;
	}
	public Userinfo getUserinfo() {
		return userinfo;
	}
	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}
	public String getOPaymethod() {
		return OPaymethod;
	}
	public void setOPaymethod(String oPaymethod) {
		OPaymethod = oPaymethod;
	}
	public String getOSendtype() {
		return OSendtype;
	}
	public void setOSendtype(String oSendtype) {
		OSendtype = oSendtype;
	}
	public String getOSendaddress() {
		return OSendaddress;
	}
	public void setOSendaddress(String oSendaddress) {
		OSendaddress = oSendaddress;
	}
	public String getOName() {
		return OName;
	}
	public void setOName(String oName) {
		OName = oName;
	}
	public String getOPhone() {
		return OPhone;
	}
	public void setOPhone(String oPhone) {
		OPhone = oPhone;
	}
	public String getOPost() {
		return OPost;
	}
	public void setOPost(String oPost) {
		OPost = oPost;
	}
	public String getOEmail() {
		return OEmail;
	}
	public void setOEmail(String oEmail) {
		OEmail = oEmail;
	}
	public Date getOOrderdate() {
		return OOrderdate;
	}
	public void setOOrderdate(Date oOrderdate) {
		OOrderdate = oOrderdate;
	}
	public Integer getOCheck() {
		return OCheck;
	}
	public void setOCheck(Integer oCheck) {
		OCheck = oCheck;
	}
	public Integer getOJiezhang() {
		return OJiezhang;
	}
	public void setOJiezhang(Integer oJiezhang) {
		OJiezhang = oJiezhang;
	}
	public Integer getOState() {
		return OState;
	}
	public void setOState(Integer oState) {
		OState = oState;
	}
	public String getORemark() {
		return ORemark;
	}
	public void setORemark(String oRemark) {
		ORemark = oRemark;
	}
	public String getOExtendone() {
		return OExtendone;
	}
	public void setOExtendone(String oExtendone) {
		OExtendone = oExtendone;
	}
	public String getOExtendtwo() {
		return OExtendtwo;
	}
	public void setOExtendtwo(String oExtendtwo) {
		OExtendtwo = oExtendtwo;
	}
	public Integer getOExtendthree() {
		return OExtendthree;
	}
	public void setOExtendthree(Integer oExtendthree) {
		OExtendthree = oExtendthree;
	}
	public Set getOrdersdetails() {
		return ordersdetails;
	}
	public void setOrdersdetails(Set ordersdetails) {
		this.ordersdetails = ordersdetails;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Integer getSex() {
		return sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}
	public Date getRegisterdate() {
		return registerdate;
	}
	public void setRegisterdate(Date registerdate) {
		this.registerdate = registerdate;
	}
	public String getPhotos() {
		return photos;
	}
	public void setPhotos(String photos) {
		this.photos = photos;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public Date getLastlogin() {
		return lastlogin;
	}
	public void setLastlogin(Date lastlogin) {
		this.lastlogin = lastlogin;
	}
	public Integer getLogintime() {
		return logintime;
	}
	public void setLogintime(Integer logintime) {
		this.logintime = logintime;
	}
	public Integer getUsercoin() {
		return usercoin;
	}
	public void setUsercoin(Integer usercoin) {
		this.usercoin = usercoin;
	}
	public Integer getUserstate() {
		return userstate;
	}
	public void setUserstate(Integer userstate) {
		this.userstate = userstate;
	}
	public String getUserjp() {
		return userjp;
	}
	public void setUserjp(String userjp) {
		this.userjp = userjp;
	}
	public String getURemarks() {
		return URemarks;
	}
	public void setURemarks(String uRemarks) {
		URemarks = uRemarks;
	}
	public Double getUExtendone() {
		return UExtendone;
	}
	public void setUExtendone(Double uExtendone) {
		UExtendone = uExtendone;
	}
	public String getUExtendtwo() {
		return UExtendtwo;
	}
	public void setUExtendtwo(String uExtendtwo) {
		UExtendtwo = uExtendtwo;
	}
	public String getUExtendthree() {
		return UExtendthree;
	}
	public void setUExtendthree(String uExtendthree) {
		UExtendthree = uExtendthree;
	}
	public Set getOrderses() {
		return orderses;
	}
	public void setOrderses(Set orderses) {
		this.orderses = orderses;
	}
	public FoodVo(Integer foodid, Foodtype foodtype, String foodname,
			String foodimg, Double danjia, Integer foodcoin, String mainfood,
			String taste, Integer foodnumber, String foodremark,
			Integer fState, String fJp, String extendone, String extendtwo,
			Integer extendthree, Set advices, String oId, Manager manager,
			Userinfo userinfo, String oPaymethod, String oSendtype,
			String oSendaddress, String oName, String oPhone, String oPost,
			String oEmail, Date oOrderdate, Integer oCheck, Integer oJiezhang,
			Integer oState, String oRemark, String oExtendone,
			String oExtendtwo, Integer oExtendthree, Set ordersdetails,
			Integer userid, String username, String pwd, Integer sex,
			Date registerdate, String photos, String address, String email,
			String telephone, Date lastlogin, Integer logintime,
			Integer usercoin, Integer userstate, String userjp,
			String uRemarks, Double uExtendone, String uExtendtwo,
			String uExtendthree, Set orderses) {
		super();
		this.foodid = foodid;
		this.foodtype = foodtype;
		this.foodname = foodname;
		this.foodimg = foodimg;
		this.danjia = danjia;
		this.foodcoin = foodcoin;
		this.mainfood = mainfood;
		this.taste = taste;
		this.foodnumber = foodnumber;
		this.foodremark = foodremark;
		FState = fState;
		FJp = fJp;
		this.extendone = extendone;
		this.extendtwo = extendtwo;
		this.extendthree = extendthree;
		this.advices = advices;
		OId = oId;
		this.manager = manager;
		this.userinfo = userinfo;
		OPaymethod = oPaymethod;
		OSendtype = oSendtype;
		OSendaddress = oSendaddress;
		OName = oName;
		OPhone = oPhone;
		OPost = oPost;
		OEmail = oEmail;
		OOrderdate = oOrderdate;
		OCheck = oCheck;
		OJiezhang = oJiezhang;
		OState = oState;
		ORemark = oRemark;
		OExtendone = oExtendone;
		OExtendtwo = oExtendtwo;
		OExtendthree = oExtendthree;
		this.ordersdetails = ordersdetails;
		this.userid = userid;
		this.username = username;
		this.pwd = pwd;
		this.sex = sex;
		this.registerdate = registerdate;
		this.photos = photos;
		this.address = address;
		this.email = email;
		this.telephone = telephone;
		this.lastlogin = lastlogin;
		this.logintime = logintime;
		this.usercoin = usercoin;
		this.userstate = userstate;
		this.userjp = userjp;
		URemarks = uRemarks;
		UExtendone = uExtendone;
		UExtendtwo = uExtendtwo;
		UExtendthree = uExtendthree;
		this.orderses = orderses;
	}
	public FoodVo() {
		super();
	}

	
	
}
