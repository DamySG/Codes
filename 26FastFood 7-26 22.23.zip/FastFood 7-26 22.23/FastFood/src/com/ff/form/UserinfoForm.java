package com.ff.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
/**
 * 用户信息actionform 类
 * @author 失色季節。
 *
 */
public class UserinfoForm extends ActionForm{
   // 头像
   private FormFile photos;

	public FormFile getPhotos() {
		return photos;
	}
	
	public void setPhotos(FormFile photos) {
		this.photos = photos;
	}

	public UserinfoForm(FormFile photos) {
		super();
		this.photos = photos;
	}

	public UserinfoForm() {
		super();
	}
   
   
}
