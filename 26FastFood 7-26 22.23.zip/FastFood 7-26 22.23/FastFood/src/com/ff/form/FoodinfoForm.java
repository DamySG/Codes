package com.ff.form;

import org.apache.struts.action.ActionForm;
import org.apache.struts.upload.FormFile;
/**
 * 商品信息actionform 类
 * @author 失色季節。
 *
 */
public class FoodinfoForm extends ActionForm{
   // 头像
   private FormFile foodImg;

	public FoodinfoForm(FormFile foodImg) {
		super();
		this.foodImg = foodImg;
	}
	
		public FormFile getFoodImg() {
		return foodImg;
	}
	
	
	public void setFoodImg(FormFile foodImg) {
		this.foodImg = foodImg;
	}

	public FoodinfoForm() {
		super();
	}
   
   
}
