package com.ff.action;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IManagerRoleService;
import com.ff.iservices.IManagerService;
import com.ff.iservices.ITreeMenuService;
import com.ff.services.TreeMenuService;
import com.hsg.pojos.Manager;
import com.hsg.pojos.Managerrole;
import com.hsg.pojos.Treemenu;

/**
 * 管理员角色action
 * @author hushiguo
 *
 */
public class ManagerRoleAction extends DispatchAction {

	private IManagerService managerService;
	private IManagerRoleService managerRoleService;
	private ITreeMenuService treemenuService;
		
	public void setTreemenuService(ITreeMenuService treemenuService) {
		this.treemenuService = treemenuService;
	}	 
		
	
	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}
	public void setManagerRoleService(IManagerRoleService managerRoleService) {
		this.managerRoleService = managerRoleService;
	}
	
	/*
	 * 给角色添加权限菜单
	 */
	public ActionForward addTreeMenuByRoleId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try {
			String roleId=request.getParameter("roleId");   //角色编号
			String [] menuId=request.getParameterValues("array"); //树形父级菜单编号数组
			for (int i = 0; i < menuId.length; i++) {
				System.out.println(menuId[i]);
			}
			if(roleId!=null&&!roleId.equals("")&&menuId!=null){
				managerRoleService.addTreeMenuByRoleId(Integer.parseInt(roleId), menuId);
				out.print("{bol:true,msg:'修改成功!'}");
			}else{
				out.print("{bol:false,msg:'修改失败!'}");
			}
		
		} catch (Exception e) {
			out.print("{bol:false,msg:'修改失败!'}");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	/*
	 * 查询所有角色
	 */
	public ActionForward findAllRole(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		String i=request.getParameter("i");
		try {
			//查询出所有角色
			List<Managerrole> roleList=managerRoleService.findAllManagerRole2();
            request.setAttribute("roleList", roleList);
            if(Integer.parseInt(i)==1){
            	//跳转到后台显示角色信息页面
     		   return new ActionForward("/admin/view/RoleInfo.jsp");
			}else{
				List<Treemenu>  listTreeMenu=treemenuService.findAllTreeMenu();
				List<Treemenu>  ParentMenu=treemenuService.findParentMenu();
				request.setAttribute("listTreeMenu", listTreeMenu); //所有菜单
				request.setAttribute("ParentMenu", ParentMenu); //父级菜单
				//跳转到后台显示角色信息页面
			   return new ActionForward("/admin/view/MenuInfo.jsp");
			}
		
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	

	/*
	 * 添加角色   
	 * 如果id为空   
	 * 则进行增加操作，
	 * 否则作修改操作
	 */
	public ActionForward addRole(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String roleName=request.getParameter("roleName"); //角色名称
		String remark=request.getParameter("remark"); //备注
		String roleId=request.getParameter("roleId"); //角色名称
		
		try {
			if(roleName!=null&&!roleName.equals("")){
				Managerrole role=managerRoleService.findRoleByName(roleName);
				if(role!=null){
					out.print("{bol:true,msg:'角色名称已存在'}");
				}else{
					if(roleId==null||roleId.equals("null")){  //如果id为 空则进行增加操作， 否则作修改操作
						Managerrole role2=new Managerrole(roleName,1,remark);
						managerRoleService.addRole(role2);
						out.print("{bol:false,msg:'"+role2.getManagerroleid()+"'}");  //把id传回去
					}else{
						Managerrole role3=new Managerrole(roleName,1,remark);
						managerRoleService.updateRole(Integer.parseInt(roleId),role3);
						out.print("{bol:false,msg:'"+role3.getManagerroleid()+"'}");  //把id传回去
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	

	/*
	 * 删除角色
	 */
	public ActionForward deleteRole(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String roleId=request.getParameter("roleId"); //角色编号
		
		try {
			if(roleId==null||roleId.equals("null")){
				out.print("{bol:false,msg:'删除失败'}");
			}else{
				managerRoleService.deleteRole(Integer.parseInt(roleId));
				out.print("{bol:true,msg:'删除成功'}");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据名称查询角色信息
	 */
	public ActionForward queryRoleByName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
			String roleName=request.getParameter("roleName");
			List<Managerrole> roleList =null;
			try {
				if(roleName==null||roleName.equals("")){
					roleList=managerRoleService.findAllManagerRole2();
				}else{
					roleList=managerRoleService.findRoleByName2(roleName);
				}
				request.setAttribute("roleList", roleList);
				//跳转到后台显示角色信息页面
				 return new ActionForward("/admin/view/RoleInfo.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return null;
	}
	
	
}
