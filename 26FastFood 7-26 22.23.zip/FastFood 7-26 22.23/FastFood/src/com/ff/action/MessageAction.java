package com.ff.action;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IMessageService;
import com.hsg.pojos.Message;
import com.hsg.pojos.PageBean;

/**
 * 留言action
 * @author hushiguo
 *
 */
public class MessageAction extends DispatchAction{

	private IMessageService messageService;

	public void setMessageService(IMessageService messageService) {
		this.messageService = messageService;
	}
	
	/**
	 * 查询所有留言信息
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward findAllMessage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
			
		try {
			String msid=request.getParameter("msid");
			String currentPage=request.getParameter("page");
			
			PageBean pb = messageService.findAllMessage(
					Integer.parseInt(currentPage),Integer.parseInt(msid));
			
			request.setAttribute("pb", pb);
			
			
			if(Integer.parseInt(msid)==1){
				return new ActionForward("/view/clientMessage.jsp");
			}else{
				return new ActionForward("/admin/view/Messageinfo.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	/**
	 * 根据标题分页查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByTitle(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String title = request.getParameter("msTitle"); //账户名称 
			String currentPage=request.getParameter("page");
			
			PageBean pb = messageService.queryByTitle(
					Integer.parseInt(currentPage),
					title);
			request.setAttribute("title", title);
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Messageinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 按时间查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByDate(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		try {
			String startDate=request.getParameter("startDate");  //开始日期
			String stopDate=request.getParameter("stopDate");  //结束日期
			String currentPage=request.getParameter("page");
			
			Date date1=null;
			Date date2=null;
			
			//装换成date，类型
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			if(!(startDate==null||startDate.equals(""))&&!(stopDate==null||stopDate.equals(""))){
				date1=sf.parse(startDate);
				date2=sf.parse(stopDate);
			}
				
				PageBean pb = messageService.queryByDate(
						Integer.parseInt(currentPage),
						date1,
						date2);
				
				request.setAttribute("date1", date1);
				request.setAttribute("date2", date2);
				request.setAttribute("pb", pb);
				return new ActionForward("/admin/view/Messageinfo.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	}
	
	/**
	 * 根据 id删除数据
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		try {
			String []messageid = request.getParameterValues("checkBox");
			for (String msId : messageid) {
				messageService.deleteById(Integer.parseInt(msId));
			}
			out.print("<script>alert(\"删除成功!\");location=\"/FastFood/message.do?p=findAllMessage&msid=2&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"删除失败!\");location=\"/FastFood/message.do?p=findAllMessage&msid=2&page=1\"</script>");
		}
		return null;
	}
	
	/**
	 * 添加留言
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward addMessage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String usrname = request.getParameter("usrname");
			String title = request.getParameter("title");
			String tx = request.getParameter("tx");
			String email = request.getParameter("email");
			String qq = request.getParameter("qq");
			String memo = request.getParameter("memo");
			
			//日期转换，添加到扩展列msExtendone中。
			SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String msdate=df.format(new Date());
			
			Message message = new Message(
					title,
					usrname,
					email,
					qq,
					tx,
					memo,
					msdate,
					1);
			
		messageService.addMessage(message);	
		return new ActionForward("/message.do?p=findAllMessage&msid=1&page=1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
