package com.ff.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IAccountService;
import com.ff.iservices.IBankTypeService;

/**
 * 账户action
 * @author hushiguo
 *
 */
public class AccountsAction extends DispatchAction{

	private IAccountService accountService;
	private IBankTypeService bankTypeService;
	public void setAccountService(IAccountService accountService) {
		this.accountService = accountService;
	}
	public void setBankTypeService(IBankTypeService bankTypeService) {
		this.bankTypeService = bankTypeService;
	}
	
	/*
	 * 查询某银行的某账户信息
	 */
	public ActionForward findAccountById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
}
