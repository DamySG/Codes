package com.ff.action;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.FormFile;

import com.ff.form.FoodinfoForm;
import com.ff.iservices.IAdviceService;
import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IFoodtypeService;
import com.hsg.pojos.FoodInfoBean;
import com.hsg.pojos.Foodinfo;
import com.hsg.pojos.Foodtype;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Userinfo;

/**
 * 商品信息action(做什么)
 * @author hushiguo
 *  
 */
public class FoodinfoAction extends DispatchAction{
 
	private IFoodinfoService foodInfoService;
	private IFoodtypeService foodTypeServive;
	private IAdviceService adviceService;
	
	
	public void setAdviceService(IAdviceService adviceService) {
		this.adviceService = adviceService;
	}
	public void setFoodInfoService(IFoodinfoService foodInfoService) {
		this.foodInfoService = foodInfoService;
	}
	public void setFoodTypeServive(IFoodtypeService foodTypeServive) {
		this.foodTypeServive = foodTypeServive;
	}
	
	/**
	 * 增加商品信息时先查询所有商品类型 
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByAdd(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
        try {
			List<Foodtype> foodTypeList=foodTypeServive.findAllFoodType2();		
			if(foodTypeList!=null){
				request.setAttribute("foodTypeList", foodTypeList);
				return new ActionForward("/admin/view/addFoodInfo.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ActionForward("/admin/view/addFoodInfo.jsp");
		}
		return null;
		
	}
	
	
	/**
	 * 修改商品信息 
	 * @return
	 * @throws Exception
	 */
	public ActionForward UpdateFoodInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		    PrintWriter out=response.getWriter();
		    String foodId=request.getParameter("foodId"); //商品名称
		    String foodname=request.getParameter("foodName"); //商品名称
		    String danjia=request.getParameter("danjia");  //单价
		    String foodNumber=request.getParameter("foodNumber"); //库存
		    String foodCoin=request.getParameter("foodCoin"); //积分
		    String mainFood=request.getParameter("mainFood"); //主料
		    String taste=request.getParameter("taste"); //口味
		    String typeId=request.getParameter("typeSel"); //类别编号
		    String foodRemark=request.getParameter("foodRemark"); //描述
		    String Img1=request.getParameter("foodimg2"); //原始图片
			String Img2=getUploadImg(request,form);  //获得上传图片
			
			String foodImg="";
			if(Img2!=null&&Img2!=""){  //如果上传了新图片 则保持新图片  否则保存原来的图片
				foodImg=Img2;
			}else{
				foodImg=Img1;
			}
			
		 try {
				Double danjia2=0.0;
				if(danjia!=null){
					danjia2=Double.parseDouble(danjia);
				}
				
				Foodtype type=foodTypeServive.findFoodTypeById(Integer.parseInt(typeId));		
				Foodinfo food=new Foodinfo(type,
						foodname,
						foodImg,
						danjia2,
						Integer.parseInt(foodCoin),
						mainFood,
						taste,
						Integer.parseInt(foodNumber),
						foodRemark,
						1);
			    foodInfoService.updateFoodInfo(Integer.parseInt(foodId), food);
			    out.print("<script>alert('修改成功!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
			} catch (Exception e) {
				 out.print("<script>alert('修改失败!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	}
	
	
	/**
	 * 查询修改商品信息 
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByUpdate(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		 String foodId=request.getParameter("foodId");
		 try {
			    Foodinfo food=foodInfoService.findFoodInfoById(Integer.parseInt(foodId));
				List<Foodtype> foodTypeList=foodTypeServive.findAllFoodType2();		
				request.setAttribute("foodTypeList", foodTypeList);
				request.setAttribute("food", food);
				return new ActionForward("/admin/view/UpdateFoodInfo.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return new ActionForward("/admin/view/UpdateFoodInfo.jsp");
			}
	}
	
	public String getUploadImg(HttpServletRequest request,ActionForm form){
		//获得form
		String foodImg="";
		try {
			FoodinfoForm frm =(FoodinfoForm) form;
			//获得提交的文件对象
			FormFile ff=frm.getFoodImg();
			//获得文件字节流
			byte []b =ff.getFileData();
			//获得上传文件名
			String fileName=ff.getFileName();
			//获得upload文件夹的真实路径
			String filePath=request.getSession().getServletContext().getRealPath("/images/food");
			//获得随机文件名
			String randomName=UUID.randomUUID().toString();
			//获得上传文件的后缀名
			String fix="";
			FileOutputStream fos=null;
			if(fileName!=null&&!fileName.equals("")){
			    fix=fileName.substring(fileName.lastIndexOf("."));
			   //创建输出文件的输出流
				fos=new FileOutputStream(filePath+"/"+randomName+fix);
				//获得真实的文件名
			    foodImg=randomName+fix;   //图片
			}
			if(b!=null){
				//写出输出流
				fos.write(b);	
			}
			//关闭
			fos.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return foodImg;
		}
		 return foodImg;
	}
	
	
	/**
	 * 增加商品信息 
	 * @return
	 * @throws Exception
	 */
	public ActionForward addFoodInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		PrintWriter out=response.getWriter();
		String foodImg=getUploadImg(request,form);  //获得上传图片
	    
	    String foodname=request.getParameter("foodName"); //商品名称
	    String danjia=request.getParameter("danjia");  //单价
	    String foodNumber=request.getParameter("foodNumber"); //库存
	    String foodCoin=request.getParameter("foodCoin"); //积分
	    String mainFood=request.getParameter("mainFood"); //主料
	    String taste=request.getParameter("taste"); //口味
	    String typeId=request.getParameter("typeSel"); //类别编号
	    String foodRemark=request.getParameter("foodRemark"); //描述
	    
	    try {
			Foodtype type=foodTypeServive.findFoodTypeById(Integer.parseInt(typeId));
			
			Double danjia2=0.0;
			if(danjia!=null){
				danjia2=Double.parseDouble(danjia);
			}
			
			Foodinfo food=new Foodinfo(type,
					foodname,
					foodImg,
					danjia2,
					Integer.parseInt(foodCoin),
					mainFood,
					taste,
					Integer.parseInt(foodNumber),
					foodRemark,
					1);
			foodInfoService.addFoodInfo(food);
			out.print("<script>alert('新增成功!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
		} catch (Exception e) {
			out.print("<script>alert('新增失败!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	    
        return null;
	
	}
	
	
	/**
	 * 删除商品信息 即将状态修改为2 
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteFoodInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		  PrintWriter out=response.getWriter();
	        //获得要删除的商品编号
		  String [] foodId=request.getParameterValues("checkBox");
		  String typeId=request.getParameter("typeId");
		  try {
				if(foodId!=null){
					for (String oId : foodId) {
						//循环删除
						foodInfoService.deleteFoodInfo(Integer.parseInt(oId));
					}
					if(typeId!=null&!typeId.equals("")){
						out.print("<script>alert('删除成功!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
					}else{
						out.print("<script>alert('删除成功!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=0&currentPage=1';</script>");
					}
				}
			} catch (Exception e) {
				if(typeId!=null&!typeId.equals("")){
					out.print("<script>alert('删除失败!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=1&currentPage=1&foodTypeId="+Integer.parseInt(typeId)+"';</script>");
				}else{
					out.print("<script>alert('删除失败!');location='/FastFood/foodInfo.do?p=findFoodInfoByPage&i=0&currentPage=1';</script>");
				}
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return null;	
	}
	
	
	
	/**
	 * 分页查询商品信息
	 * @return
	 * @throws Exception
	 */
	public ActionForward findFoodInfoByPage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		String foodTypeId=request.getParameter("foodTypeId");  //商品类型编号
		String currentPage=request.getParameter("currentPage");  //商品类型编号
		String foodName=request.getParameter("foodName");  //商品类型编号
		String i=request.getParameter("i");  //i ==0  查询所有  i=1 则根据条件查询
		
		try {
			Integer currentPage2=1;
			if(currentPage!=null&&!currentPage.equals("")){
				currentPage2=Integer.parseInt(currentPage);
			}
			Integer i2=0;
			if(i!=null&&!i.equals("")){
				i2=Integer.parseInt(i);
			}
			Integer foodTypeId2=null;
			if(foodTypeId!=null&&!foodTypeId.equals("")){
				foodTypeId2=Integer.parseInt(foodTypeId);
			}
			
			Map<String,Object> map=foodInfoService.findFoodInfoByPage(
					foodTypeId2, 
					currentPage2, 
					i2,
					foodName);
			List<Foodtype> foodtypeList=foodTypeServive.findAllFoodType2();
			
//			List<Foodinfo> list= (List<Foodinfo>) map.get("list");
//			if(list!=null){
//				for (Foodinfo foodinfo : list) {
//					System.out.println(foodinfo.getFoodtype().getFTypename());
//				}
//			}
			request.setAttribute("map", map);
			request.setAttribute("foodtypeList", foodtypeList);
			request.setAttribute("foodTypeId", foodTypeId);  //把编号返回去 
			//跳转到商品信息页面(后台)
			return new ActionForward("/admin/view/foodType.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
		return null;
	}

	/**
	 * 判断是否登录，
	 * 登录了，就跳转到填写订单页面    否则，跳转到登录页面
	 * @return
	 * @throws Exception
	 */
	public ActionForward toOrderInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			//获得购物车
			Userinfo   user=(Userinfo)session.getAttribute("user");
			ShoppingCar   car=(ShoppingCar)session.getAttribute("car");
			request.setAttribute("user", user);
			request.setAttribute("car", car);
				//跳转到填写订单信息
			return new ActionForward("/foodInfo.do?p=findFoodInfoById&bigTypeId=1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/**
	 * 根据商品编号删除所购买的商品
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteCarByFoodId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			//要删除的商品编号
			String foodid=request.getParameter("foodid");
			//获得购物车
			ShoppingCar   car=(ShoppingCar)session.getAttribute("car");
			if(car!=null){
				//删除商品信息
				car.deleteFoodInfo(Integer.parseInt(foodid));
				//然后再保存到session中
			}
			session.setAttribute("car", car);
			//跳转到首页
			return new ActionForward("/foodInfo.do?p=findFoodInfoById&bigTypeId=1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	/**
	 * 清空购物车
	 * @return
	 * @throws Exception
	 */
	public ActionForward clearShoppingCar(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			//获得购物车
			ShoppingCar car=(ShoppingCar) session.getAttribute("car");
			//清空购物车
			car.clearShoppingCar();
			 //默认查询出自选订餐的单点餐品
		    Foodtype type=foodTypeServive.findFoodTypeByName("单点餐品");
		    //调用公用方法
			GongYong(request,type.getFTypeid(),type.getFBigtype());
			//跳转到首页
			return new ActionForward("/view/home.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 修改商品的购买数量(修改购物车)
	 * @return
	 * @throws Exception
	 */
	public ActionForward updateBuyNum(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			//要修改的商品编号
			String foodid=request.getParameter("foodid");
			//要修改的数量
			Integer buyNum=Integer.parseInt(request.getParameter("buyNum"));
			//获得购物车
			ShoppingCar   car=(ShoppingCar)session.getAttribute("car");
			//修改数量
			FoodInfoBean foodBean= car.getMap().get(Integer.parseInt(foodid));

			foodBean.setBuy(buyNum);
			//然后再保存到session中
			session.setAttribute("car", car);
			//跳转到首页
			return new ActionForward("/foodInfo.do?p=findFoodInfoById&bigTypeId=1");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 购买商品(添加到购物车)
	 * @return
	 * @throws Exception
	 */
	public ActionForward addShoppingInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		//先看看有没有购物记录   没有的话就创建一个购物车
		try {
			if(session.getAttribute("car")==null){
				session.setAttribute("car", new ShoppingCar());
			}
			
			//要购买的商品编号
			String foodId=request.getParameter("foodid");
			//获得商品信息
			Foodinfo foodinfo= foodInfoService.findFoodInfoById(Integer.parseInt(foodId));
			//购物详细资料，主要包括商品信息，购买数量
			FoodInfoBean foodBean=new FoodInfoBean(foodinfo,1);
			//从session中取得购物车对象
			ShoppingCar car=(ShoppingCar) session.getAttribute("car");
			//将商品添加到购物车
			car.addFoodInfo(foodBean);
			//然后再保存到session中
			session.setAttribute("car", car);
			GongYong(request,foodinfo.getFoodtype().getFTypeid(),foodinfo.getFoodtype().getFBigtype());
			return new ActionForward("/view/home.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/**
	 * 根据编号查询商品信息
	 * 
	 * @return
	 * @throws Exception
	 */
	public ActionForward findFoodInfoById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			//查询所有自选套餐的foodType信息    大类别编号 ： 1 自选套餐    2固定套餐   3 组合套餐
			String bigTypeId=request.getParameter("bigTypeId");
			
			//餐品小类别
			List<Foodtype> listType=null;
			List<Foodtype> listType3=null;
			//默认查询出自选订餐的单点餐品
			List<Foodinfo> listFood=null;
			//组合套餐(荤菜)
			List<Foodinfo> listFood2=null;
			//组合套餐(素菜)
			List<Foodinfo> listFood3=null;
			//组合套餐(汤菜)
			List<Foodinfo> listFood4=null;
			if(Integer.parseInt(bigTypeId)==1){
				 //默认查询出自选订餐的单点餐品
			     listFood=foodInfoService.findFoodInfoByTypeName("单点餐品");
			     listType=foodTypeServive.findFoodTypeByBigId(1);
			}else if(Integer.parseInt(bigTypeId)==2){
				 //默认查询出固定套餐的精品盖饭
			     listFood=foodInfoService.findFoodInfoByTypeName("精品盖饭");
			     listType=foodTypeServive.findFoodTypeByBigId(2);
			}else if(Integer.parseInt(bigTypeId)==3){
				 //默认查询出组合套餐的精品盖饭
			     listFood2=foodInfoService.findFoodInfoByTypeName("荤菜");
			     //默认查询出组合套餐的精品盖饭
			     listFood3=foodInfoService.findFoodInfoByTypeName("素菜");
			     //默认查询出组合套餐的精品盖饭
			     listFood4=foodInfoService.findFoodInfoByTypeName("汤菜");
			     listType3=foodTypeServive.findFoodTypeByBigId(3);
			}
   
   
			request.setAttribute("listType", listType);
			request.setAttribute("listFood", listFood);
			request.setAttribute("listFood2", listFood2);
			request.setAttribute("listFood3", listFood3);
			request.setAttribute("listFood4", listFood4);
			request.setAttribute("listType3", listType3);
			return new ActionForward("/view/home.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据商品类别编号查询商品信息
	 * @return
	 * @throws Exception
	 */
	public ActionForward findFoodInfoByTypeId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		try {
			//餐品类型编号
			String foodTypeId=request.getParameter("typeId");
			//查询所有自选套餐的foodType信息    大类别编号 ： 1 自选套餐    2固定套餐   3 组合套餐
			String bigTypeId=request.getParameter("bigTypeId");
			GongYong(request,Integer.parseInt(foodTypeId),Integer.parseInt(bigTypeId));
			return new ActionForward("/view/home.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 公用方法
	 * @return
	 * @throws Exception
	 */
	public void GongYong(HttpServletRequest request,Integer foodTypeId,Integer bigTypeId)
			throws Exception {
		// TODO Auto-generated method stub
	    try {
			//默认查询出自选订餐的单点餐品
			List<Foodinfo> listFood=foodInfoService.findFoodInfoByTypeId(foodTypeId);
			
			List<Foodtype> listType=null;
			List<Foodtype> listType3=null;
			//默认查询出自选订餐的单点餐品
			if(bigTypeId==3){
				 //默认查询出自选订餐的单点餐品
			     listType3=foodTypeServive.findFoodTypeByBigId(bigTypeId);
			}else{
				//默认查询出固定订餐的精品盖饭
			     listType=foodTypeServive.findFoodTypeByBigId(bigTypeId);
			}
   
			request.setAttribute("listType", listType);
			request.setAttribute("listType3", listType3);
			request.setAttribute("listFood", listFood);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
