package com.ff.action;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IManagerService;
import com.ff.iservices.ITreeMenuService;
import com.hsg.pojos.Treemenu;

public class TreeMenuAction extends DispatchAction{

	private ITreeMenuService treeMenuService;
	private IManagerService managerService;
	public void setTreeMenuService(ITreeMenuService treeMenuService) {
		this.treeMenuService = treeMenuService;
	}
	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}
	
	/*
	 * 根据角色编号查询树形菜单
	 */
	public ActionForward findMenuByRoleId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String roleId=request.getParameter("roleId");
		try {
			if(roleId!=null&&!roleId.equals("")){
				Set<Treemenu> tree=treeMenuService.findMenuByRoleId(Integer.parseInt(roleId));
				List<Integer> list=new ArrayList<Integer>();
				//Integer[]treeMenuId=new Integer[6];
				for (Treemenu treemenu : tree) {
					if(treemenu.getTreeprentid()==0){
						list.add(treemenu.getTreemenuid());
					}
				}
//				//将树形父级菜单编号保存到数组中
//				for (int i = 0; i < list.size(); i++) {
//					if(list.get(i).getTreeprentid()==0){
//						treeMenuId[i]=list.get(i).getTreemenuid();
//					}
//				}
//				System.out.println(treeMenuId);
//				for (int i = 0; i < treeMenuId.length; i++) {
//					 System.out.println(treeMenuId[i]);
//				}
				// out.print(treeMenuId);
//			    //返回json数组
//				JsonConfig config=new JsonConfig();
//			    JSONArray arry=JSONArray.fromObject(list,config);
			    out.print(list);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
}
