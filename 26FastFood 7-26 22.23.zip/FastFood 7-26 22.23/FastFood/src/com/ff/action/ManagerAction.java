package com.ff.action;

import java.io.PrintWriter;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IFoodtypeService;
import com.ff.iservices.IManagerRoleService;
import com.ff.iservices.IManagerService;
import com.ff.iservices.ITreeMenuService;
import com.hsg.pojos.Foodtype;
import com.hsg.pojos.Manager;
import com.hsg.pojos.Managerrole;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Treemenu;
import com.hsg.pojos.Userinfo;

public class ManagerAction extends DispatchAction {

	private IManagerService managerService;
	private IManagerRoleService managerRoleService;
	private IFoodinfoService foodinfoService;
	private IFoodtypeService foodtypeService;

    private ITreeMenuService treemenuService;
	
	
	public void setTreemenuService(ITreeMenuService treemenuService) {
		this.treemenuService = treemenuService;
	}	 
	
	
	public void setFoodtypeService(IFoodtypeService foodtypeService) {
		this.foodtypeService = foodtypeService;
	}
	public void setFoodinfoService(IFoodinfoService foodinfoService) {
		this.foodinfoService = foodinfoService;
	}
	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}
	public void setManagerRoleService(IManagerRoleService managerRoleService) {
		this.managerRoleService = managerRoleService;
	}
	
	/**
	 * 安全退出
	 * @throws Exception
	 */
	public ActionForward exitLogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		session.removeAttribute("manager");
		out.print("<script>location='/FastFood/admin/login.jsp';</script>");
		return null;
		
	}
	
	
	/**
	 * 验证姓名是否存在
	 */
	public ActionForward checkName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
	    PrintWriter out=response.getWriter();
	    try {
			String name=request.getParameter("username");
			if(name!=null){
				Manager manager= managerService.checkName(name);
				if(manager!=null){
					out.print(true);
				}else{
					out.print(false);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         return null;
	}
	
	
	/**
	 * 分页查询所有管理员
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward findAllManager(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
			
		try {
			String currentPage=request.getParameter("page");
			
			PageBean pb = managerService.findAllManager(
					Integer.parseInt(currentPage));
			
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Managerinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据用户Name分页查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
			
		String name = request.getParameter("userName"); //账户名称
		
		try {
			String currentPage=request.getParameter("page");
			
			PageBean pb = managerService.queryByName(
					Integer.parseInt(currentPage),
					name);
			request.setAttribute("name", name);
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Managerinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据mgId查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			String mgId = request.getParameter("mgId"); //账户id
			
			Manager listManager = managerService.findManagerById(Integer.parseInt(mgId));
			//查询出所有的角色信息
			List<Managerrole> roleList=managerRoleService.findAllManagerRole2();
			session.setAttribute("roleList", roleList);
			request.setAttribute("listManager",listManager);
			return new ActionForward("/admin/view/updateManager.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 根据mgId修改管理员信息
	 */
	public ActionForward updateById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		try {
			String mgId = request.getParameter("mgId"); //账户id
			String name = request.getParameter("userName"); //账户名称
			String sex = request.getParameter("sex"); //性别
			String phone = request.getParameter("telephone"); //联系电话
			String email = request.getParameter("email"); //电子邮件
			String address = request.getParameter("address"); //联系地址
			String bz = request.getParameter("u_remarks"); //备注
			String roleId = request.getParameter("role"); // 角色编号
			if(roleId!=null&&!roleId.equals("")){
				managerService.updateManagerById(
						Integer.parseInt(mgId), 
						name, 
						Integer.parseInt(sex), 
						phone, 
						email, 
						address, 
						bz,
						Integer.parseInt(roleId));
				out.print("<script>alert(\"修改成功!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
			}else{
				out.print("<script>alert(\"修改失败!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"修改失败!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
		}
		return null;
	}

	/**
	 * 根据 id删除数据
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try {
			String []mgId = request.getParameterValues("checkBox");
			for (String mgid : mgId) {
				managerService.deleteById(Integer.parseInt(mgid));
			}
			out.print("<script>alert(\"删除成功!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"删除失败!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
		}
		return null;
	}
	
	
	/**
	 * 添加管理员
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward addManager(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		try {
			
			String name = request.getParameter("userName"); //账户名称
			String pwd = request.getParameter("pwd"); //账户密码
			String sex = request.getParameter("sex"); // mg_extendThree 性别
			String phone = request.getParameter("telephone"); //联系电话
			String email = request.getParameter("email"); // mg_extendOne 电子邮件
			String address = request.getParameter("address"); //联系地址
			String bz = request.getParameter("u_remarks"); // mg_extendTwo 备注
			String roleId=request.getParameter("role");  //角色
//		    Managerrole role=null;
//			if(roleId!=null&&!roleId.equals("")){
//				role=managerRoleService.findManagerRoleById(Integer.parseInt(roleId));
//			}
//			System.out.println(role.getManagerrolename());
//			Set managerroles=new HashSet();
//			managerroles.add(role);
			Manager manager = new Manager(
					name,
					pwd,
					phone,
					address,
					1,
					email,
					bz,
					Integer.parseInt(sex));
			managerService.addManager(manager,Integer.parseInt(roleId));
			out.print("<script>alert(\"添加成功!\");location=\"/FastFood/manager.do?p=findAllManager&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"添加失败!\");location=\"/FastFood/admin/view/addManager.jsp\";</script>");
		}
		
		return null;
	}
	

	/*
	 * 添加管理员时查询所有的角色信息
	 */
	public ActionForward queryByAdd(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		PrintWriter out=response.getWriter();
		HttpSession seesion=request.getSession();
		try {
			//查询出所有的角色信息
			List<Managerrole> roleList=managerRoleService.findAllManagerRole2();
			seesion.setAttribute("roleList", roleList);
			out.print("<script>location='/FastFood/admin/view/addManager.jsp';</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/*
	 * 验证登录
	 */
	public ActionForward checkLogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		try {
			String managerName=request.getParameter("userName");
			String pwd=request.getParameter("userPass");
			//根据名称和密码查询
			Manager manager=managerService.checkLogin(managerName, pwd);
			if(manager!=null){
				List<Foodtype> foodtypeList=foodtypeService.findAllFoodType2(); //商品所有类型
				session.setAttribute("foodtypeList", foodtypeList);
				session.setAttribute("manager", manager);
				manager.setMgLastlogin(new Date());
				//得到父级菜单
				List<Treemenu> listTreeMenu1=treemenuService.findTreeMenuBymgId(manager.getMgId());
				//得到父级菜单下的所有子菜单
				List<Treemenu> listTreeMenu2=null;
//				for (Treemenu treemenu : listTreeMenu1) {
//						listTreeMenu2=treemenuService.findBytmId(treemenu.getTreemenuid());
//						
//				}
//				listTreeMenu2=treemenuService.findBytmId(listTreeMenu1.get(0).getTreemenuid());
				listTreeMenu2=treemenuService.findAllTreeMenu();
				session.setAttribute("listTreeMenu1", listTreeMenu1);  //父菜单
				session.setAttribute("listTreeMenu2", listTreeMenu2); //子菜单
				
				out.print(true);
			}else{
				out.print(false);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			out.print(false);
			e.printStackTrace();
		}
		return null;
	}
	
}
