package com.ff.action;

import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IFoodtypeService;
import com.ff.iservices.IManagerService;
import com.ff.iservices.IOrderDetailService;
import com.ff.iservices.IOrderService;
import com.ff.iservices.IUserInfoService;
import com.hsg.pojos.FoodInfoBean;
import com.hsg.pojos.Orders;
import com.hsg.pojos.Ordersdetail;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Userinfo;

/**
 * 订单信息action
 * @author hushiguo
 *
 */
public class OrdersAction extends DispatchAction{
	private IOrderService orderService;
	private IOrderDetailService orderDetailService;
	private IUserInfoService userInfoService;
	private IFoodinfoService foodInfoService;
	private IFoodtypeService foodTypeServive;
	private IManagerService managerService;
	
	public void setOrderService(IOrderService orderService) {
		this.orderService = orderService;
	}
	public void setOrderDetailService(IOrderDetailService orderDetailService) {
		this.orderDetailService = orderDetailService;
	}

	public void setUserInfoService(IUserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}

	public void setFoodInfoService(IFoodinfoService foodInfoService) {
		this.foodInfoService = foodInfoService;
	}

	public void setFoodTypeServive(IFoodtypeService foodTypeServive) {
		this.foodTypeServive = foodTypeServive;
	}

	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}

	/*
	 * 根据订单编号查询订单信息
	 */
	public ActionForward queryByOrderId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session=request.getSession();
	     //获得要删除的订单编号
	    String  orderId=request.getParameter("orderId");  //订单编号
	    String  jieshouRen=request.getParameter("userName");  //接收人
	    String  i=request.getParameter("i");   // i==0  前台查询  ==1 后台查询
	    Userinfo user=(Userinfo) session.getAttribute("user");
	    Integer userId=null;
	    if(user!=null){
	    	userId=user.getUserid();  //当前登录用户编号
	    }
	    
	    try {
			if(orderId!=null){
				Orders order=null;
				List<Ordersdetail>  detailList=null;
				if(Integer.parseInt(i)==0){ 
					order=orderService.findAllOrders(orderId,jieshouRen,userId);
				}else{
					order=orderService.findAllOrders(orderId);
				}
				
				if(order!=null){
					 detailList=orderDetailService.findByOrderId(orderId);
				}
				//订单信息
			    request.setAttribute("Order", order);
			    //详单信息
				request.setAttribute("detail", detailList);
			    if(Integer.parseInt(i)==0){
					//跳转(到前台)订单详细信息显示
				   return new ActionForward("/view/order/orderSubmit.jsp");
			    }else{
				   //跳转(到后台)订单详细信息显示
				   return new ActionForward("/admin/view/DetailOrderInfo.jsp");
			    }
		    }
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/*
	 *要修改的订单信息
	 */
	public ActionForward UpdateOrderInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		    PrintWriter out=response.getWriter();
		    String orderId=request.getParameter("o_Id");  //获得订单编号	 
			String uesrName=request.getParameter("userName");  //客户名称
		    String address=request.getParameter("OSendaddress");  //送货地址
			String uesrphone=request.getParameter("OPhone");  //联系电话
			String uesrPost=request.getParameter("OPost");  //邮编
			String uesrEmail=request.getParameter("OEmail");  //电子邮件
			String Ocheck=request.getParameter("OcheckSel");  //审核状态
			String OJieZhang=request.getParameter("OJieZhangSel");  //发货状态
			String sendTime=request.getParameter("OSendtypeSel");  //送货时间

			try {
				Integer OJieZhang2=1;
				if(OJieZhang!=null){
					OJieZhang2=Integer.parseInt(OJieZhang);
				}
				Integer Ocheck2=1;
				if(OJieZhang!=null){
					Ocheck2=Integer.parseInt(Ocheck);
				}
				Orders order=new Orders(sendTime,
						address,
						uesrName,
						uesrphone,
						uesrPost,
						uesrEmail,
						Ocheck2,
						OJieZhang2);
			 orderService.updateOrderInfo(orderId, order);
			 out.print("<script>alert('修改成功!');location='/FastFood/ordersDetail.do?p=findDetailByPage&i=1&page=1&orderId="+orderId+"';</script>");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				 out.print("<script>alert('修改失败!');location='/FastFood/ordersDetail.do?p=findDetailByPage&i=1&page=1&orderId="+orderId+"';</script>");
				e.printStackTrace();
			}
		    return null;
	}
	
	/*
	 *查询要修改的订单信息
	 */
	public ActionForward queryByUpdate(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	        //获得要删除的订单编号
		    String  orderId=request.getParameter("oId");
		    try {
				if(orderId!=null){
						Orders order=orderService.findAllOrders(orderId);
						request.setAttribute("order", order);
					//跳转到修改页面
					return new ActionForward("/admin/view/UpdateOrder.jsp");
				}
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    return null;
	}
	
	
	/*
	 * 新增订单信息
	 */
	public ActionForward addOrderInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
	    HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		try {
			String address=request.getParameter("address");  //送货地址
			String uesrName=request.getParameter("uesrName");  //客户名称
			String uesrphone=request.getParameter("uesrphone");  //联系电话
			String payMethod=request.getParameter("payMethod");  //送货方式
			String uesrPost=request.getParameter("uesrPost");  //邮编
			String uesrEmail=request.getParameter("uesrEmail");  //电子邮件
			String sendTime=request.getParameter("sendTime");  //送货时间
			String remark=request.getParameter("remark");  //备注
		    String orderId=orderService.getOrderId();  //获得订单编号
			ShoppingCar car=(ShoppingCar)session.getAttribute("car");	//获得购物车
			Userinfo user=(Userinfo)session.getAttribute("user");	//获得当前登录用户
		    //订单实例
			Orders order=new Orders(
					orderId,
					user,
					payMethod,
					sendTime,
					address,
					uesrName,
					uesrphone,
					uesrPost,
					uesrEmail,
					new Date(),1,1,1,
					remark
					);
			System.out.println(orderId);
			//新增订单
			orderService.addOrders(order);
			//新增详单
			orderDetailService.addOrderDetail(car,
					order,
					user);
			//清空购物车
			car.clearShoppingCar();
			out.print("true");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			out.print("false");
			e.printStackTrace();
		}
	    
		return null;
	}
	
}
