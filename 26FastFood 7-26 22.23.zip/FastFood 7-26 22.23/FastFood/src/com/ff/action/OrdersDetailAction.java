package com.ff.action;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.ServletConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IFoodtypeService;
import com.ff.iservices.IManagerRoleService;
import com.ff.iservices.IManagerService;
import com.ff.iservices.IOrderDetailService;
import com.ff.iservices.IOrderService;
import com.ff.iservices.IUserInfoService;
import com.ff.util.Config;
import com.ff.util.ExcelUtil;
import com.hsg.pojos.Orders;
import com.hsg.pojos.Ordersdetail;
import com.hsg.pojos.PageBean;

/**
 * 详细订单信息action
 * @author hushiguo
 *
 */
public class OrdersDetailAction extends DispatchAction{

	private IOrderService orderService;
	private IOrderDetailService orderDetailService;
	private IUserInfoService userInfoService;
	private IFoodinfoService foodInfoService;
	private IFoodtypeService foodTypeService;
	private IManagerService managerService;

	public void setOrderService(IOrderService orderService) {
		this.orderService = orderService;
	}
	public void setOrderDetailService(IOrderDetailService orderDetailService) {
		this.orderDetailService = orderDetailService;
	}
	public void setUserInfoService(IUserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}
	public void setFoodInfoService(IFoodinfoService foodInfoService) {
		this.foodInfoService = foodInfoService;
	}
	public void setFoodTypeService(IFoodtypeService foodTypeService) {
		this.foodTypeService = foodTypeService;
	}
	public void setManagerService(IManagerService managerService) {
		this.managerService = managerService;
	}
	
	
	
	/*
	 * 导出订单信息excel
	 */
	public ActionForward exportExcelByOrder(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		    HttpSession session=request.getSession();
		    String all=request.getParameter("all");   //为ture  导出所有  否则 导出当前也
		    //获得session中的订单信息(pagebean 中)
		    List<Ordersdetail> detailList= (List<Ordersdetail>)session.getAttribute("orderList");
		    String out="false";
		    SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd  hh.mm.ss");
		    String ExcelName="Order"+sdf.format(new Date());   //excel 名称
		    StringBuffer sb=new StringBuffer();
		    //过滤		
//			String color = Config.getConfig().getProperty("selectColor"); 
//		    Pattern p1=Pattern.compile("<strong><font style='color:'"+color+">");
//		    Pattern p2=Pattern.compile("</font></strong>");
		    try {
				//写表头 
				String [] title=new String[13];
				title[0]="订单编号";
				title[1]="商品名称";
				title[2]="购买数量";
				title[3]="支付金额";
				title[4]="接收人姓名";
				title[5]="送货地址";
				title[6]="联系电话";
				title[7]="电子邮件";
				title[8]="送餐时间";
				title[9]="订单日期";
				title[10]="审核状态";
				title[11]="送货状态";
				title[12]="支付方式";
				
				//13列
				String [] types={"String","String","String","String","String","String","String","String","String","String","String","String","String"};
				
				//写内容
				Object[][] obj=new Object[detailList.size()][13];
				//循环list中的内容
				for (int i = 0; i <detailList.size(); i++) {
					obj[i][0]=""+(i+1);
					obj[i][1]=detailList.get(i).getOrders().getOId();  //订单编号
					obj[i][2]=detailList.get(i).getFoodinfo().getFoodname();  //商品名称
					obj[i][1]=detailList.get(i).getOdBuynum().toString();  //购买数量
					obj[i][1]=detailList.get(i).getOdTotalmoney().toString();  //支付金额
					obj[i][1]=detailList.get(i).getOrders().getOName();  //接收人姓名
					obj[i][1]=detailList.get(i).getOrders().getOSendaddress();  //送货地址
					obj[i][1]=detailList.get(i).getOrders().getOPhone();  //联系电话
					obj[i][1]=detailList.get(i).getOrders().getOEmail();  //电子邮件
					obj[i][1]=detailList.get(i).getOrders().getOSendtype();  //送餐时间
					obj[i][1]=detailList.get(i).getOrders().getOOrderdate().toString();  //订单日期
					obj[i][1]=detailList.get(i).getOrders().getOCheck()==1?"未审核":"已审核";  //审核状态
					String songhuo="";
					if(detailList.get(i).getOrders().getOJiezhang()==1){
						songhuo="未发货";
					}else if(detailList.get(i).getOrders().getOJiezhang()==2){
						songhuo="已发货";
					}else{
						songhuo="已签收";
					}
					obj[i][1]=songhuo;  //送货状态
					obj[i][1]=detailList.get(i).getOrders().getOPaymethod();  //支付方式
			    }
				//导出
//				ServletConfig servletConfig =  getServletvletConfig();
//				String serverPath = servletConfig.getServletContext().getRealPath("/");
//				String filePath = serverPath + "upload";  

				ExcelUtil.exportExcel(ExcelName+".xls", ExcelName+".xls", title, types, obj, sb);
                out=ExcelName+".xls";				
			} catch (Exception e) {
				out="false";
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.getWriter().print(out);
		    return null;
	}
	
	
	
	
	/*
	 *删除订单信息  (即将订单状态和详细订单状态修改为2)
	 */
	public ActionForward deleteOrderInfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		    PrintWriter out=response.getWriter();
	        //获得要删除的订单编号数组
		    String []orderId=request.getParameterValues("checkBox");
		    try {
				if(orderId!=null){
					for (String oId : orderId) {
						//循环删除
						orderDetailService.deleteOrderInfo(oId);
						out.print("<script>alert('删除成功!');location='/FastFood/ordersDetail.do?p=findDetailByPage&page=1&i=0';</script>");
					}
				}
			} catch (Exception e) {
				out.print("<script>alert('删除失败!');location='/FastFood/ordersDetail.do?p=findDetailByPage&page=1&i=0';</script>");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    return null;
	}
	
	
	/*
	 *根据条件分页查询订单信息
	 */
	public ActionForward findDetailByPage(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
	
	    try {
	    	String currentPage=request.getParameter("page");  //当前页
			String i=request.getParameter("i");  //i=0 查询所有  否则根据条件查询
			String orderId=request.getParameter("orderId");  //订单编号
			String startDate=request.getParameter("startDate");  //开始日期
			String stopDate=request.getParameter("stopDate");  //结束日期
			String OCheck=request.getParameter("OCheck");  //是否审核  1 未审核  2  已审核
			String OJiezhang=request.getParameter("OJiezhang");  //是否审核  1  未发货   2  已发货  3 已签收
			Integer OCheck2=null;
			Integer OJiezhang2=null;
			if(OCheck!=null){
				 OCheck2=Integer.parseInt(OCheck);  //是否审核  1  已审核  2  未审核
			}
			if(OJiezhang!=null){
				 OJiezhang2=Integer.parseInt(OJiezhang);  //是否审核  1  已审核  2  未审核
			}
			System.out.println(startDate);
			System.out.println(stopDate);
			Date date1=null;
			Date date2=null;
			
			//装换成date，类型
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			if(!(startDate==null||startDate.equals(""))&&!(stopDate==null||stopDate.equals(""))){
				date1=sf.parse(startDate);
				date2=sf.parse(stopDate);
			}
			//分页查询，返回一个pagebean
			PageBean pagebean=orderDetailService.findDetailByPage(
					Integer.parseInt(currentPage),
					Integer.parseInt(i),
					orderId,
					date1,
					date2,
					OCheck2,
					OJiezhang2);
			request.setAttribute("pagebean", pagebean);
			//用于导出excel
			request.getSession().setAttribute("orderList", pagebean.getPageData());
			request.setAttribute("orderId", orderId);
			request.setAttribute("startDate", startDate);
			request.setAttribute("stopDate", stopDate);
			return new ActionForward("/admin/view/Ordersinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	} 
	
	/*
	 * 根据编号查询最新添加的详细订单信息
	 */
	public ActionForward findNewDeatil(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		try {
			List<Ordersdetail> detailList=orderDetailService.findBigOrderInfo();
			if(detailList!=null){
				//获得订单编号
				String oId=detailList.get(0).getOrders().getOId();
				//查询订单信息
			    Orders Order=orderService.findAllOrders(oId);
			    //订单信息
			    request.setAttribute("Order", Order);
			    //详单信息
				request.setAttribute("detail", detailList);
				return new ActionForward("/view/order/orderSubmit.jsp");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
