package com.ff.action;


import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IAdviceService;
import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IUserInfoService;
import com.hsg.pojos.Advice;
import com.hsg.pojos.Foodinfo;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.Userinfo;

public class AdviceAction extends DispatchAction{

	private IAdviceService adviceService;
	private IUserInfoService userInfoService;
	private IFoodinfoService foodInfoService;
	
	public void setAdviceService(IAdviceService adviceService) {
		this.adviceService = adviceService;
	}
	public void setUserInfoService(IUserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}
	public void setFoodInfoService(IFoodinfoService foodInfoService) {
		this.foodInfoService = foodInfoService;
	}
	
	/**
	 * 查询某商品的所有评论信息
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward findAdviceByFoodId(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
        //获得当前页
		try {
			String currentPage=request.getParameter("page");
			String foodid=request.getParameter("foodid");
			
			//获得商品信息
			Foodinfo foodinfo= foodInfoService.findFoodInfoById(Integer.parseInt(foodid));
			//根据商品编号查询并返回一个pagebean
			PageBean pb=adviceService.findAdviceByfoodId(
					Integer.parseInt(currentPage), 
					Integer.parseInt(foodid));
			
			//保存商品信息
			request.setAttribute("foodinfo", foodinfo);
			request.setAttribute("pb", pb);
			return new ActionForward("/view/clientReview.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 分页查询所有评论信息
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward findAllAdvice(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String currentPage=request.getParameter("page");
			
			PageBean pb=adviceService.findAllAdvice(
					Integer.parseInt(currentPage));
					
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Advicesinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 根据商品名称分页查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String foodName = request.getParameter("foodName"); //商品名称 
			String currentPage=request.getParameter("page");
			
			PageBean pb = adviceService.queryByName(
					Integer.parseInt(currentPage),
					foodName);
			request.setAttribute("foodName", foodName);
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Advicesinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 按时间查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByDate(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		try {
			String startDate=request.getParameter("startDate");  //开始日期
			String stopDate=request.getParameter("stopDate");  //结束日期
			String currentPage=request.getParameter("page");
			
			Date date1=null;
			Date date2=null;
			
			//装换成date，类型
			SimpleDateFormat sf=new SimpleDateFormat("yyyy-MM-dd");
			if(!(startDate==null||startDate.equals(""))&&!(stopDate==null||stopDate.equals(""))){
				date1=sf.parse(startDate);
				date2=sf.parse(stopDate);
			}
				
				PageBean pb = adviceService.queryByDate(
						Integer.parseInt(currentPage),
						date1,
						date2);
				
				request.setAttribute("date1", date1);
				request.setAttribute("date2", date2);
				request.setAttribute("pb", pb);
				return new ActionForward("/admin/view/Advicesinfo.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	}
	
	/**
	 * 根据 id删除数据
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		try {
			String []adviceid = request.getParameterValues("checkBox");
			for (String adId : adviceid) {
				adviceService.deleteById(Integer.parseInt(adId));
			}
			out.print("<script>alert(\"删除成功!\");location=\"/FastFood/advice.do?p=findAllAdvice&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"删除失败!\");location=\"/FastFood/advice.do?p=findAllAdvice&page=1\"</script>");
		}
		return null;
	}
	
	/**
	 * 添加评论
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward addAdvice(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		try {
			Userinfo user= (Userinfo) session.getAttribute("user");
			String foodid = request.getParameter("foodid"); //评论商品的编号
			String memo = request.getParameter("memo"); //评论内容
			
			//根据编号查询当前评论的商品信息
		Foodinfo f=	foodInfoService.findFoodInfoById(Integer.parseInt(foodid));
		Advice advice=new Advice(
				f,
				user,
				memo,
				new Date(),1);
		
		adviceService.addAdvice(advice);
		return new ActionForward("/advice.do?p=findAdviceByFoodId&foodid="+foodid+"&page=1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return null;
	}
	
}
