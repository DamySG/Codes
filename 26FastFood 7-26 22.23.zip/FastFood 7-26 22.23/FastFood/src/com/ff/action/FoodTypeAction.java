package com.ff.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ff.iservices.IFoodinfoService;
import com.ff.iservices.IFoodtypeService;

/**
 * 商品信息action
 * @author hushiguo
 *
 */
public class FoodTypeAction extends DispatchAction{
 
	private IFoodinfoService foodInfoService;
	private IFoodtypeService foodTypeServive;
	
	public void setFoodInfoService(IFoodinfoService foodInfoService) {
		this.foodInfoService = foodInfoService;
	}
	public void setFoodTypeServive(IFoodtypeService foodTypeServive) {
		this.foodTypeServive = foodTypeServive;
	}
	
	
	/**
	 * 根据编号查询商品类别信息
	 * @return
	 * @throws Exception
	 */
	public ActionForward finFoodTypeById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		out.print("根据编号查询商品信息");
		return null;
	}
	
	
	
	
	
	
}
