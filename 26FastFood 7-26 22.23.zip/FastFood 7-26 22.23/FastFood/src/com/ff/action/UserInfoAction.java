package com.ff.action;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;
import org.apache.struts.upload.FormFile;

import com.ff.form.UserinfoForm;
import com.ff.iservices.IUserInfoService;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Userinfo;

public class UserInfoAction extends DispatchAction {
   private IUserInfoService userInfoService;

	public void setUserInfoService(IUserInfoService userInfoService) {
		this.userInfoService = userInfoService;
	}
	
	/**
	 * 安全退出
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward exitLogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		session.removeAttribute("user");
		session.removeAttribute("car");
		out.print("<script>location='/FastFood/foodInfo.do?p=findFoodInfoById&bigTypeId=1';</script>");
		return null;
		
	}
	
	
	/**
	 * 验证姓名是否存在
	 */
	public ActionForward checkName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
	    PrintWriter out=response.getWriter();
	    try {
			String name=request.getParameter("username");
			if(name!=null){
				Userinfo user= userInfoService.checkName(name);
				if(user!=null){
					out.print(true);
				}else{
					out.print(false);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         return null;
	}
	
	/**
	 * 验证用户密码是否匹配
	 */
	public ActionForward checkPass(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
	    PrintWriter out=response.getWriter();
	    try {
			String userName=request.getParameter("username");
			String pwd=request.getParameter("userpass");
			if(pwd!=null){
				Userinfo user= userInfoService.FindByLogin(userName,pwd);
				if(user!=null){
					out.print(true);
				}else{
					out.print(false);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         return null;
	}
	
	/**
	 * 分页查询所有会员
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward findAllUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String currentPage=request.getParameter("page");
			
			PageBean pb = userInfoService.findAllUser(
					Integer.parseInt(currentPage));
			
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Userinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 根据用户Name分页查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryByName(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
			
		String name = request.getParameter("userName"); //账户名称
		
		try {
			String currentPage=request.getParameter("page");
			
			PageBean pb = userInfoService.queryByName(
					Integer.parseInt(currentPage),
					name);
			request.setAttribute("name", name);
			request.setAttribute("pb", pb);
			return new ActionForward("/admin/view/Userinfo.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 根据userid查询
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward queryById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		
		try {
			String userid = request.getParameter("userid"); //账户id
			
			Userinfo listUser = userInfoService.finUserInfoById(Integer.parseInt(userid));
			
			request.setAttribute("listUser",listUser);
			
			return new ActionForward("/admin/view/updateUser.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
	/**
	 * 根据userid修改会员信息
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward updateById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		try {
			String userid = request.getParameter("userid"); //账户id
			String name = request.getParameter("userName"); //账户名称
			String sex = request.getParameter("sex"); //性别
			String phone = request.getParameter("telephone"); //联系电话
			String email = request.getParameter("email"); //电子邮件
			String address = request.getParameter("address"); //联系地址
			String bz = request.getParameter("u_remarks"); //备注

			userInfoService.updateById(
					Integer.parseInt(userid), 
					name, 
					Integer.parseInt(sex), 
					phone, 
					email, 
					address, 
					bz);
			out.print("<script>alert(\"修改成功!\");location=\"/FastFood/userInfo.do?p=findAllUser&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"修改失败!\");location=\"/FastFood/userInfo.do?p=findAllUser&page=1\"</script>");
		}
		return null;
	}
	
	/**
	 * 根据 id删除数据
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteById(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try {
			String []userid = request.getParameterValues("checkBox");
			for (String uId : userid) {
				userInfoService.deleteById(Integer.parseInt(uId));
			}
			out.print("<script>alert(\"删除成功!\");location=\"/FastFood/userInfo.do?p=findAllUser&page=1\"</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"删除失败!\");location=\"/FastFood/userInfo.do?p=findAllUser&page=1\"</script>");
		}
		return null;
	}
	
	/**
	 * 前台添加会员
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @param pageContext
	 * @return
	 * @throws Exception
	 */
	public ActionForward addUserinfo(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		
		try {
			String name = request.getParameter("userName"); //账户名称
			String pwd = request.getParameter("userPass"); //账户密码
			String sex = request.getParameter("sexVal"); //性别
			String phone = request.getParameter("phone"); //联系电话
			String email = request.getParameter("myEail"); //电子邮件
			String address = request.getParameter("address"); //联系地址
			String photos = request.getParameter("photos"); //用户默认头像
			//获得输入的验证码
			String yzm=request.getParameter("yzm");
			//获得自动产生的验证码
			String sessionYZM=(String)session.getAttribute("yzm");
			
			Userinfo userinfo = new Userinfo(
					name,
					pwd,
					Integer.parseInt(sex),
					new Date(),
					photos,
					address,
					email,
					phone,1);
			
			if(sessionYZM.equalsIgnoreCase(yzm)){
				userInfoService.addUserinfo(userinfo);
				out.print("{bol:true,addUser:'注册成功!'}");
			}else{
				out.print("{bol:false,addUser:'验证码不正确!'}");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 后台添加会员
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @param pageContext
	 * @return
	 * @throws Exception
	 */
	public ActionForward addUser(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		//获得form
		UserinfoForm myForm = (UserinfoForm) form;
		//获得提交的文件对象
		FormFile ff = myForm.getPhotos();
		//获得文件字节流
		byte[] b=ff.getFileData();
		//获得上传的文件名
		String fileName=ff.getFileName();
		//获得upload文件夹的真实路径
		String filePath=request.getSession().getServletContext().getRealPath("/images/photos");
		//获得随机的文件名
		String randomName=UUID.randomUUID().toString();
		//获得上传文件的后缀名
		String fix=fileName.substring(fileName.lastIndexOf("."));
		//创建输出文件的输出流
		FileOutputStream fos=new FileOutputStream(filePath + "/" + randomName + fix);
		//获得真实的文件名
		String photos = randomName + fix;
		//写入输出流
		fos.write(b);
		//关闭
		fos.close();
		
		try {
			String name = request.getParameter("userName"); //账户名称
			String pwd = request.getParameter("pwd"); //账户密码
			String sex = request.getParameter("sex"); //性别
			String phone = request.getParameter("telephone"); //联系电话
			String email = request.getParameter("email"); //电子邮件
			String address = request.getParameter("address"); //联系地址
			String bz = request.getParameter("u_remarks"); //备注
			
			Userinfo userinfo = new Userinfo(
					name,
					pwd,
					Integer.parseInt(sex),
					new Date(),
					photos,
					address,
					email,
					phone,
					1,
					bz);
			
			userInfoService.addUser(userinfo);
			out.print("<script>alert(\"注册成功!\");location=\"/FastFood/admin/view/addUser.jsp\";</script>");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print("<script>alert(\"注册失败!\");location=\"/FastFood/admin/view/addUser.jsp\";</script>");
		}
		return null;
	}
	
	/**
	 * 修改密码
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward updatePass(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try {
			HttpSession session=request.getSession();
			Userinfo userinfo=(Userinfo) session.getAttribute("user");
			String pass = request.getParameter("userpass");//新密码
			
			userInfoService.updatePass(userinfo.getUserid(),pass);
			out.print(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print(false);
		}
		return null;
	}
	
	/**
	 * 修改个人资料
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward updateData(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try {
			HttpSession session=request.getSession();
			Userinfo userinfo=(Userinfo) session.getAttribute("user");
			String name = request.getParameter("username");//姓名
			String sex = request.getParameter("usersex");//性别
			String phone = request.getParameter("userphone");//联系电话
			String address = request.getParameter("useraddress");//联系地址
			String email = request.getParameter("useremail");//电子邮件
			String remarks = request.getParameter("userremarks");//备注
			
			userInfoService.updateById(
					userinfo.getUserid(), 
					name, 
					Integer.parseInt(sex), 
					phone, 
					email, 
					address, 
					remarks);
			Userinfo u=userInfoService.finUserInfoById(userinfo.getUserid());
			session.setAttribute("user", u);
			out.print(true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.print(false);
		}
	
		return null;
	}
	
	
	/**
	 * 修改头像
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward updatePhotos(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String can = request.getParameter("can"); //方式参数
		HttpSession session=request.getSession();
		Userinfo userinfo=(Userinfo) session.getAttribute("user");
		String photos ="";
		
		try {
			if(can!=null&&!can.equals("")){
				if(Integer.parseInt(can)==2){
					//获得form
					UserinfoForm myForm = (UserinfoForm) form;
					//获得提交的文件对象
				    FormFile ff = myForm.getPhotos();
					//获得文件字节流
					byte[] b=ff.getFileData();
					//获得上传的文件名
					String fileName=ff.getFileName();
					//获得upload文件夹的真实路径
					String filePath=request.getSession().getServletContext().getRealPath("/images/photos");
					//获得随机的文件名
					String randomName=UUID.randomUUID().toString();
					//获得上传文件的后缀名
					String fix=fileName.substring(fileName.lastIndexOf("."));
					//创建输出文件的输出流
					FileOutputStream fos=new FileOutputStream(filePath + "/" + randomName + fix);
					//获得真实的文件名
				    photos = randomName + fix;
					//写入输出流
					fos.write(b);
					//关闭
					fos.close();
				}else{
					photos = request.getParameter("userphotos"); //系统头像
				}
			
				if(can!=null&&!can.equals("")){
					userInfoService.updatePhotos(userinfo,photos);
					Userinfo u=userInfoService.finUserInfoById(userinfo.getUserid());
					session.setAttribute("user", u);
					if(Integer.parseInt(can)==2){
						out.print("<script>location='/FastFood/view/vipHub.jsp';</script>");
					 }else{
						 StringBuffer sb=new StringBuffer();
						 sb.append("{");
						 sb.append("msg:"+true);
						 sb.append(",");
						 sb.append("photos:'"+photos+"'");
						 sb.append("}");
						 out.print(""+sb+"");
					 }
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			if(can!=null&&!can.equals("")){
				if(Integer.parseInt(can)==2){
					 out.print("<script>location='/FastFood/view/vipHub.jsp';</script>");
				 }else{
					 out.print(false);
				 }
			}
		}
		return null;
	}
	
	
	/**
	 * 登录验证
	 * @return
	 * @throws Exception
	 */
	public ActionForward checkLogin(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		try {
			String userName=request.getParameter("userName");
			String userPass=request.getParameter("userPass");
			//获得输入的验证码
			String yzm=request.getParameter("yzm");
			//获得自动产生的验证码
			String sessionYZM=(String)session.getAttribute("yzm");
			//获得购物车
			ShoppingCar car=(ShoppingCar)session.getAttribute("car");
			Userinfo userInfo=userInfoService.FindByLogin(userName, userPass);
			if(sessionYZM.equalsIgnoreCase(yzm)){
				if(userInfo==null){
					 //返回json对象  {属性：属性值，属性：属性值}  {}--表示一个对象
					out.print("{bol:false,message:'用户名或密码错误!'}");
				}else {
					//修改登录次数
					userInfoService.updateLoginTime(userInfo);
					session.setAttribute("user", userInfo);
					
					if(car!=null){
						if(car.getCarCount()==null||car.getCarCount()==0){
							out.print("{bol:true,message:'跳转到首页'}");
						}else{
							out.print("{bol:true,message:'跳转到填写订单'}");
						}
					}else{
						out.print("{bol:true,message:'跳转到首页'}");
					}
				}
			}else{
				out.print("{bol:false,message:'验证码不正确!'}");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
   
}
