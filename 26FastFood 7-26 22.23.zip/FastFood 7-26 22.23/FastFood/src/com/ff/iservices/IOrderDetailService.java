package com.ff.iservices;

import java.util.Date;
import java.util.List;

import com.hsg.pojos.Orders;
import com.hsg.pojos.Ordersdetail;
import com.hsg.pojos.PageBean;
import com.hsg.pojos.ShoppingCar;
import com.hsg.pojos.Userinfo;

public interface IOrderDetailService {

	/**
	 *查询所有的详细订单信息
	 * @return
	 */
	public abstract List<Ordersdetail> findAllOrderDetail();

	/**
	 *根据编号查询所有的详细订单信息
	 * @return
	 */
	public abstract Ordersdetail findAllOrderDetail(Integer orderDetailId);

	
	/**
	 * 添加详单
	 * @param oDetail
	 * @param car
	 * @param orders
	 */
	public abstract void addOrderDetail(ShoppingCar car,Orders orders,Userinfo user);
	
	/**
	 * 查询最新增加的订单详细信息
	 * @return
	 */
	public abstract List<Ordersdetail> findBigOrderInfo();
	
	/**
	 * 根据条件分页查询订单信息
	 * @return
	 */
	public abstract PageBean findDetailByPage(Integer currentPage,Integer i,
			String orderId, 
			Date startDate, 
			Date stopDate,
			Integer OCheck,
			Integer OJiezhang);
	
	
	/**
	 * 删除订单信息  (即将状态修改为2)
	 * @param orderId
	 */
	public abstract void deleteOrderInfo(String orderId);
	
	

	/**
	 * 根据订单编号查询订单详细信息
	 * @return
	 */
	public abstract List<Ordersdetail> findByOrderId(String orderId);
}


