package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Orders;

public interface IOrderService {

	/**
	 *查询所有的订单信息
	 * @return
	 */
	public abstract List<Orders> findAllOrders();

	/**
	 *查询所有的订单信息
	 * @return
	 */
	public abstract Orders findAllOrders(String ordersId);

	/**
	 * 获得一个订单号
	 * @return
	 */
	public abstract String  getOrderId();
	
	/**
	 * 增加订单信息
	 * @param order
	 */
    public abstract void addOrders(Orders order);
    
	/**
	 * 修改订单信息
	 * @param orderId
	 * @param order
	 */
	public abstract void updateOrderInfo(String orderId,Orders order);
	
	/**
	 *根据订单编号和接收人查询订单信息
	 * @return
	 */
	public abstract Orders findAllOrders(String ordersId,String name,Integer userId);
}