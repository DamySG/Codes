package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Banktype;

public interface IBankTypeService {

	/**
	 * 查询所有银行类型信息
	 * @return
	 */
	public abstract List<Banktype> findAllBankType();

	/**
	 * 根据编号查询所有银行类型信息
	 * @return
	 */
	public abstract Banktype findBankTypeById(Integer bankTypeId);

}