package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.PageBean;
import com.hsg.pojos.Userinfo;

public interface IUserInfoService {

	/**
	 * 查询所有会员信息
	 * @return
	 */
	public abstract List<Userinfo> findAllUserInfo();

	/**
	 * 根据编号查询会员信息
	 * @return
	 */
	public abstract Userinfo finUserInfoById(Integer userId);

	/**
	 * 根据用户名和密码查询会员信息
	 * @return
	 */
	public abstract Userinfo FindByLogin(String userName, String pwd);

	/**
	 * 分页查询所有用户
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean findAllUser(Integer currentPage);
	
	/**
	 * 根据用户Name分页查询
	 * @param currentPage
	 * @param username
	 * @return
	 */
	public abstract PageBean queryByName(Integer currentPage,String username);
	
	/**
	 * 根据userId删除用户
	 * @param userId
	 */
	public abstract void deleteById(Integer userId);
	
	
	/**
	 * 根据userId修改用户
	 * @param userId
	 */
	public abstract void updateById(Integer userId,String username,Integer sex,
			String telephone,String email,String address,String URemarks);
	
	/**
	 * 前台添加会员
	 * @param Userinfo
	 */
	public abstract void addUserinfo(Userinfo Userinfo);
	
	/**
	 * 后台添加会员
	 * @param Userinfo
	 */
	public abstract void addUser(Userinfo Userinfo);
	
	
	/**
	 * 根据会员编号修改会员积分，余额
	 * @param userId
	 */
	public abstract void updateUserCoin(Integer userId,Double totalMoney,Integer totalCoin);
	
	/**
	 * 修改登录的时间和登录次数
	 * @param user
	 */
	public abstract void updateLoginTime(Userinfo user);
	
	/**
	 * 修改密码
	 * @param userId
	 * @param pass
	 */
	public abstract void updatePass(Integer userId,String pass);
	
	
	/**
	 * 修改头像
	 * @param userId
	 * @param photos
	 */
	public abstract void updatePhotos(Userinfo user,String photos);
	
	/** 
	 * 验证name是否已存在
	 */
	public abstract Userinfo checkName(String name);

}