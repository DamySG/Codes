package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Managerrole;

public interface IManagerRoleService {

	/**
	 * 查询所有管理员角色
	 * @return
	 */
	public abstract List<Managerrole> findAllManagerRole();

	/**
	 * 根据编号查询所有管理员角色
	 * @return
	 */
	public abstract Managerrole findManagerRoleById(Integer managerRoleId);
	
	/**
	 * 根据姓名查询所有管理员角色
	 * @return
	 */
	public abstract Managerrole findRoleByName(String roleName);
	
	/**
	 * 增加角色
	 * @return
	 */
	public abstract void addRole(Managerrole role);
	

	/**
	 * 修改角色
	 * @return
	 */
	public abstract void updateRole(Integer roleId,Managerrole role);
	
	/**
	 * 查询所有管理员角色
	 * @return
	 */
	public abstract List<Managerrole> findAllManagerRole2();
	

	/**
	 * 删除角色  把状态修改为2
	 * @return
	 */
	public abstract void deleteRole(Integer roleId);
	
	/**
	 * 根据姓名模糊查询角色
	 * @return
	 */
	public abstract List<Managerrole> findRoleByName2(String roleName);
	
	/**
	 * 给角色添加权限菜单
	 * roleId  角色编号
	 * menuId 树形菜单编号数组
	 * @return
	 */
	public abstract void addTreeMenuByRoleId(Integer roleId,String[]menuId);

}