package com.ff.iservices;

import java.util.List;
import java.util.Set;

import com.hsg.pojos.Treemenu;

public interface ITreeMenuService {

	/**
	 * 查询所有树形菜单
	 * @return
	 */
	public abstract List<Treemenu> findAllTreeMenu();

	/**
	 * 根据编号查询所有树形菜单
	 * @return
	 */
	public abstract Treemenu findTreeMenuById(Integer treeMenuId);
	   
	/**
	 * 根据管理员编号查询所有树形菜单
	 * @return
	 */
	public abstract List<Treemenu> findTreeMenuBymgId(Integer managerId);
	

	/**
	 * 查询父级菜单
	 * @return
	 */
	public abstract List<Treemenu> findParentMenu();
	
	/**
	 * 根据角色编号查询父级菜单
	 * @return
	 */
	public abstract Set<Treemenu> findMenuByRoleId(Integer roleId);

}