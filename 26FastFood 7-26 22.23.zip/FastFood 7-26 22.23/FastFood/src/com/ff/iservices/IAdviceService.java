package com.ff.iservices;

import java.util.Date;
import java.util.List;

import com.hsg.pojos.Advice;
import com.hsg.pojos.PageBean;

public interface IAdviceService {

	/**
	 * 查询所有评论
	 * @return
	 */
	public abstract List<Advice> findAllAdvice();

	/**
	 * 根据评论编号查询所有评论
	 * @return
	 */
	public abstract Advice findAdviceById(Integer adviceId);
	
    /**
	 * 分页查询所有评论信息
	 * @return
	 */
    public abstract PageBean findAllAdvice(Integer currentPage);

	 /**
	 * 根据商品编号分页查询所有评论
	 * @return
	 */
    public abstract PageBean findAdviceByfoodId(Integer currentPage,Integer foodId);

	/**
	 * 根据标题分页查询
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean queryByName(Integer currentPage,String foodName);
    
	/**
	 * 根据时间分页查询
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean queryByDate(Integer currentPage,Date startDate, Date stopDate);
	
	/**
	 * 根据msId删除用户
	 * @param msId
	 */
	public abstract void deleteById(Integer adId);
    
    /**
     * 根据商品添加评论信息
     * @param Advice
     */
    public abstract void addAdvice(Advice Advice);
    
}