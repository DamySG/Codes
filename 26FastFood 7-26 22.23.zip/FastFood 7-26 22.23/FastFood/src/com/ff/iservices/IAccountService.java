package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Accounts;

public interface IAccountService {

	/**
	 * 查询所有账户信息
	 * @return
	 */
	public abstract List<Accounts> findAllAccounts();

	/**
	 * 根据编号查询所有账户信息
	 * @return
	 */
	public abstract Accounts findAccountById(String accountId);

	/**
	 * 根据银行类型，账户号，密码  查询账户信息
	 * @return
	 */
	public abstract Accounts findAccountById(Integer bankTypeId,
			String accountId, Integer acPwd);

}