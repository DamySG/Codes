package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Manager;
import com.hsg.pojos.PageBean;

public interface IManagerService {

	/**
	 * 查询所有管理员
	 * @return
	 */
	public abstract List<Manager> findAllManager();

	/**
	 * 根据编号查询所有管理员
	 * @return
	 */
	public abstract Manager findManagerById(Integer managerId);

	/**
	 * 分页查询所有管理员
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean findAllManager(Integer currentPage);
	
	/**
	 * 根据用户Name分页查询
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean queryByName(Integer currentPage,String mgName);

	/** 
	 * 验证name是否已存在
	 * @return
	 */
	public abstract Manager checkName(String name);
	
	/**
	 * 根据mgId删除用户
	 * @param mgId
	 */
	public abstract void deleteById(Integer mgId);
	
	/**
	 * 根据mgId修改管理员信息
	 * @param mgId
	 */
	public void updateManagerById(Integer mgId,String mgName,Integer mgExtendthree,
			String mgPhone,String mgExtendone,String mgAddress,String mgExtendtwo,Integer roleId);

	
	/**
	 * 登录验证
	 * @return
	 */
	public abstract Manager checkLogin(String managerName, String pwd);
	


	/**
	 * 后台添加管理员
	 * @param Manager
	 */
	public abstract void addManager(Manager manager,Integer roleId);

}