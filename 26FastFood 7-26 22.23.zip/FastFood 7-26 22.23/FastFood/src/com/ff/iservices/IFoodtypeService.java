package com.ff.iservices;

import java.util.List;

import com.hsg.pojos.Foodtype;

public interface IFoodtypeService {

	/**
	 * 查询所有商品类别信息
	 * @return
	 */
	public abstract List<Foodtype> findAllFoodType();

	/**
	 * 根据编号查询
	 * @param typeId
	 * @return
	 */
	public abstract Foodtype findFoodTypeById(Integer typeId);

	/**
	 * 根据大类型编号查询
	 * 1  自选订餐
	 * 2  固定套餐
	 * 3  组合套餐
	 * @param typeId
	 * @return
	 */
	public abstract List<Foodtype> findFoodTypeByBigId(Integer bigTypeId);
	
	/**
	 * 根据名称查询
	 * @param typeId
	 * @return
	 */
	public abstract Foodtype findFoodTypeByName(String typeName);
	
	/**
	 * 查询所有商品类别信息
	 * @return
	 */
	public abstract List<Foodtype> findAllFoodType2();
	
}