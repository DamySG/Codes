package com.ff.iservices;

import java.util.Date;
import java.util.List;

import com.hsg.pojos.Message;
import com.hsg.pojos.PageBean;

public interface IMessageService {

	/**
	 * 查询所有的留言
	 * @return
	 */
	public abstract List<Message> findAllMessage();
	
	   /**
	 * 分页查询所有留言
	 * @return
	 */
    public abstract PageBean findAllMessage(Integer currentPage, Integer msid);
    
	/**
	 * 根据标题分页查询
	 * @param currentPage
	 * @param username
	 * @return
	 */
	public abstract PageBean queryByTitle(Integer currentPage,String msTitle);
	
	/**
	 * 根据时间分页查询
	 * @param currentPage
	 * @return
	 */
	public abstract PageBean queryByDate(Integer currentPage,Date startDate, Date stopDate);
	
	/**
	 * 根据msId删除用户
	 * @param msId
	 */
	public abstract void deleteById(Integer msId);
	
	/**
	 * 添加留言
	 * @param Message
	 */
	public abstract void addMessage(Message Message);

}