package com.ff.iservices;

import java.util.List;
import java.util.Map;

import com.hsg.pojos.Foodinfo;

public interface IFoodinfoService {

	/* 
	 * 查询所有商品信息
	 */
	public abstract List<Foodinfo> findAllFoodInfo();

	/*
	 *  根据编号查询商品信息
	 */
	public abstract Foodinfo findFoodInfoById(Integer foodId);

	/* 
	 * 根据商品类型查询所有商品信息
	 */
	public abstract List<Foodinfo> findFoodInfoByTypeId(Integer foodTypeId);

	
	   
	/* 
	 * 根据商品类型名称查询所有商品信息
	 */
	public abstract List<Foodinfo> findFoodInfoByTypeName(String foodTypeName);
	
	
	/* 
	 * 根据商品大类型名称查询所有商品信息
	 */
	public abstract List<Foodinfo> findFoodInfoByBigTypeId(Integer bigTypeId);
	
	/**
	 * 修改商品数量
	 * @param foodid
	 * @param foodNum
	 */
	public abstract void updateFoodNum(Integer foodid,Integer foodNum);
	
	/**
	 * 分页查询商品信息
	 * @param foodTypeId
	 * @param currentPage
	 * @param i
	 * @return
	 */
	public abstract Map<String,Object> findFoodInfoByPage(Integer foodTypeId,Integer currentPage,
			Integer i,String foodName);
	
	/**
	 * 删除商品信息  (即将状态修改为2)
	 * @param orderId
	 */
	public abstract void deleteFoodInfo(Integer foodId);
	
	/**
	 * 增加商品信息
	 * @param food
	 */
	public abstract void addFoodInfo(Foodinfo food);
	
	/**
	 * 修改商品信息
	 * @param foodId
	 * @param food
	 */
	public abstract void updateFoodInfo(Integer foodId,Foodinfo food);
}