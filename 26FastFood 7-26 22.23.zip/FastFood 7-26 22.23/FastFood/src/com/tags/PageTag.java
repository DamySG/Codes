package com.tags;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.hsg.pojos.PageBean;

/**
 * 自定义标签分页
 * 
 * @author Administrator
 * 
 */
public class PageTag extends SimpleTagSupport {

	private PageBean page; // 分页对象

	private String content; // 分页路径

	public PageBean getPage() {
		return page;
	}

	public void setPage(PageBean page) {
		this.page = page;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public void doTag() throws JspException, IOException {
		PageContext pageContext = (PageContext) this.getJspContext();
		JspWriter out = pageContext.getOut();

		HttpServletRequest request = (HttpServletRequest) pageContext
				.getRequest();
		// 获取路径(工程路径)
		String basePath = request.getContextPath() + content;

		// 以下开始拼页面
		out.println("<script>function goTo(pageNum){location.href='" + basePath
				+ "&page='+pageNum;}</script>");

		out.println("页次：<font color='blue'>"
						+ page.getCurrentPage()
						+ '/'
						+ page.getMaxPage()
						+ "</font>&nbsp;页&nbsp;&nbsp;&nbsp;每页显示：<font color='blue'>"+page.getRowSize()+"</font>&nbsp;条&nbsp;&nbsp;&nbsp;记录数：<font color='blue'>"
						+ page.getRowCount() + "</font>&nbsp;条&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

		if (page.getCurrentPage() <= 1) {
			out.println("&nbsp;&nbsp;&nbsp;<font color='gray' style='font-size:12px;'>首页</font>&nbsp;&nbsp;&nbsp;");
			
			out.println("<font color='gray' style='font-size:12px;'>上一页</font>&nbsp;&nbsp;&nbsp;");
		} else {
			out.println("&nbsp;&nbsp;&nbsp;<a href='javascript:goTo(1)'><font color='blue' style='font-size:12px;'>首页</font></a>&nbsp;&nbsp;&nbsp;");
			
			out.println("<a href='javascript:goTo("
							+ page.getPreviousPage()
							+ ")'><font color='blue' style='font-size:12px;'>上一页</font></a>&nbsp;&nbsp;&nbsp;");

		}
		if (page.getCurrentPage() >= page.getMaxPage()) {
			out.println("<font color='gray' style='font-size:12px;'>下一页</font>&nbsp;&nbsp;&nbsp;");
			
			out.println("<font color='gray' style='font-size:12px;'>末页</font>");
		} else {
			out.println("<a href='javascript:goTo("
							+ page.getBackPage()
							+ ")' ><font color='blue' style='font-size:12px;'>下一页</font></a>&nbsp;&nbsp;&nbsp;");
			
			out.println("<a href='javascript:goTo("
							+ page.getMaxPage()
							+ ")'><font color='blue' style='font-size:12px;'>末页</font></a>");
		}

	}
}
