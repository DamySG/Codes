package com.hsg.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * Managerrole entity. @author MyEclipse Persistence Tools
 */

public class Managerrole implements java.io.Serializable {

	// Fields

	private Integer managerroleid;
	private String managerrolename;
	private Integer managerstate;
	private String RExtendone;
	private String RExtendtwo;
	private Integer RExtendthree;

	private Set treemenus=new HashSet(0);  //树形菜单集合
	private Set managers=new HashSet(0);  //管理员集合
	

    public Managerrole(String managerrolename, Integer managerstate,
			String rExtendone) {
		super();
		this.managerrolename = managerrolename;
		this.managerstate = managerstate;
		RExtendone = rExtendone;
	}
    
	// Constructors

	public Managerrole(Integer managerroleid, String managerrolename,
			Integer managerstate, String rExtendone, String rExtendtwo,
			Integer rExtendthree, Set treemenus, Set managers) {
		super();
		this.managerroleid = managerroleid;
		this.managerrolename = managerrolename;
		this.managerstate = managerstate;
		RExtendone = rExtendone;
		RExtendtwo = rExtendtwo;
		RExtendthree = rExtendthree;
		this.treemenus = treemenus;
		this.managers = managers;
	}

	public Set getTreemenus() {
		return treemenus;
	}

	public void setTreemenus(Set treemenus) {
		this.treemenus = treemenus;
	}

	public Set getManagers() {
		return managers;
	}

	public void setManagers(Set managers) {
		this.managers = managers;
	}
	
	// Constructors

	/** default constructor */
	public Managerrole() {
	}

	/** full constructor */
	public Managerrole(String managerrolename, Integer managerstate,
			String RExtendone, String RExtendtwo, Integer RExtendthree) {
		this.managerrolename = managerrolename;
		this.managerstate = managerstate;
		this.RExtendone = RExtendone;
		this.RExtendtwo = RExtendtwo;
		this.RExtendthree = RExtendthree;
	}

	// Property accessors

	public Integer getManagerroleid() {
		return this.managerroleid;
	}

	public void setManagerroleid(Integer managerroleid) {
		this.managerroleid = managerroleid;
	}

	public String getManagerrolename() {
		return this.managerrolename;
	}

	public void setManagerrolename(String managerrolename) {
		this.managerrolename = managerrolename;
	}

	public Integer getManagerstate() {
		return this.managerstate;
	}

	public void setManagerstate(Integer managerstate) {
		this.managerstate = managerstate;
	}

	public String getRExtendone() {
		return this.RExtendone;
	}

	public void setRExtendone(String RExtendone) {
		this.RExtendone = RExtendone;
	}

	public String getRExtendtwo() {
		return this.RExtendtwo;
	}

	public void setRExtendtwo(String RExtendtwo) {
		this.RExtendtwo = RExtendtwo;
	}

	public Integer getRExtendthree() {
		return this.RExtendthree;
	}

	public void setRExtendthree(Integer RExtendthree) {
		this.RExtendthree = RExtendthree;
	}

}