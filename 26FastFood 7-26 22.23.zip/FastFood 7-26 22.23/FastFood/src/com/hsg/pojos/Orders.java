package com.hsg.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Orders entity. @author MyEclipse Persistence Tools
 */

public class Orders implements java.io.Serializable {

	// Fields
	private String OId;
	private Manager manager;
	private Userinfo userinfo;
	private String OPaymethod;
	private String OSendtype;
	private String OSendaddress;
	private String OName;
	private String OPhone;
	private String OPost;
	private String OEmail;
	private Date OOrderdate;
	private Integer OCheck;
	private Integer OJiezhang;
	private Integer OState;
	private String ORemark;
	private String OExtendone;
	private String OExtendtwo;
	private Integer OExtendthree;
	private Set ordersdetails = new HashSet(0);

	// Constructors
	
	/** default constructor */
	public Orders() {
	}

	public Orders(String oSendtype, String oSendaddress, String oName,
			String oPhone, String oPost, String oEmail, Integer oCheck,
			Integer oJiezhang) {
		super();
		OSendtype = oSendtype;
		OSendaddress = oSendaddress;
		OName = oName;
		OPhone = oPhone;
		OPost = oPost;
		OEmail = oEmail;
		OCheck = oCheck;
		OJiezhang = oJiezhang;
	}

	public Orders(String oId, Userinfo userinfo, String oPaymethod,
			String oSendtype, String oSendaddress, String oName, String oPhone,
			String oPost, String oEmail, Date oOrderdate, Integer oCheck,
			Integer oJiezhang, Integer oState, String oRemark) {
		super();
		OId = oId;
		this.userinfo = userinfo;
		OPaymethod = oPaymethod;
		OSendtype = oSendtype;
		OSendaddress = oSendaddress;
		OName = oName;
		OPhone = oPhone;
		OPost = oPost;
		OEmail = oEmail;
		OOrderdate = oOrderdate;
		OCheck = oCheck;
		OJiezhang = oJiezhang;
		OState = oState;
		ORemark = oRemark;
	}

	/** full constructor */
	public Orders(Manager manager, Userinfo userinfo, String OPaymethod,
			String OSendtype, String OSendaddress, String OName, String OPhone,
			String OPost, String OEmail, Date OOrderdate, Integer OCheck,
			Integer OJiezhang, Integer OState, String ORemark,
			String OExtendone, String OExtendtwo, Integer OExtendthree,
			Set ordersdetails) {
		this.manager = manager;
		this.userinfo = userinfo;
		this.OPaymethod = OPaymethod;
		this.OSendtype = OSendtype;
		this.OSendaddress = OSendaddress;
		this.OName = OName;
		this.OPhone = OPhone;
		this.OPost = OPost;
		this.OEmail = OEmail;
		this.OOrderdate = OOrderdate;
		this.OCheck = OCheck;
		this.OJiezhang = OJiezhang;
		this.OState = OState;
		this.ORemark = ORemark;
		this.OExtendone = OExtendone;
		this.OExtendtwo = OExtendtwo;
		this.OExtendthree = OExtendthree;
		this.ordersdetails = ordersdetails;
	}

	// Property accessors

	public String getOId() {
		return this.OId;
	}

	public void setOId(String OId) {
		this.OId = OId;
	}

	public Manager getManager() {
		return this.manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	public Userinfo getUserinfo() {
		return this.userinfo;
	}

	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

	public String getOPaymethod() {
		return this.OPaymethod;
	}

	public void setOPaymethod(String OPaymethod) {
		this.OPaymethod = OPaymethod;
	}

	public String getOSendtype() {
		return this.OSendtype;
	}

	public void setOSendtype(String OSendtype) {
		this.OSendtype = OSendtype;
	}

	public String getOSendaddress() {
		return this.OSendaddress;
	}

	public void setOSendaddress(String OSendaddress) {
		this.OSendaddress = OSendaddress;
	}

	public String getOName() {
		return this.OName;
	}

	public void setOName(String OName) {
		this.OName = OName;
	}

	public String getOPhone() {
		return this.OPhone;
	}

	public void setOPhone(String OPhone) {
		this.OPhone = OPhone;
	}

	public String getOPost() {
		return this.OPost;
	}

	public void setOPost(String OPost) {
		this.OPost = OPost;
	}

	public String getOEmail() {
		return this.OEmail;
	}

	public void setOEmail(String OEmail) {
		this.OEmail = OEmail;
	}

	public Date getOOrderdate() {
		return this.OOrderdate;
	}

	public void setOOrderdate(Date OOrderdate) {
		this.OOrderdate = OOrderdate;
	}

	public Integer getOCheck() {
		return this.OCheck;
	}

	public void setOCheck(Integer OCheck) {
		this.OCheck = OCheck;
	}

	public Integer getOJiezhang() {
		return this.OJiezhang;
	}

	public void setOJiezhang(Integer OJiezhang) {
		this.OJiezhang = OJiezhang;
	}

	public Integer getOState() {
		return this.OState;
	}

	public void setOState(Integer OState) {
		this.OState = OState;
	}

	public String getORemark() {
		return this.ORemark;
	}

	public void setORemark(String ORemark) {
		this.ORemark = ORemark;
	}

	public String getOExtendone() {
		return this.OExtendone;
	}

	public void setOExtendone(String OExtendone) {
		this.OExtendone = OExtendone;
	}

	public String getOExtendtwo() {
		return this.OExtendtwo;
	}

	public void setOExtendtwo(String OExtendtwo) {
		this.OExtendtwo = OExtendtwo;
	}

	public Integer getOExtendthree() {
		return this.OExtendthree;
	}

	public void setOExtendthree(Integer OExtendthree) {
		this.OExtendthree = OExtendthree;
	}

	public Set getOrdersdetails() {
		return this.ordersdetails;
	}

	public void setOrdersdetails(Set ordersdetails) {
		this.ordersdetails = ordersdetails;
	}

}