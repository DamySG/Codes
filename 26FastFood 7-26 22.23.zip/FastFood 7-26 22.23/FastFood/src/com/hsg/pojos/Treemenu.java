package com.hsg.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * Treemenu entity. @author MyEclipse Persistence Tools
 */

public class Treemenu implements java.io.Serializable {

	// Fields

	private Integer treemenuid;
	private String treemenuname;
	private Integer treeprentid;
	private String treemenusrc;
	private Integer treemenustate;
	private String TExtendone;
	private String TExtendtwo;
	private Integer TExtendthree;

	private Set managerroles=new HashSet(0);  //角色集合
	
	public Treemenu(Integer treemenuid, String treemenuname,
			Integer treeprentid, String treemenusrc, Integer treemenustate,
			String tExtendone, String tExtendtwo, Integer tExtendthree,
			Set managerroles) {
		super();
		this.treemenuid = treemenuid;
		this.treemenuname = treemenuname;
		this.treeprentid = treeprentid;
		this.treemenusrc = treemenusrc;
		this.treemenustate = treemenustate;
		TExtendone = tExtendone;
		TExtendtwo = tExtendtwo;
		TExtendthree = tExtendthree;
		this.managerroles = managerroles;
	}

	// Constructors

	public Set getManagerroles() {
		return managerroles;
	}

	public void setManagerroles(Set managerroles) {
		this.managerroles = managerroles;
	}
	
	// Constructors

	/** default constructor */
	public Treemenu() {
	}

	/** full constructor */
	public Treemenu(String treemenuname, Integer treeprentid,
			String treemenusrc, Integer treemenustate, String TExtendone,
			String TExtendtwo, Integer TExtendthree) {
		this.treemenuname = treemenuname;
		this.treeprentid = treeprentid;
		this.treemenusrc = treemenusrc;
		this.treemenustate = treemenustate;
		this.TExtendone = TExtendone;
		this.TExtendtwo = TExtendtwo;
		this.TExtendthree = TExtendthree;
	}

	// Property accessors

	public Integer getTreemenuid() {
		return this.treemenuid;
	}

	public void setTreemenuid(Integer treemenuid) {
		this.treemenuid = treemenuid;
	}

	public String getTreemenuname() {
		return this.treemenuname;
	}

	public void setTreemenuname(String treemenuname) {
		this.treemenuname = treemenuname;
	}

	public Integer getTreeprentid() {
		return this.treeprentid;
	}

	public void setTreeprentid(Integer treeprentid) {
		this.treeprentid = treeprentid;
	}

	public String getTreemenusrc() {
		return this.treemenusrc;
	}

	public void setTreemenusrc(String treemenusrc) {
		this.treemenusrc = treemenusrc;
	}

	public Integer getTreemenustate() {
		return this.treemenustate;
	}

	public void setTreemenustate(Integer treemenustate) {
		this.treemenustate = treemenustate;
	}

	public String getTExtendone() {
		return this.TExtendone;
	}

	public void setTExtendone(String TExtendone) {
		this.TExtendone = TExtendone;
	}

	public String getTExtendtwo() {
		return this.TExtendtwo;
	}

	public void setTExtendtwo(String TExtendtwo) {
		this.TExtendtwo = TExtendtwo;
	}

	public Integer getTExtendthree() {
		return this.TExtendthree;
	}

	public void setTExtendthree(Integer TExtendthree) {
		this.TExtendthree = TExtendthree;
	}

}