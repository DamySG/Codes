package com.hsg.pojos;

import java.util.Collection;
import java.util.HashMap;

/**
 * 购物车类
 * @author hushiguo
 *
 */
public class ShoppingCar {
	//用haspMap保存购买商品信息(购物车)
	HashMap<Integer, FoodInfoBean> map=new HashMap<Integer, FoodInfoBean>();
	
	public HashMap<Integer, FoodInfoBean> getMap() {
		return map;
	}
	public void setMap(HashMap<Integer, FoodInfoBean> map) {
		this.map = map;
	}


    /**
     * 向购物车中添加商品
     * @param foodBean
     */
	public void addFoodInfo(FoodInfoBean  foodBean){
		Foodinfo  foodInfo=foodBean.getFoodinfo();
		int foodId=foodInfo.getFoodid();  //获得要添加的商品编号
		
		//判断购物车中是否存在该商品，有的话就增加数量，否则增加一条新信息
		if(map.containsKey(foodId)){
			FoodInfoBean oldBean=map.get(foodId);
			//添加数量
			oldBean.setBuy(oldBean.getBuy()+1);
			map.put(foodId,oldBean);
		}else{
			//否则添加一条商品信息
			map.put(foodId,foodBean);
		}
	}
	
	/**
	 * 根据编号删除购买的商品
	 * @param foodInfoId
	 */
	public void deleteFoodInfo(Integer foodInfoId){
		map.remove(foodInfoId);
	}
	
	/**
	 * 获得所有购物车内的商品信息
	 * @return
	 */
	public Collection<FoodInfoBean> getAllFoodInfo(){
		return map.values();
	}
	
	/**
	 * 获得购物车内商品的数量
	 * @return
	 */
	public Integer getCarCount(){
		return map.size();
	}
	
	/**
	 * 清空购物车
	 */
	public void clearShoppingCar(){
		map.clear();
	}
}
