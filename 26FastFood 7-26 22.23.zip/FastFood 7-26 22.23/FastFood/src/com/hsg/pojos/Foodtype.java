package com.hsg.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * Foodtype entity. @author MyEclipse Persistence Tools
 */

public class Foodtype implements java.io.Serializable {

	// Fields

	private Integer FTypeid;
	private String FTypename;
	private String FRemark;
	private Integer FState;
	private Integer FBigtype;
	private Set foodinfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public Foodtype() {
	}

	/** full constructor */
	public Foodtype(String FTypename, String FRemark, Integer FState,
			Integer FBigtype, Set foodinfos) {
		this.FTypename = FTypename;
		this.FRemark = FRemark;
		this.FState = FState;
		this.FBigtype = FBigtype;
		this.foodinfos = foodinfos;
	}

	// Property accessors

	public Integer getFTypeid() {
		return this.FTypeid;
	}

	public void setFTypeid(Integer FTypeid) {
		this.FTypeid = FTypeid;
	}

	public String getFTypename() {
		return this.FTypename;
	}

	public void setFTypename(String FTypename) {
		this.FTypename = FTypename;
	}

	public String getFRemark() {
		return this.FRemark;
	}

	public void setFRemark(String FRemark) {
		this.FRemark = FRemark;
	}

	public Integer getFState() {
		return this.FState;
	}

	public void setFState(Integer FState) {
		this.FState = FState;
	}

	public Integer getFBigtype() {
		return this.FBigtype;
	}

	public void setFBigtype(Integer FBigtype) {
		this.FBigtype = FBigtype;
	}

	public Set getFoodinfos() {
		return this.foodinfos;
	}

	public void setFoodinfos(Set foodinfos) {
		this.foodinfos = foodinfos;
	}

}