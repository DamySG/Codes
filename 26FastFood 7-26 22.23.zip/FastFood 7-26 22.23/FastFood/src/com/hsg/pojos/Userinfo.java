package com.hsg.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Userinfo entity. @author MyEclipse Persistence Tools
 */

public class Userinfo implements java.io.Serializable {

	// Fields

	private Integer userid;
	private String username;
	private String pwd;
	private Integer sex;
	private Date registerdate;
	private String photos;
	private String address;
	private String email;
	private String telephone;
	private Date lastlogin;
	private Integer logintime;
	private Integer usercoin;
	private Integer userstate;
	private String userjp;
	private String URemarks;
	private Double UExtendone;
	private String UExtendtwo;
	private String UExtendthree;
	private Set orderses = new HashSet(0);
	private Set advices = new HashSet(0);

	// Constructors

	/** default constructor */
	public Userinfo() {
	}

	/** full constructor */
	public Userinfo(String username, String pwd, Integer sex,
			Date registerdate, String photos, String address, String email,
			String telephone, Date lastlogin, Integer logintime,
			Integer usercoin, Integer userstate, String userjp,
			String URemarks, Double UExtendone, String UExtendtwo,
			String UExtendthree, Set orderses, Set advices) {
		this.username = username;
		this.pwd = pwd;
		this.sex = sex;
		this.registerdate = registerdate;
		this.photos = photos;
		this.address = address;
		this.email = email;
		this.telephone = telephone;
		this.lastlogin = lastlogin;
		this.logintime = logintime;
		this.usercoin = usercoin;
		this.userstate = userstate;
		this.userjp = userjp;
		this.URemarks = URemarks;
		this.UExtendone = UExtendone;
		this.UExtendtwo = UExtendtwo;
		this.UExtendthree = UExtendthree;
		this.orderses = orderses;
		this.advices = advices;
	}
	
	
	/** 前台会员注册 */
	public Userinfo(String username, String pwd, Integer sex,
			Date registerdate,String photos,String address, String email,
			String telephone,Integer userstate) {
		this.username = username;
		this.pwd = pwd;
		this.sex = sex;
		this.registerdate = registerdate;
		this.photos = photos;
		this.address = address;
		this.email = email;
		this.telephone = telephone;
		this.userstate = userstate;

	}
	
	/** 后台会员注册 */
	public Userinfo(String username, String pwd, Integer sex,
			Date registerdate, String photos, String address, String email,
			String telephone,Integer userstate,String URemarks) {
		this.username = username;
		this.pwd = pwd;
		this.sex = sex;
		this.registerdate = registerdate;
		this.photos = photos;
		this.address = address;
		this.email = email;
		this.telephone = telephone;
		this.userstate = userstate;
		this.URemarks = URemarks;
	}

	// Property accessors

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPwd() {
		return this.pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public Integer getSex() {
		return this.sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public Date getRegisterdate() {
		return this.registerdate;
	}

	public void setRegisterdate(Date registerdate) {
		this.registerdate = registerdate;
	}

	public String getPhotos() {
		return this.photos;
	}

	public void setPhotos(String photos) {
		this.photos = photos;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Date getLastlogin() {
		return this.lastlogin;
	}

	public void setLastlogin(Date lastlogin) {
		this.lastlogin = lastlogin;
	}

	public Integer getLogintime() {
		return this.logintime;
	}

	public void setLogintime(Integer logintime) {
		this.logintime = logintime;
	}

	public Integer getUsercoin() {
		return this.usercoin;
	}

	public void setUsercoin(Integer usercoin) {
		this.usercoin = usercoin;
	}

	public Integer getUserstate() {
		return this.userstate;
	}

	public void setUserstate(Integer userstate) {
		this.userstate = userstate;
	}

	public String getUserjp() {
		return this.userjp;
	}

	public void setUserjp(String userjp) {
		this.userjp = userjp;
	}

	public String getURemarks() {
		return this.URemarks;
	}

	public void setURemarks(String URemarks) {
		this.URemarks = URemarks;
	}

	public Double getUExtendone() {
		return this.UExtendone;
	}

	public void setUExtendone(Double UExtendone) {
		this.UExtendone = UExtendone;
	}

	public String getUExtendtwo() {
		return this.UExtendtwo;
	}

	public void setUExtendtwo(String UExtendtwo) {
		this.UExtendtwo = UExtendtwo;
	}

	public String getUExtendthree() {
		return this.UExtendthree;
	}

	public void setUExtendthree(String UExtendthree) {
		this.UExtendthree = UExtendthree;
	}

	public Set getOrderses() {
		return this.orderses;
	}

	public void setOrderses(Set orderses) {
		this.orderses = orderses;
	}

	public Set getAdvices() {
		return this.advices;
	}

	public void setAdvices(Set advices) {
		this.advices = advices;
	}

}