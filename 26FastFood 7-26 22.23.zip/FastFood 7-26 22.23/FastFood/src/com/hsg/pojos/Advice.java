package com.hsg.pojos;

import java.util.Date;

/**
 * Advice entity. @author MyEclipse Persistence Tools
 */

public class Advice implements java.io.Serializable {

	// Fields

	private Integer adId;
	private Foodinfo foodinfo;
	private Userinfo userinfo;
	private String adTitle;
	private String adContent;
	private Date adDate;
	private Integer adState;
	private String adExtendone;
	private String adExtendtwo;
	private Integer adExtendthree;

	// Constructors

	/** default constructor */
	public Advice() {
	}

	/** full constructor */
	public Advice(Foodinfo foodinfo, Userinfo userinfo, String adTitle,
			String adContent, Date adDate, Integer adState, String adExtendone,
			String adExtendtwo, Integer adExtendthree) {
		this.foodinfo = foodinfo;
		this.userinfo = userinfo;
		this.adTitle = adTitle;
		this.adContent = adContent;
		this.adDate = adDate;
		this.adState = adState;
		this.adExtendone = adExtendone;
		this.adExtendtwo = adExtendtwo;
		this.adExtendthree = adExtendthree;
	}

	
	/** full constructor */
	public Advice(Foodinfo foodinfo, Userinfo userinfo,
			String adContent, Date adDate, Integer adState) {
		this.foodinfo = foodinfo;
		this.userinfo = userinfo;
		this.adContent = adContent;
		this.adDate = adDate;
		this.adState = adState;

	}
	
	// Property accessors

	public Integer getAdId() {
		return this.adId;
	}

	public void setAdId(Integer adId) {
		this.adId = adId;
	}

	public Foodinfo getFoodinfo() {
		return this.foodinfo;
	}

	public void setFoodinfo(Foodinfo foodinfo) {
		this.foodinfo = foodinfo;
	}

	public Userinfo getUserinfo() {
		return this.userinfo;
	}

	public void setUserinfo(Userinfo userinfo) {
		this.userinfo = userinfo;
	}

	public String getAdTitle() {
		return this.adTitle;
	}

	public void setAdTitle(String adTitle) {
		this.adTitle = adTitle;
	}

	public String getAdContent() {
		return this.adContent;
	}

	public void setAdContent(String adContent) {
		this.adContent = adContent;
	}

	public Date getAdDate() {
		return this.adDate;
	}

	public void setAdDate(Date adDate) {
		this.adDate = adDate;
	}

	public Integer getAdState() {
		return this.adState;
	}

	public void setAdState(Integer adState) {
		this.adState = adState;
	}

	public String getAdExtendone() {
		return this.adExtendone;
	}

	public void setAdExtendone(String adExtendone) {
		this.adExtendone = adExtendone;
	}

	public String getAdExtendtwo() {
		return this.adExtendtwo;
	}

	public void setAdExtendtwo(String adExtendtwo) {
		this.adExtendtwo = adExtendtwo;
	}

	public Integer getAdExtendthree() {
		return this.adExtendthree;
	}

	public void setAdExtendthree(Integer adExtendthree) {
		this.adExtendthree = adExtendthree;
	}

}