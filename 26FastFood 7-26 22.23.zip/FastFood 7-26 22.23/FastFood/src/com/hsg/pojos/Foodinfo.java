package com.hsg.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * Foodinfo entity. @author MyEclipse Persistence Tools
 */

public class Foodinfo implements java.io.Serializable {

	// Fields

	private Integer foodid;
	private Foodtype foodtype;
	private String foodname;
	private String foodimg;
	private Double danjia;
	private Integer foodcoin;
	private String mainfood;
	private String taste;
	private Integer foodnumber;
	private String foodremark;
	private Integer FState;
	private String FJp;
	private String extendone;
	private String extendtwo;
	private Integer extendthree;
	private Set advices = new HashSet(0);
	private Set ordersdetails = new HashSet(0);

	// Constructors

	/** default constructor */
	public Foodinfo() {
	}

	
	

	/** full constructor */
	public Foodinfo(Foodtype foodtype, String foodname, String foodimg,
			Double danjia, Integer foodcoin, String mainfood, String taste,
			Integer foodnumber, String foodremark, Integer FState, String FJp,
			String extendone, String extendtwo, Integer extendthree,
			Set advices, Set ordersdetails) {
		this.foodtype = foodtype;
		this.foodname = foodname;
		this.foodimg = foodimg;
		this.danjia = danjia;
		this.foodcoin = foodcoin;
		this.mainfood = mainfood;
		this.taste = taste;
		this.foodnumber = foodnumber;
		this.foodremark = foodremark;
		this.FState = FState;
		this.FJp = FJp;
		this.extendone = extendone;
		this.extendtwo = extendtwo;
		this.extendthree = extendthree;
		this.advices = advices;
		this.ordersdetails = ordersdetails;
	}

	// Property accessors

	public Foodinfo(Foodtype foodtype, String foodname, String foodimg,
			Double danjia, Integer foodcoin, String mainfood, String taste,
			Integer foodnumber, String foodremark, Integer fState) {
		super();
		this.foodtype = foodtype;
		this.foodname = foodname;
		this.foodimg = foodimg;
		this.danjia = danjia;
		this.foodcoin = foodcoin;
		this.mainfood = mainfood;
		this.taste = taste;
		this.foodnumber = foodnumber;
		this.foodremark = foodremark;
		FState = fState;
	}


	public Integer getFoodid() {
		return this.foodid;
	}

	public void setFoodid(Integer foodid) {
		this.foodid = foodid;
	}

	public Foodtype getFoodtype() {
		return this.foodtype;
	}

	public void setFoodtype(Foodtype foodtype) {
		this.foodtype = foodtype;
	}

	public String getFoodname() {
		return this.foodname;
	}

	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}

	public String getFoodimg() {
		return this.foodimg;
	}

	public void setFoodimg(String foodimg) {
		this.foodimg = foodimg;
	}

	public Double getDanjia() {
		return this.danjia;
	}

	public void setDanjia(Double danjia) {
		this.danjia = danjia;
	}

	public Integer getFoodcoin() {
		return this.foodcoin;
	}

	public void setFoodcoin(Integer foodcoin) {
		this.foodcoin = foodcoin;
	}

	public String getMainfood() {
		return this.mainfood;
	}

	public void setMainfood(String mainfood) {
		this.mainfood = mainfood;
	}

	public String getTaste() {
		return this.taste;
	}

	public void setTaste(String taste) {
		this.taste = taste;
	}

	public Integer getFoodnumber() {
		return this.foodnumber;
	}

	public void setFoodnumber(Integer foodnumber) {
		this.foodnumber = foodnumber;
	}

	public String getFoodremark() {
		return this.foodremark;
	}

	public void setFoodremark(String foodremark) {
		this.foodremark = foodremark;
	}

	public Integer getFState() {
		return this.FState;
	}

	public void setFState(Integer FState) {
		this.FState = FState;
	}

	public String getFJp() {
		return this.FJp;
	}

	public void setFJp(String FJp) {
		this.FJp = FJp;
	}

	public String getExtendone() {
		return this.extendone;
	}

	public void setExtendone(String extendone) {
		this.extendone = extendone;
	}

	public String getExtendtwo() {
		return this.extendtwo;
	}

	public void setExtendtwo(String extendtwo) {
		this.extendtwo = extendtwo;
	}

	public Integer getExtendthree() {
		return this.extendthree;
	}

	public void setExtendthree(Integer extendthree) {
		this.extendthree = extendthree;
	}

	public Set getAdvices() {
		return this.advices;
	}

	public void setAdvices(Set advices) {
		this.advices = advices;
	}

	public Set getOrdersdetails() {
		return this.ordersdetails;
	}

	public void setOrdersdetails(Set ordersdetails) {
		this.ordersdetails = ordersdetails;
	}

}