package com.hsg.pojos;

/**
 * Accounts entity. @author MyEclipse Persistence Tools
 */

public class Accounts implements java.io.Serializable {

	// Fields

	private String acId;
	private Banktype banktype;
	private Integer acPwd;
	private Double acMoney;
	private String acExtendone;
	private String acExtendtwo;
	private Integer acExtendthree;

	// Constructors

	/** default constructor */
	public Accounts() {
	}

	/** full constructor */
	public Accounts(Banktype banktype, Integer acPwd, Double acMoney,
			String acExtendone, String acExtendtwo, Integer acExtendthree) {
		this.banktype = banktype;
		this.acPwd = acPwd;
		this.acMoney = acMoney;
		this.acExtendone = acExtendone;
		this.acExtendtwo = acExtendtwo;
		this.acExtendthree = acExtendthree;
	}

	// Property accessors

	public String getAcId() {
		return this.acId;
	}

	public void setAcId(String acId) {
		this.acId = acId;
	}

	public Banktype getBanktype() {
		return this.banktype;
	}

	public void setBanktype(Banktype banktype) {
		this.banktype = banktype;
	}

	public Integer getAcPwd() {
		return this.acPwd;
	}

	public void setAcPwd(Integer acPwd) {
		this.acPwd = acPwd;
	}

	public Double getAcMoney() {
		return this.acMoney;
	}

	public void setAcMoney(Double acMoney) {
		this.acMoney = acMoney;
	}

	public String getAcExtendone() {
		return this.acExtendone;
	}

	public void setAcExtendone(String acExtendone) {
		this.acExtendone = acExtendone;
	}

	public String getAcExtendtwo() {
		return this.acExtendtwo;
	}

	public void setAcExtendtwo(String acExtendtwo) {
		this.acExtendtwo = acExtendtwo;
	}

	public Integer getAcExtendthree() {
		return this.acExtendthree;
	}

	public void setAcExtendthree(Integer acExtendthree) {
		this.acExtendthree = acExtendthree;
	}

}