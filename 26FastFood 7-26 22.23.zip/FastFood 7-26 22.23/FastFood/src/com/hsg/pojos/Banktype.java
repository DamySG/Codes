package com.hsg.pojos;

import java.util.HashSet;
import java.util.Set;

/**
 * Banktype entity. @author MyEclipse Persistence Tools
 */

public class Banktype implements java.io.Serializable {

	// Fields

	private Integer btId;
	private String btName;
	private Integer btState;
	private String btExtendone;
	private String btExtendtwo;
	private Integer btExtendthree;
	private Set accountses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Banktype() {
	}

	/** full constructor */
	public Banktype(String btName, Integer btState, String btExtendone,
			String btExtendtwo, Integer btExtendthree, Set accountses) {
		this.btName = btName;
		this.btState = btState;
		this.btExtendone = btExtendone;
		this.btExtendtwo = btExtendtwo;
		this.btExtendthree = btExtendthree;
		this.accountses = accountses;
	}

	// Property accessors

	public Integer getBtId() {
		return this.btId;
	}

	public void setBtId(Integer btId) {
		this.btId = btId;
	}

	public String getBtName() {
		return this.btName;
	}

	public void setBtName(String btName) {
		this.btName = btName;
	}

	public Integer getBtState() {
		return this.btState;
	}

	public void setBtState(Integer btState) {
		this.btState = btState;
	}

	public String getBtExtendone() {
		return this.btExtendone;
	}

	public void setBtExtendone(String btExtendone) {
		this.btExtendone = btExtendone;
	}

	public String getBtExtendtwo() {
		return this.btExtendtwo;
	}

	public void setBtExtendtwo(String btExtendtwo) {
		this.btExtendtwo = btExtendtwo;
	}

	public Integer getBtExtendthree() {
		return this.btExtendthree;
	}

	public void setBtExtendthree(Integer btExtendthree) {
		this.btExtendthree = btExtendthree;
	}

	public Set getAccountses() {
		return this.accountses;
	}

	public void setAccountses(Set accountses) {
		this.accountses = accountses;
	}

}