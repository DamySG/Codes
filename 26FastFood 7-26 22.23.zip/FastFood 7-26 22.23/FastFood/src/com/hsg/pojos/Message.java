package com.hsg.pojos;

/**
 * Message entity. @author MyEclipse Persistence Tools
 */

public class Message implements java.io.Serializable {

	// Fields

	private Integer msId;
	private String msTitle;
	private String msUsername;
	private String msEmail;
	private String msQq;
	private String mgPhotos;
	private String msContent;
	private Integer msState;
	private String msExtendone;
	private String msExtendtwo;
	private Integer msExtendthree;

	// Constructors

	/** default constructor */
	public Message() {
	}

	/** full constructor */
	public Message(String msTitle, String msUsername, String msEmail,
			String msQq, String mgPhotos, String msContent, Integer msState,
			String msExtendone, String msExtendtwo, Integer msExtendthree) {
		this.msTitle = msTitle;
		this.msUsername = msUsername;
		this.msEmail = msEmail;
		this.msQq = msQq;
		this.mgPhotos = mgPhotos;
		this.msContent = msContent;
		this.msState = msState;
		this.msExtendone = msExtendone;
		this.msExtendtwo = msExtendtwo;
		this.msExtendthree = msExtendthree;
	}

	
	/** full constructor */
	public Message(String msTitle, String msUsername, String msEmail,
			String msQq, String mgPhotos, String msContent, Integer msState) {
		this.msTitle = msTitle;
		this.msUsername = msUsername;
		this.msEmail = msEmail;
		this.msQq = msQq;
		this.mgPhotos = mgPhotos;
		this.msContent = msContent;
		this.msState = msState;
	}
	
	/**
	 * 分页查询留言信息
	 * @param msTitle
	 * @param msUsername
	 * @param msEmail
	 * @param msQq
	 * @param mgPhotos
	 * @param msContent
	 * @param msExtendone
	 * @param msState
	 */
	public Message(String msTitle, String msUsername, String msEmail,
			String msQq, String mgPhotos, String msContent, String msExtendone, Integer msState) {
		this.msTitle = msTitle;
		this.msUsername = msUsername;
		this.msEmail = msEmail;
		this.msQq = msQq;
		this.mgPhotos = mgPhotos;
		this.msContent = msContent;
		this.msExtendone = msExtendone;
		this.msState = msState;
	}
	
	// Property accessors

	public Integer getMsId() {
		return this.msId;
	}

	public void setMsId(Integer msId) {
		this.msId = msId;
	}

	public String getMsTitle() {
		return this.msTitle;
	}

	public void setMsTitle(String msTitle) {
		this.msTitle = msTitle;
	}

	public String getMsUsername() {
		return this.msUsername;
	}

	public void setMsUsername(String msUsername) {
		this.msUsername = msUsername;
	}

	public String getMsEmail() {
		return this.msEmail;
	}

	public void setMsEmail(String msEmail) {
		this.msEmail = msEmail;
	}

	public String getMsQq() {
		return this.msQq;
	}

	public void setMsQq(String msQq) {
		this.msQq = msQq;
	}

	public String getMgPhotos() {
		return this.mgPhotos;
	}

	public void setMgPhotos(String mgPhotos) {
		this.mgPhotos = mgPhotos;
	}

	public String getMsContent() {
		return this.msContent;
	}

	public void setMsContent(String msContent) {
		this.msContent = msContent;
	}

	public Integer getMsState() {
		return this.msState;
	}

	public void setMsState(Integer msState) {
		this.msState = msState;
	}

	public String getMsExtendone() {
		return this.msExtendone;
	}

	public void setMsExtendone(String msExtendone) {
		this.msExtendone = msExtendone;
	}

	public String getMsExtendtwo() {
		return this.msExtendtwo;
	}

	public void setMsExtendtwo(String msExtendtwo) {
		this.msExtendtwo = msExtendtwo;
	}

	public Integer getMsExtendthree() {
		return this.msExtendthree;
	}

	public void setMsExtendthree(Integer msExtendthree) {
		this.msExtendthree = msExtendthree;
	}

}