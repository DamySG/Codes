package com.hsg.pojos;

/**
 * 保存购物车实体类信息
 * @author hushiguo
 *
 */
public class FoodInfoBean {

	private Foodinfo foodinfo;    //商品所有信息
	private Integer buy;  //商品购买数量
	
	public FoodInfoBean(Foodinfo foodinfo, Integer buy) {
		super();
		this.foodinfo = foodinfo;
		this.buy = buy;
	}
	public Foodinfo getFoodinfo() {
		return foodinfo;
	}
	public void setFoodinfo(Foodinfo foodinfo) {
		this.foodinfo = foodinfo;
	}
	public Integer getBuy() {
		return buy;
	}
	public void setBuy(Integer buy) {
		this.buy = buy;
	}
	
	public FoodInfoBean() {
		super();
	}
	
}
