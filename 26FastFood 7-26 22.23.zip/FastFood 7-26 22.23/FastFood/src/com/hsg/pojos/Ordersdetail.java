package com.hsg.pojos;

/**
 * Ordersdetail entity. @author MyEclipse Persistence Tools
 */

public class Ordersdetail implements java.io.Serializable {

	// Fields

	private Integer odId;
	private Orders orders;
	private Foodinfo foodinfo;
	private Integer odBuynum;
	private Double odTotalmoney;
	private String odRemark;
	private Integer odState;
	private String odExtendone;
	private String odExtendtwo;
	private Integer odExtendthree;

	// Constructors

	/** default constructor */
	public Ordersdetail() {
	}

	public Ordersdetail(Orders orders, Foodinfo foodinfo, Integer odBuynum,
			Double odTotalmoney, Integer odState) {
		super();
		this.orders = orders;
		this.foodinfo = foodinfo;
		this.odBuynum = odBuynum;
		this.odTotalmoney = odTotalmoney;
		this.odState = odState;
	}



	/** full constructor */
	public Ordersdetail(Orders orders, Foodinfo foodinfo, Integer odBuynum,
			Double odTotalmoney, String odRemark, Integer odState,
			String odExtendone, String odExtendtwo, Integer odExtendthree) {
		this.orders = orders;
		this.foodinfo = foodinfo;
		this.odBuynum = odBuynum;
		this.odTotalmoney = odTotalmoney;
		this.odRemark = odRemark;
		this.odState = odState;
		this.odExtendone = odExtendone;
		this.odExtendtwo = odExtendtwo;
		this.odExtendthree = odExtendthree;
	}

	// Property accessors

	public Integer getOdId() {
		return this.odId;
	}

	public void setOdId(Integer odId) {
		this.odId = odId;
	}

	public Orders getOrders() {
		return this.orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	public Foodinfo getFoodinfo() {
		return this.foodinfo;
	}

	public void setFoodinfo(Foodinfo foodinfo) {
		this.foodinfo = foodinfo;
	}

	public Integer getOdBuynum() {
		return this.odBuynum;
	}

	public void setOdBuynum(Integer odBuynum) {
		this.odBuynum = odBuynum;
	}

	public Double getOdTotalmoney() {
		return this.odTotalmoney;
	}

	public void setOdTotalmoney(Double odTotalmoney) {
		this.odTotalmoney = odTotalmoney;
	}

	public String getOdRemark() {
		return this.odRemark;
	}

	public void setOdRemark(String odRemark) {
		this.odRemark = odRemark;
	}

	public Integer getOdState() {
		return this.odState;
	}

	public void setOdState(Integer odState) {
		this.odState = odState;
	}

	public String getOdExtendone() {
		return this.odExtendone;
	}

	public void setOdExtendone(String odExtendone) {
		this.odExtendone = odExtendone;
	}

	public String getOdExtendtwo() {
		return this.odExtendtwo;
	}

	public void setOdExtendtwo(String odExtendtwo) {
		this.odExtendtwo = odExtendtwo;
	}

	public Integer getOdExtendthree() {
		return this.odExtendthree;
	}

	public void setOdExtendthree(Integer odExtendthree) {
		this.odExtendthree = odExtendthree;
	}

}