package com.hsg.pojos;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * Manager entity. @author MyEclipse Persistence Tools
 */

public class Manager implements java.io.Serializable {

	// Fields

	private Integer mgId;
	private String mgName;
	private String mgPwd;
	private String mgPhone;
	private String mgAddress;
	private Integer mgState;
	private Date mgLastlogin;
	private String mgExtendone;
	private String mgExtendtwo;
	private Integer mgExtendthree;
	private Set orderses = new HashSet(0);

    private Set managerroles = new HashSet(0);  //管理员角色

    
	
	public Manager(Integer mgId, String mgName, String mgPwd, String mgPhone,
			String mgAddress, Integer mgState, Date mgLastlogin,
			String mgExtendone, String mgExtendtwo, Integer mgExtendthree,
			Set managerroles) {
		super();
		this.mgId = mgId;
		this.mgName = mgName;
		this.mgPwd = mgPwd;
		this.mgPhone = mgPhone;
		this.mgAddress = mgAddress;
		this.mgState = mgState;
		this.mgLastlogin = mgLastlogin;
		this.mgExtendone = mgExtendone;
		this.mgExtendtwo = mgExtendtwo;
		this.mgExtendthree = mgExtendthree;
		this.managerroles = managerroles;
	}
	
	
	public Manager(String mgName, String mgPwd, String mgPhone,
			String mgAddress, Integer mgState, String mgExtendone,
			String mgExtendtwo, Integer mgExtendthree, Set managerroles) {
		super();
		this.mgName = mgName;
		this.mgPwd = mgPwd;
		this.mgPhone = mgPhone;
		this.mgAddress = mgAddress;
		this.mgState = mgState;
		this.mgExtendone = mgExtendone;
		this.mgExtendtwo = mgExtendtwo;
		this.mgExtendthree = mgExtendthree;
		this.managerroles = managerroles;
	}


	public Manager(Integer mgId, String mgName, String mgPwd, String mgPhone,
			String mgAddress, Integer mgState, Date mgLastlogin,
			String mgExtendone, String mgExtendtwo, Integer mgExtendthree,
			Set orderses, Set managerroles) {
		super();
		this.mgId = mgId;
		this.mgName = mgName;
		this.mgPwd = mgPwd;
		this.mgPhone = mgPhone;
		this.mgAddress = mgAddress;
		this.mgState = mgState;
		this.mgLastlogin = mgLastlogin;
		this.mgExtendone = mgExtendone;
		this.mgExtendtwo = mgExtendtwo;
		this.mgExtendthree = mgExtendthree;
		this.orderses = orderses;
		this.managerroles = managerroles;
	}

	// Constructors

	public Set getManagerroles() {
		return managerroles;
	}

	public void setManagerroles(Set managerroles) {
		this.managerroles = managerroles;
	}
	
	
	// Constructors

	/** default constructor */
	public Manager() {
	}

	/** full constructor */
	public Manager(String mgName, String mgPwd, String mgPhone,
			String mgAddress, Integer mgState, Date mgLastlogin,
			String mgExtendone, String mgExtendtwo, Integer mgExtendthree,
			Set orderses) {
		this.mgName = mgName;
		this.mgPwd = mgPwd;
		this.mgPhone = mgPhone;
		this.mgAddress = mgAddress;
		this.mgState = mgState;
		this.mgLastlogin = mgLastlogin;
		this.mgExtendone = mgExtendone;
		this.mgExtendtwo = mgExtendtwo;
		this.mgExtendthree = mgExtendthree;
		this.orderses = orderses;
	}

	/**后台添加管理员 */
	public Manager(String mgName, String mgPwd, String mgPhone,
			String mgAddress, Integer mgState,
			String mgExtendone, String mgExtendtwo, Integer mgExtendthree) {
		this.mgName = mgName;
		this.mgPwd = mgPwd;
		this.mgPhone = mgPhone;
		this.mgAddress = mgAddress;
		this.mgState = mgState;
		this.mgExtendone = mgExtendone;
		this.mgExtendtwo = mgExtendtwo;
		this.mgExtendthree = mgExtendthree;
	}
	
	
	// Property accessors

	public Integer getMgId() {
		return this.mgId;
	}

	public void setMgId(Integer mgId) {
		this.mgId = mgId;
	}

	public String getMgName() {
		return this.mgName;
	}

	public void setMgName(String mgName) {
		this.mgName = mgName;
	}

	public String getMgPwd() {
		return this.mgPwd;
	}

	public void setMgPwd(String mgPwd) {
		this.mgPwd = mgPwd;
	}

	public String getMgPhone() {
		return this.mgPhone;
	}

	public void setMgPhone(String mgPhone) {
		this.mgPhone = mgPhone;
	}

	public String getMgAddress() {
		return this.mgAddress;
	}

	public void setMgAddress(String mgAddress) {
		this.mgAddress = mgAddress;
	}

	public Integer getMgState() {
		return this.mgState;
	}

	public void setMgState(Integer mgState) {
		this.mgState = mgState;
	}

	public Date getMgLastlogin() {
		return this.mgLastlogin;
	}

	public void setMgLastlogin(Date mgLastlogin) {
		this.mgLastlogin = mgLastlogin;
	}

	public String getMgExtendone() {
		return this.mgExtendone;
	}

	public void setMgExtendone(String mgExtendone) {
		this.mgExtendone = mgExtendone;
	}

	public String getMgExtendtwo() {
		return this.mgExtendtwo;
	}

	public void setMgExtendtwo(String mgExtendtwo) {
		this.mgExtendtwo = mgExtendtwo;
	}

	public Integer getMgExtendthree() {
		return this.mgExtendthree;
	}

	public void setMgExtendthree(Integer mgExtendthree) {
		this.mgExtendthree = mgExtendthree;
	}

	public Set getOrderses() {
		return this.orderses;
	}

	public void setOrderses(Set orderses) {
		this.orderses = orderses;
	}

}