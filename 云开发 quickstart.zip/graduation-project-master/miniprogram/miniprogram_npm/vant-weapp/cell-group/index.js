import { VantComponent } from '../common/component';
VantComponent({
    props: {
        border: {
            type: Boolean,
            value: true
        }
    }
});
