export declare const iphonex: void;
