export declare const behavior: void;
